import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  normalizePhone,
  parseReply,
  validDate,
  validSlot,
  mayReply,
  standbyRank,
  isConfirmCommand,
  parseRescheduleCommand,
  parseRequestedDay,
} from '../lib/rules.ts';
test('international phone validation', () => {
  assert.equal(normalizePhone('+56 9 1234 5678'), '+56912345678');
  assert.throws(() => normalizePhone('912345678'));
  assert.throws(() => normalizePhone('+0001234'));
});
test('reply includes exact action and code', () => {
  assert.deepEqual(parseReply(' cancel ab12cd34 '), {
    action: 'CANCEL',
    code: 'AB12CD34',
  });
  assert.equal(parseReply('yes'), null);
  assert.equal(parseReply('ACCEPT AB12CD34 extra'), null);
});
test('stale or wrong-phone replies cannot change booking', () => {
  assert.equal(mayReply('+1', '+2', 100, 200), false);
  assert.equal(mayReply('+1', '+1', 100, 99), false);
  assert.equal(mayReply('+1', '+1', 100, 200), true);
});
test('/reschedule carries whatever day the patient wrote', () => {
  assert.deepEqual(parseRescheduleCommand('/reschedule'), { arg: null });
  assert.deepEqual(parseRescheduleCommand('/reschedule 25/09'), {
    arg: '25/09',
  });
  assert.deepEqual(parseRescheduleCommand('/reschedule@bot cualquier día'), {
    arg: 'cualquier día',
  });
  assert.equal(parseRescheduleCommand('/rescheduled'), null);
  assert.equal(parseRescheduleCommand('R'), null);
});
test('a requested day reads like a Chilean patient writes it', () => {
  const today = '2026-09-16';
  assert.deepEqual(parseRequestedDay('25/09', today), { date: '2026-09-25' });
  assert.deepEqual(parseRequestedDay('25-09', today), { date: '2026-09-25' });
  assert.deepEqual(parseRequestedDay('3.10', today), { date: '2026-10-03' });
  assert.deepEqual(parseRequestedDay('25/09/2026', today), {
    date: '2026-09-25',
  });
  assert.deepEqual(parseRequestedDay('25/09/26', today), {
    date: '2026-09-25',
  });
  assert.deepEqual(parseRequestedDay('2026-09-25', today), {
    date: '2026-09-25',
  });
  assert.deepEqual(parseRequestedDay('cualquier día', today), { any: true });
  assert.deepEqual(parseRequestedDay('Cualquiera', today), { any: true });
  // day/month already past this year → next year, not a past date
  const past = parseRequestedDay('01/03', today);
  assert.ok(past && 'date' in past && past.date.startsWith('2027-03-01'));
  assert.equal(parseRequestedDay('hola', today), null);
  assert.equal(parseRequestedDay('31/02', today), null, 'impossible date');
  assert.equal(parseRequestedDay('2000-01-01', today), null, 'past date');
});
test('/confirm is the confirmation command; a bare C is not', () => {
  assert.equal(isConfirmCommand('/confirm'), true);
  assert.equal(isConfirmCommand('  /CONFIRM '), true);
  assert.equal(isConfirmCommand('/confirm@carequeue_demo_bot'), true);
  assert.equal(isConfirmCommand('C'), false);
  assert.equal(isConfirmCommand('/confirmed'), false);
  assert.equal(isConfirmCommand('/confirm now'), false);
  assert.equal(isConfirmCommand('/cita'), false);
});
test('service catalogue is well formed', async () => {
  const { programs, services } = await import('../lib/services.ts');
  assert.ok(programs.length >= 5);
  for (const p of programs) {
    assert.ok(p.name.trim().length > 0);
    assert.ok(p.services.length > 0, p.name);
    for (const s of p.services) assert.equal(s, s.trim());
  }
  assert.equal(
    new Set(services).size,
    services.length,
    'no service appears under two programmes',
  );
  assert.ok(
    services.every((s) => s.length <= 100),
    'fits the server limit',
  );
});
test('standby candidates: fit for the day first, then longest waiting', () => {
  const rows = [
    { id: 'other-day-old', date: '2099-01-02', created: 100 },
    { id: 'same-day-new', date: '2099-01-01', created: 400 },
    { id: 'any-day-old', date: null, created: 200 },
    { id: 'same-day-old', date: '2099-01-01', created: 300 },
    { id: 'other-day-new', date: '2099-01-03', created: 500 },
  ];
  assert.deepEqual(
    [...rows].sort(standbyRank('2099-01-01')).map((r) => r.id),
    [
      'any-day-old',
      'same-day-old',
      'same-day-new',
      'other-day-old',
      'other-day-new',
    ],
  );
  // With no slot date, only "any day" fits; everything else is by wait time.
  assert.deepEqual(
    [...rows].sort(standbyRank(null)).map((r) => r.id),
    [
      'any-day-old',
      'other-day-old',
      'same-day-old',
      'same-day-new',
      'other-day-new',
    ],
  );
});
test('a standby day is validated like a slot day', () => {
  assert.throws(() => validDate('2099-02-30'));
  assert.throws(() => validDate('2000-01-01'));
  assert.throws(() => validDate('12/09/2099'));
  validDate('2099-09-12');
});
test('invalid dates and times fail', () => {
  assert.throws(() => validSlot('2099-02-30', '10:00'));
  assert.throws(() => validSlot('2099-01-01', '25:00'));
  assert.throws(() => validSlot('2000-01-01', '10:00'));
  validSlot('2099-01-01', '10:00');
});
