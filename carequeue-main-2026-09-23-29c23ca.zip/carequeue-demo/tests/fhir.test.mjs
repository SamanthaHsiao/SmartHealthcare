import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { openDatabase, loadTs } from './harness.mjs';
import { subset } from '../scripts/fhir-subset.mjs';
import {
  assertFhir,
  assertAllFhir,
  fhirErrors,
  schemaEnum,
} from './fhir-validate.mjs';

// The FHIR document store and the resource checks, against SQLite and the
// official R4 schema. The workflow tests validate what the features write;
// this file validates the store itself.

const { DB } = openDatabase();
const { fhirStore, Conflict } = await loadTs('lib/fhir/store.ts');
const { CODES, SYSTEM, EXT, idFrom, assertResource, indexOf } = await loadTs(
  'lib/fhir/resources.ts',
);
const { violations, isValidR4 } = await loadTs('lib/fhir/validate.ts');
const store = fhirStore(DB);
const o = 'clinic-a';

const service = {
  coding: [{ system: SYSTEM.service, code: 'pap', display: 'PAP' }],
  text: 'PAP',
};
const fixtures = () => ({
  Patient: {
    resourceType: 'Patient',
    identifier: [{ system: SYSTEM.record, value: 'P-1234' }],
    name: [{ text: 'Rosa Fuentes' }],
    telecom: [
      {
        system: 'other',
        value: '-1001',
        extension: [{ url: EXT.provider, valueCode: 'telegram' }],
      },
    ],
    extension: [{ url: EXT.notes, valueString: 'Prefers mornings' }],
  },
  Practitioner: {
    resourceType: 'Practitioner',
    name: [{ text: 'Dra. Pérez' }],
  },
  Location: { resourceType: 'Location', name: 'Box 3', status: 'active' },
  HealthcareService: {
    resourceType: 'HealthcareService',
    name: 'PAP',
    type: [service],
    category: [{ text: 'Programa de la Mujer' }],
  },
  Consent: {
    resourceType: 'Consent',
    status: 'active',
    scope: {
      coding: [
        {
          system: 'http://terminology.hl7.org/CodeSystem/consentscope',
          code: 'patient-privacy',
        },
      ],
    },
    category: [{ coding: [{ system: 'http://loinc.org', code: '59284-0' }] }],
    patient: { reference: 'Patient/p1' },
    dateTime: '2026-09-16T00:00:00Z',
    policy: [{ uri: SYSTEM.consentPolicy }],
    provision: { type: 'permit' },
  },
  Schedule: {
    resourceType: 'Schedule',
    actor: [{ reference: 'Practitioner/dr' }, { reference: 'Location/box3' }],
  },
  Slot: {
    resourceType: 'Slot',
    schedule: { reference: 'Schedule/s1' },
    status: 'free',
    start: '2026-09-20T10:00:00-03:00',
    end: '2026-09-20T10:30:00-03:00',
    serviceType: [service],
  },
  Appointment: {
    resourceType: 'Appointment',
    status: 'pending',
    identifier: [{ system: SYSTEM.bookingCode, value: 'ABCD1234' }],
    serviceType: [service],
    slot: [{ reference: 'Slot/s1' }],
    start: '2026-09-20T10:00:00-03:00',
    end: '2026-09-20T10:30:00-03:00',
    created: '2026-09-16T00:00:00Z',
    extension: [{ url: EXT.assigned, valueDateTime: '2026-09-16T00:00:00Z' }],
    participant: [
      { actor: { reference: 'Patient/p1' }, status: 'needs-action' },
      { actor: { reference: 'Practitioner/dr' }, status: 'accepted' },
      { actor: { reference: 'Location/box3' }, status: 'accepted' },
    ],
  },
  AppointmentResponse: {
    resourceType: 'AppointmentResponse',
    appointment: { reference: 'Appointment/a1' },
    actor: { reference: 'Patient/p1' },
    participantStatus: 'accepted',
  },
  Communication: {
    resourceType: 'Communication',
    id: idFrom('reminder:A1:C1'),
    status: 'completed',
    category: [
      { coding: [{ system: SYSTEM.messageCategory, code: 'reminder' }] },
    ],
    identifier: [
      { system: SYSTEM.messageKey, value: 'reminder:A1:C1' },
      { system: SYSTEM.providerMessage, value: 'SM1' },
    ],
    sent: '2026-09-16T00:00:00Z',
    about: [{ reference: 'Appointment/a1' }],
    recipient: [{ reference: 'Patient/p1' }],
    payload: [{ contentString: 'Hola Rosa' }],
    extension: [
      {
        url: EXT.address,
        valueContactPoint: { system: 'other', value: '-1001' },
      },
      { url: EXT.delivery, valueString: 'delivered' },
    ],
  },
});

test('runtime value sets match the official R4 schema', () => {
  const pairs = [
    ['Consent', 'status', CODES.consentStatus],
    ['Slot', 'status', CODES.slotStatus],
    ['Appointment', 'status', CODES.appointmentStatus],
    ['Appointment_Participant', 'status', CODES.participantStatus],
    ['ContactPoint', 'system', CODES.contactPointSystem],
  ];
  for (const [type, element, ours] of pairs)
    assert.deepEqual(
      [...ours],
      schemaEnum(type, element),
      `${type}.${element}`,
    );
  // Where the published schema leaves a required binding as a bare `code`,
  // the runtime list is the only enforcement; pin it to the R4 value sets.
  assert.equal(schemaEnum('Communication', 'status'), null);
  assert.equal(schemaEnum('AppointmentResponse', 'participantStatus'), null);
  assert.deepEqual(
    [...CODES.communicationStatus],
    [
      'preparation',
      'in-progress',
      'not-done',
      'on-hold',
      'stopped',
      'completed',
      'entered-in-error',
      'unknown',
    ],
  );
});

test('every fixture is valid R4 before and after the store touches it', async () => {
  for (const r of Object.values(fixtures())) {
    assertFhir({ id: 'x', ...r });
    const stored = await store.create(o, r);
    assert.match(stored.id, /^[A-Za-z0-9\-.]{1,64}$/);
    assert.equal(stored.meta.versionId, '1');
    assert.match(
      stored.meta.lastUpdated,
      /^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d+Z$/,
    );
    const back = await store.read(o, r.resourceType, stored.id);
    assert.deepEqual(back, stored);
    assertFhir(back);
  }
  assert.equal(assertAllFhir(await store.everything(o)), 10);
});

test('the official schema rejects what the runtime check rejects', () => {
  const bad = { ...fixtures().Appointment, id: 'x', status: 'filled' };
  assert.ok(fhirErrors(bad).length, 'schema: invented status');
  assert.throws(() => assertResource(bad), /Appointment.status must be one of/);
  const noParticipant = { ...fixtures().Appointment, id: 'x' };
  delete noParticipant.participant;
  assert.ok(
    fhirErrors(noParticipant).length,
    'schema: participant is required',
  );
  assert.throws(() => assertResource(noParticipant), /at least one/);
  // The schema cannot say a list must be non-empty; the runtime check does.
  assert.throws(
    () => assertResource({ ...noParticipant, participant: [] }),
    /at least one/,
  );
  const dateOnly = { ...fixtures().Slot, id: 'x', start: '2026-09-20' };
  assert.ok(fhirErrors(dateOnly).length, 'schema: Slot.start needs an instant');
  const unknownField = { ...fixtures().Patient, id: 'x', notes: 'free text' };
  assert.ok(fhirErrors(unknownField).length, 'schema: no such element');
  assert.throws(
    () => assertResource({ resourceType: 'Patient', id: 'has:colon' }),
    /Malformed id/,
  );
  assert.throws(
    () =>
      assertResource({ resourceType: 'Observation', id: 'x', status: 'final' }),
    /Unsupported resource type/,
  );
});

test('a write with an invented status never reaches the database', async () => {
  await assert.rejects(
    store.create(o, { ...fixtures().Slot, status: 'open' }),
    /Slot.status must be one of/,
  );
  await assert.rejects(
    store.create(o, { ...fixtures().Communication, id: 'c2', status: 'sent' }),
    /Communication.status must be one of/,
  );
  assert.equal((await store.search(o, 'Slot', { status: 'open' })).length, 0);
});

test('update carries the version forward and refuses a stale one', async () => {
  const o = 'clinic-update';
  const a = await store.create(o, fixtures().Appointment);
  const booked = await store.update(o, { ...a, status: 'booked' });
  assert.equal(booked.meta.versionId, '2');
  assert.equal((await store.read(o, 'Appointment', a.id)).status, 'booked');
  // The copy read before the first update is stale now.
  await assert.rejects(
    store.update(o, { ...a, status: 'cancelled' }),
    (e) => e instanceof Conflict && /just changed/.test(e.message),
  );
  assert.equal((await store.read(o, 'Appointment', a.id)).status, 'booked');
  // The index follows the document: the old status no longer matches.
  assert.equal(
    (
      await store.search(o, 'Appointment', {
        status: 'pending',
        slot: 'Slot/s1',
      })
    ).length,
    0,
  );
  assert.equal(
    (
      await store.search(o, 'Appointment', {
        status: 'booked',
        slot: 'Slot/s1',
      })
    ).length,
    1,
  );
  await assert.rejects(
    store.update(o, fixtures().Patient),
    /read from the store/,
  );
});

test('createIfAbsent inserts once and reports which happened', async () => {
  const o = 'clinic-absent';
  const c = {
    ...fixtures().Communication,
    id: idFrom('ack:-1001:7'),
    status: 'preparation',
  };
  const first = await store.createIfAbsent(o, c);
  assert.equal(first.created, true);
  const again = await store.createIfAbsent(o, { ...c, status: 'completed' });
  assert.equal(again.created, false);
  assert.equal(again.resource.status, 'preparation', 'the original stands');
  assert.equal(again.resource.meta.versionId, '1');
  // And the index describes the original, not the ignored newcomer — even
  // when both writes land in the same millisecond.
  assert.equal(
    (await store.search(o, 'Communication', { status: 'preparation' })).length,
    1,
  );
  assert.equal(
    (await store.search(o, 'Communication', { status: 'completed' })).length,
    0,
  );
  await assert.rejects(
    store.createIfAbsent(o, fixtures().Patient),
    /needs an id/,
  );
});

test('unique index rows settle a duplicate at the database', async () => {
  const o = 'clinic-unique';
  await store.create(o, fixtures().Practitioner);
  await assert.rejects(
    store.create(o, fixtures().Practitioner),
    (e) => e instanceof Conflict && /already holds that key/.test(e.message),
  );
  assert.equal(
    (await store.search(o, 'Practitioner', { name: 'Dra. Pérez' })).length,
    1,
  );
  await store.create(o, fixtures().Slot);
  await assert.rejects(store.create(o, fixtures().Slot), Conflict);
  await store.create(o, fixtures().Patient);
  await assert.rejects(store.create(o, fixtures().Patient), Conflict);
  // A refused create leaves no index rows behind.
  assert.equal(
    (
      await store.search(o, 'Slot', {
        'schedule-start': 'Schedule/s1@2026-09-20T10:00:00-03:00',
      })
    ).length,
    1,
  );
  // The same clinician at another time, or in another workspace, is fine.
  await store.create(o, {
    ...fixtures().Slot,
    start: '2026-09-20T10:30:00-03:00',
    end: '2026-09-20T11:00:00-03:00',
  });
  await store.create('clinic-b', fixtures().Practitioner);
});

test('search ANDs parameters and ORs values of one parameter', async () => {
  const o = 'clinic-search';
  const booked = await store.create(o, {
    ...fixtures().Appointment,
    status: 'booked',
  });
  const waiting = await store.create(o, {
    resourceType: 'Appointment',
    status: 'waitlist',
    serviceType: [service],
    requestedPeriod: [{ start: '2026-09-25', end: '2026-09-25' }],
    created: '2026-09-16T00:00:00Z',
    participant: [
      { actor: { reference: 'Patient/p2' }, status: 'needs-action' },
    ],
  });
  assertFhir(waiting);
  const byPatient = await store.search(o, 'Appointment', {
    patient: 'Patient/p2',
  });
  assert.deepEqual(
    byPatient.map((x) => x.id),
    [waiting.id],
  );
  const either = await store.search(o, 'Appointment', {
    status: ['waitlist', 'booked'],
  });
  assert.equal(either.length, 2);
  const both = await store.search(o, 'Appointment', {
    status: ['waitlist', 'booked'],
    patient: 'Patient/p1',
  });
  assert.deepEqual(
    both.map((x) => x.id),
    [booked.id],
  );
  assert.deepEqual(await store.search(o, 'Appointment', { status: [] }), []);
  assert.equal(
    (
      await store.search(o, 'Appointment', {
        'service-type': `${SYSTEM.service}|pap`,
      })
    ).length,
    2,
  );
  assert.equal(
    (await store.search(o, 'Appointment', { 'service-type': 'PAP' })).length,
    2,
  );
  assert.equal(
    (await store.search(o, 'Appointment', { 'service-type': 'Dental' })).length,
    0,
  );
});

test('every read and search is scoped to the owner', async () => {
  const [p] = await store.search(o, 'Patient');
  assert.ok(p);
  assert.equal(await store.read('clinic-b', 'Patient', p.id), null);
  assert.equal(
    (await store.search('clinic-b', 'Patient', { telecom: '-1001' })).length,
    0,
  );
  assert.equal(await store.remove('clinic-b', 'Patient', p.id), false);
  assert.ok(await store.read(o, 'Patient', p.id));
  assert.deepEqual(await store.resolve(o, 'Patient/' + p.id), p);
  assert.equal(await store.resolve(o, 'Patient/nobody'), null);
  assert.equal(await store.resolve(o, 'garbage'), null);
});

test('remove deletes the document and its index rows', async () => {
  const [p] = await store.search(o, 'Patient', { telecom: '-1001' });
  assert.equal(await store.remove(o, 'Patient', p.id), true);
  assert.equal(await store.read(o, 'Patient', p.id), null);
  assert.equal(
    (await store.search(o, 'Patient', { telecom: '-1001' })).length,
    0,
  );
  assert.equal(await store.remove(o, 'Patient', p.id), false);
  // The record number is free again.
  await store.create(o, fixtures().Patient);
});

test('ids from message keys are reversible and stay inside the R4 id charset', () => {
  assert.equal(idFrom('reminder:A1B2C3D4:E5F6:2'), 'reminder.A1B2C3D4.E5F6.2');
  assert.equal(idFrom('inbound:-1001234:45'), 'inbound.-1001234.45');
  assert.equal(
    idFrom('ack:SM0123456789abcdef0123456789abcdef'),
    'ack.SM0123456789abcdef0123456789abcdef',
  );
  assert.throws(() => idFrom('has space'), /Not a usable FHIR id/);
  assert.throws(() => idFrom('x'.repeat(65)), /Not a usable FHIR id/);
  assert.throws(() => idFrom(''), /Not a usable FHIR id/);
});

test('the index describes what each resource can be found by', () => {
  const f = fixtures();
  const names = (r) =>
    indexOf({ id: 'x', ...r }).map(
      (x) => x.param + (x.unique ? '!' : '') + '=' + x.value,
    );
  assert.deepEqual(names(f.Patient), [
    `identifier!=${SYSTEM.record}|P-1234`,
    'telecom=-1001',
    'name=Rosa Fuentes',
  ]);
  assert.deepEqual(names(f.Schedule), [
    'actor=Practitioner/dr',
    'actor=Location/box3',
    'actors!=Location/box3,Practitioner/dr',
  ]);
  assert.ok(
    names(f.Slot).includes(
      'schedule-start!=Schedule/s1@2026-09-20T10:00:00-03:00',
    ),
  );
  assert.ok(names(f.Appointment).includes('patient=Patient/p1'));
  assert.ok(names(f.Appointment).includes('practitioner=Practitioner/dr'));
  assert.ok(names(f.Appointment).includes('location=Location/box3'));
  assert.ok(
    names(f.Appointment).includes(`identifier=${SYSTEM.bookingCode}|ABCD1234`),
  );
  assert.ok(names(f.Communication).includes('address=-1001'));
  assert.ok(
    names(f.Communication).includes(
      `category=${SYSTEM.messageCategory}|reminder`,
    ),
  );
});

test('transact writes several resources together, or none of them', async () => {
  const o = 'clinic-transact';
  const slot = await store.create(o, fixtures().Slot);
  const a = await store.create(o, fixtures().Appointment);
  // A stale copy of the slot in the same transaction as a good appointment
  // update: the batch is refused and the appointment is untouched.
  const staleSlot = { ...slot, status: 'busy' };
  await store.update(o, { ...slot, status: 'busy' });
  await assert.rejects(
    store.transact(o, [
      { update: { ...a, status: 'booked' } },
      { update: { ...staleSlot, status: 'free' } },
    ]),
    (e) => e instanceof Conflict && e.kind === 'stale',
  );
  assert.equal((await store.read(o, 'Appointment', a.id)).status, 'pending');
  assert.equal((await store.read(o, 'Appointment', a.id)).meta.versionId, '1');
  assert.equal((await store.read(o, 'Slot', slot.id)).status, 'busy');
  // With fresh copies both land, plus a create and a removal in the same
  // batch, and the index follows every one of them.
  const fresh = await store.read(o, 'Slot', slot.id);
  const [booked, freed, response, gone] = await store.transact(o, [
    { update: { ...a, status: 'booked' } },
    { update: { ...fresh, status: 'free' } },
    { create: fixtures().AppointmentResponse },
    { remove: { type: 'Patient', id: 'nobody' } },
  ]);
  assert.equal(booked.status, 'booked');
  assert.equal(booked.meta.versionId, '2');
  assert.equal(freed.meta.versionId, '3');
  assert.ok(response.id);
  assert.equal(gone, null);
  assert.equal(
    (await store.search(o, 'Appointment', { status: 'booked' })).length,
    1,
  );
  assert.equal((await store.search(o, 'Slot', { status: 'free' })).length, 1);
  assert.equal(
    (
      await store.search(o, 'AppointmentResponse', {
        'part-status': 'accepted',
      })
    ).length,
    1,
  );
  // A unique key taken inside a transaction rolls the rest back too.
  await assert.rejects(
    store.transact(o, [
      { update: { ...booked, status: 'cancelled' } },
      { create: fixtures().Slot },
    ]),
    (e) => e instanceof Conflict && e.kind === 'unique',
  );
  assert.equal((await store.read(o, 'Appointment', a.id)).status, 'booked');
});

test('the import schema subset is the official schema, cut down and up to date', () => {
  const committed = JSON.parse(
    readFileSync('fhir/r4-import.schema.json', 'utf8'),
  );
  assert.deepEqual(committed, subset(), 'run: node scripts/fhir-subset.mjs');
  assert.equal(Object.keys(committed.definitions).length, 81);
  assert.ok(
    committed.definitions.Patient.properties.contained === undefined,
    'contained is left out',
  );
  assert.ok(
    readFileSync('fhir/r4-import.schema.json').length < 80_000,
    'small enough for the Worker',
  );
});

test('the import validator gives the same verdicts as ajv on the official schema', () => {
  const agree = (r, label) => {
    const official = fhirErrors({ id: 'x', ...r }).length === 0;
    const ours = violations({ id: 'x', ...r });
    assert.equal(
      ours.length === 0,
      official,
      `${label}: ours ${JSON.stringify(ours)} vs official ${official ? 'valid' : 'invalid'}`,
    );
    return ours;
  };
  // Communication is never imported, so it is outside the subset.
  for (const [type, r] of Object.entries(fixtures()))
    if (type !== 'Communication') agree(r, type);
  assert.match(
    violations(fixtures().Communication)[0].message,
    /no R4 definition for Communication/,
  );
  // What review sent in: a birthDate that is not a date, a string for a
  // boolean, an element R4 does not have.
  const bad = agree(
    {
      resourceType: 'Patient',
      birthDate: 'not-a-date',
      active: 'yes',
      favouriteColour: 'green',
      name: [{ text: 'X' }],
    },
    'bad patient',
  );
  assert.deepEqual(
    bad.map((v) => `${v.path}: ${v.message}`),
    [
      'birthDate: is not a valid date',
      'active: must be a boolean',
      'favouriteColour: is not an element of Patient',
    ],
  );
  agree({ ...fixtures().Appointment, status: 'filled' }, 'invented status');
  agree(
    { ...fixtures().Appointment, participant: undefined },
    'missing participant',
  );
  agree({ ...fixtures().Slot, start: '2026-09-20' }, 'date for an instant');
  agree(
    { ...fixtures().Patient, telecom: [{ system: 'whatsapp', value: '1' }] },
    'telecom system off the list',
  );
  agree({ ...fixtures().Patient, name: 'Rosa' }, 'a string where a list goes');
  agree(
    {
      ...fixtures().Patient,
      extension: [{ url: 'http://x', valueInteger: 1.5 }],
    },
    'a decimal for an integer',
  );
  agree(
    { ...fixtures().Consent, provision: { type: 'maybe' } },
    'provision type off the list',
  );
  agree(
    { ...fixtures().Location, position: { longitude: 'east', latitude: 1 } },
    'a string for a decimal',
  );
  assert.match(
    violations({ resourceType: 'Observation', status: 'final', code: {} })[0]
      .message,
    /no R4 definition/,
  );
  assert.equal(isValidR4(fixtures().Patient), true);
  assert.equal(
    isValidR4({ resourceType: 'Patient', id: 'x', gender: 'other-ish' }),
    false,
  );
});

test('search can order by an indexed parameter and cut in the database', async () => {
  const o = 'clinic-order';
  const at = (n) => `2026-09-16T10:${String(n).padStart(2, '0')}:00.000Z`;
  for (const n of [5, 1, 9, 3])
    await store.create(o, {
      ...fixtures().Communication,
      id: `m-${n}`,
      identifier: [{ system: SYSTEM.messageKey, value: `k:${n}` }],
      ...(n % 2 ? { sent: at(n) } : { received: at(n), sent: undefined }),
    });
  const newest = await store.search(
    o,
    'Communication',
    {},
    { sort: { param: ['sent', 'received'], descending: true }, limit: 2 },
  );
  assert.deepEqual(
    newest.map((c) => c.id),
    ['m-9', 'm-5'],
  );
  const oldest = await store.search(
    o,
    'Communication',
    {},
    { sort: { param: ['sent', 'received'] } },
  );
  assert.deepEqual(
    oldest.map((c) => c.id),
    ['m-1', 'm-3', 'm-5', 'm-9'],
  );
  assert.equal(
    (await store.search(o, 'Communication', {}, { limit: 3 })).length,
    3,
  );
});
