import { test, afterEach } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { openDatabase, loadTs } from './harness.mjs';
import { assertAllFhir, assertFhir } from './fhir-validate.mjs';
import {
  installFakeProviders,
  telegramCredentials,
  twilioCredentials,
} from './fake-providers.mjs';

// The FHIR-backed workspace, exercised through its own `action` and `state`
// with SQLite and fake vendors. After every test, every resource in every
// workspace touched is validated against the official R4 schema, so a
// feature cannot write something that is not FHIR without failing here.

const { DB } = openDatabase();
globalThis.__cqEnv = {
  DB,
  CREDENTIAL_KEY: Buffer.from(
    crypto.getRandomValues(new Uint8Array(32)),
  ).toString('base64'),
};
const stubs = {
  'cloudflare:workers': 'export const env=globalThis.__cqEnv',
  '@/app/chatgpt-auth':
    'export async function getChatGPTUser(){return {userId:"owner"}}',
};
const { action, state } = await loadTs('lib/fhir/backend.ts', stubs);
const { store } = await loadTs('lib/workspace.ts', stubs);
const { SYSTEM, EXT } = await loadTs('lib/fhir/resources.ts');
const {
  serviceCodeSystem,
  patientName,
  patientRecord,
  patientAddress,
  patientNotes,
} = await loadTs('lib/fhir/build.ts');
const { practitionerOf, locationOf, serviceOf, unreachable } = await loadTs(
  'lib/fhir/registry.ts',
  stubs,
);
const { confirmAppointment, releaseToStandby } = await loadTs(
  'lib/fhir/scheduling.ts',
  stubs,
);
const { instantOf, wallTime, plusMinutes } = await loadTs('lib/fhir/time.ts');
const { project, availability } = await loadTs('lib/fhir/view.ts');
const { exportBundle, importBundle } = await loadTs(
  'lib/fhir/bundle.ts',
  stubs,
);
const hospitalBundle = () =>
  JSON.parse(readFileSync('tests/fixtures/hospital-bundle.json', 'utf8'));
const { gridTimes, hoursLabel } = await loadTs('lib/timetable.ts');
const {
  bookingCode,
  assignedAt,
  releasedAt,
  requestedDay,
  patientRefOf,
  slotRefOf,
  serviceOfAppointment,
  messageKey,
  deliveryStatus,
  messageBody,
  messageAddress,
  messageDirection,
  providerSid,
} = await loadTs('lib/fhir/build.ts');
const fake = installFakeProviders();

const owners = new Set();
const act = (o, data) => {
  owners.add(o);
  return action(o, data);
};
afterEach(async () => {
  for (const o of owners) assertAllFhir(await store().everything(o));
});

const phoneA = '+56911111111',
  phoneB = '+56922222222';
const byName = (s, name) => s.Patient.find((p) => patientName(p) === name);

// A Twilio workspace with one registered phone and the named patients on
// it; returns patient ids by name.
async function clinic(o, names) {
  await act(o, twilioCredentials);
  await act(o, {
    action: 'contact',
    name: 'Team',
    phone: phoneA,
    consent: true,
  });
  const ids = {};
  for (const name of names) {
    await act(o, { action: 'patient', name, phone: phoneA });
    ids[name] = byName(await state(o), name).id;
  }
  return ids;
}
const slot = (patient, extra = {}) => ({
  action: 'appointment',
  patient,
  date: '2099-09-10',
  time: '10:00',
  clinician: 'Dr Demo',
  service: 'PAP',
  location: 'Demo Room',
  ...extra,
});
const live = (s) =>
  s.Appointment.filter((a) => ['pending', 'booked'].includes(a.status));
const waiting = (s) => s.Appointment.filter((a) => a.status === 'waitlist');
const open = (s) => s.Slot.filter((x) => x.status === 'free');
const byKey = (s, key) => s.Communication.find((c) => messageKey(c) === key);
const inboundOf = (s) =>
  s.Communication.filter((c) => messageDirection(c) === 'inbound');
// A WhatsApp reply arriving on the next poll.
const whatsapp = async (o, phone, body) => {
  fake.incoming.push({
    sid: 'IN' + fake.incoming.length,
    direction: 'inbound',
    from: 'whatsapp:' + phone,
    body,
    date_sent: new Date(Date.now()).toISOString(),
  });
  await act(o, { action: 'sync' });
};
// A Telegram message arriving on the next poll; `ago` shifts its time back.
let updateId = 100;
const telegram = async (o, chat, text, { ago = 0, title } = {}) => {
  updateId += 1;
  fake.tgUpdates.push({
    update_id: updateId,
    message: {
      message_id: updateId,
      date: Math.floor(Date.now() / 1000) - ago,
      text,
      chat: title
        ? { id: Number(chat), title, type: 'group' }
        : { id: Number(chat), first_name: 'Chat ' + chat },
    },
  });
  await act(o, { action: 'sync' });
  return `${chat}:${updateId}`;
};

test('the service catalogue is a valid CodeSystem', () => {
  const cs = serviceCodeSystem();
  assertFhir(cs);
  assert.equal(cs.url, SYSTEM.service);
  const codes = cs.concept.flatMap((p) => p.concept.map((c) => c.code));
  assert.equal(new Set(codes).size, codes.length, 'codes are distinct');
  assert.ok(codes.includes('consulta-ginecologica'));
  assert.ok(codes.includes('atencion-por-consumo-problematico-oh-y-drogas'));
  assert.equal(cs.count, cs.concept.length + codes.length);
});

test('a patient is a Patient with a record number, a telecom and a Consent', async () => {
  const o = 'clinic-patients';
  await act(o, twilioCredentials);
  await act(o, {
    action: 'contact',
    name: 'Team',
    phone: phoneA,
    consent: true,
  });
  // The address must be a registered, consented recipient.
  await assert.rejects(
    act(o, { action: 'patient', name: 'Nobody', phone: phoneB }),
    /Register this recipient/,
  );
  await assert.rejects(
    act(o, { action: 'patient', name: '', phone: phoneA }),
    /Patient name/,
  );
  await act(o, {
    action: 'patient',
    name: 'Fictional Elena',
    phone: phoneA,
    notes: 'Prefers mornings',
  });
  const s = await state(o);
  const elena = byName(s, 'Fictional Elena');
  assert.ok(elena);
  assert.equal(elena.resourceType, 'Patient');
  assert.match(patientRecord(elena), /^P-[0-9A-F]{4}$/);
  assert.equal(patientAddress(elena), phoneA);
  assert.deepEqual(
    elena.telecom[0].system,
    'phone',
    'a WhatsApp number is a phone',
  );
  assert.equal(
    elena.telecom[0].extension.find((x) => x.url === EXT.provider).valueCode,
    'twilio',
  );
  assert.equal(patientNotes(elena), 'Prefers mornings');
  const consent = s.Consent.find(
    (c) => c.patient.reference === 'Patient/' + elena.id,
  );
  assert.ok(consent, 'one Consent per patient');
  assert.equal(consent.status, 'active');
  assert.equal(consent.provision.type, 'permit');
  assert.equal(consent.policy[0].uri, SYSTEM.consentPolicy);
  assert.equal(await unreachable(o, elena), null);
  // Several patients on one device, which is how one phone plays a room.
  await act(o, { action: 'patient', name: 'Fictional Mateo', phone: phoneA });
  assert.equal((await state(o)).Patient.length, 2);
  assert.deepEqual(
    (await state(o)).Patient.map(patientName),
    ['Fictional Elena', 'Fictional Mateo'],
    'listed by name',
  );
  // Another workspace sees nothing of it.
  assert.equal((await state('clinic-other')).Patient.length, 0);
});

test('editing keeps the record number, re-dates consent on a new address', async () => {
  const o = 'clinic-edit';
  await act(o, telegramCredentials);
  // Telegram recipients are bound by an in-chat link code, which is the
  // sync module's job; until that has moved, two chats are registered
  // directly in the operational table.
  await DB.prepare(
    "INSERT INTO contacts(id,owner,name,phone,consent) VALUES('c1',?,'Beto chat','-1001',1),('c2',?,'Camila chat','-1002',1)",
  )
    .bind(o, o)
    .run();
  await act(o, { action: 'patient', name: 'Fictional Beto', phone: '-1001' });
  const before = byName(await state(o), 'Fictional Beto');
  assert.equal(before.telecom[0].system, 'other', 'a chat id is not a phone');
  const consentBefore = (await state(o)).Consent[0];

  const r1 = await act(o, {
    action: 'patientEdit',
    id: before.id,
    name: 'Fictional Beto Rojas',
    phone: '-1001',
    notes: '',
  });
  assert.match(r1.message, /^Patient updated\.$/);
  const renamed = byName(await state(o), 'Fictional Beto Rojas');
  assert.equal(renamed.id, before.id);
  assert.equal(
    patientRecord(renamed),
    patientRecord(before),
    'record number never changes',
  );
  assert.equal(renamed.meta.versionId, '2');
  assert.equal(patientNotes(renamed), null, 'blank notes remove the extension');
  assert.equal(
    (await state(o)).Consent[0].dateTime,
    consentBefore.dateTime,
    'same address, same consent',
  );

  const r2 = await act(o, {
    action: 'patientEdit',
    id: before.id,
    name: 'Fictional Beto Rojas',
    phone: '-1002',
    notes: 'moved',
  });
  assert.match(r2.message, /delivery address changed/);
  const moved = byName(await state(o), 'Fictional Beto Rojas');
  assert.equal(patientAddress(moved), '-1002');
  assert.equal(patientNotes(moved), 'moved');
  const consentAfter = (await state(o)).Consent[0];
  assert.equal(
    consentAfter.id,
    consentBefore.id,
    'the Consent is re-dated, not replaced',
  );
  assert.notEqual(consentAfter.dateTime, consentBefore.dateTime);
  assert.equal(consentAfter.status, 'active');

  await assert.rejects(
    act(o, { action: 'patientEdit', id: before.id, name: 'X', phone: '-1003' }),
    /Register this recipient/,
  );
  await assert.rejects(
    act(o, { action: 'patientEdit', id: 'nobody', name: 'X', phone: '-1001' }),
    /Select a patient/,
  );
});

test('a patient outlives the device that reached them and is reported, not dropped', async () => {
  const o = 'clinic-switch';
  await act(o, twilioCredentials);
  await act(o, {
    action: 'contact',
    name: 'Team',
    phone: phoneA,
    consent: true,
  });
  await act(o, { action: 'patient', name: 'Fictional Rosa', phone: phoneA });
  // Switching provider drops the registered recipients.
  await act(o, telegramCredentials);
  const s = await state(o);
  assert.equal(s.contacts.length, 0);
  const rosa = byName(s, 'Fictional Rosa');
  assert.ok(rosa, 'the record stays');
  assert.match(
    await unreachable(o, rosa),
    /no reachable device: \+56911111111 is not a registered recipient/,
  );
  assert.equal(s.Consent.length, 1, 'her consent record stays too');
});

test('deleting a patient removes the record and its consent, nothing else', async () => {
  const o = 'clinic-delete';
  await act(o, twilioCredentials);
  await act(o, {
    action: 'contact',
    name: 'Team',
    phone: phoneA,
    consent: true,
  });
  await act(o, { action: 'patient', name: 'Fictional Camila', phone: phoneA });
  await act(o, { action: 'patient', name: 'Fictional Mateo', phone: phoneA });
  const camila = byName(await state(o), 'Fictional Camila');
  await assert.rejects(
    act(o, { action: 'patientDelete', id: 'nobody' }),
    /Select a patient/,
  );
  await assert.rejects(
    act('clinic-other', { action: 'patientDelete', id: camila.id }),
    /Select a patient/,
  );
  await act(o, { action: 'patientDelete', id: camila.id });
  const s = await state(o);
  assert.deepEqual(s.Patient.map(patientName), ['Fictional Mateo']);
  assert.equal(s.Consent.length, 1);
  assert.equal(s.Consent[0].patient.reference, 'Patient/' + s.Patient[0].id);
  assert.equal(
    s.contacts.length,
    1,
    "the device registration is not the patient's",
  );
});

test('clinicians, rooms and services are found or created by name, once', async () => {
  const o = 'clinic-names';
  const a = await practitionerOf(o, 'Dra. Pérez');
  const b = await practitionerOf(o, 'Dra. Pérez');
  assert.equal(a.id, b.id);
  assert.equal(a.resourceType, 'Practitioner');
  assert.equal(a.name[0].text, 'Dra. Pérez');
  const c = await practitionerOf(o, 'Dra. Perez');
  assert.notEqual(a.id, c.id, 'names match exactly');
  const room = await locationOf(o, 'Box 3');
  assert.equal((await locationOf(o, 'Box 3')).id, room.id);
  assert.equal(room.status, 'active');
  const pap = await serviceOf(o, 'PAP');
  assert.equal((await serviceOf(o, 'PAP')).id, pap.id);
  assert.deepEqual(pap.type[0].coding[0], {
    system: SYSTEM.service,
    code: 'pap',
    display: 'PAP',
  });
  assert.equal(pap.category[0].text, 'Programa de la Mujer');
  const typed = await serviceOf(o, 'Kinesiología');
  assert.equal(
    typed.type[0].coding,
    undefined,
    'a service off the menu has text only',
  );
  assert.equal(typed.type[0].text, 'Kinesiología');
  assert.equal(typed.category, undefined);
  const s = await state(o);
  assert.equal(s.Practitioner.length, 2);
  assert.equal(s.Location.length, 1);
  assert.equal(s.HealthcareService.length, 2);
  assert.equal((await state('clinic-other')).Practitioner.length, 0);
});

test('clinic time: instants carry the Chilean offset of their day and round-trip', () => {
  assert.equal(
    instantOf('2099-01-15', '10:00'),
    '2099-01-15T10:00:00-03:00',
    'summer',
  );
  assert.equal(
    instantOf('2099-06-15', '10:00'),
    '2099-06-15T10:00:00-04:00',
    'winter',
  );
  assert.deepEqual(wallTime('2099-06-15T10:00:00-04:00'), {
    date: '2099-06-15',
    time: '10:00',
  });
  assert.deepEqual(wallTime('2099-06-15T14:00:00Z'), {
    date: '2099-06-15',
    time: '10:00',
  });
  assert.equal(
    plusMinutes('2099-01-15T10:00:00-03:00', 30),
    '2099-01-15T10:30:00-03:00',
  );
  assert.equal(
    plusMinutes('2099-01-15T23:45:00-03:00', 30),
    '2099-01-16T00:15:00-03:00',
  );
});

test('booking makes a Schedule, a busy 30-minute Slot and a pending Appointment', async () => {
  const o = 'clinic-book';
  const { 'Fictional Elena': elena } = await clinic(o, ['Fictional Elena']);
  await assert.rejects(act(o, slot('nobody')), /Choose a patient/);
  await assert.rejects(
    act(o, slot(elena, { date: '2020-01-01' })),
    /today or a future/,
  );
  await assert.rejects(
    act(o, slot(elena, { time: '25:00' })),
    /valid appointment date and time/,
  );
  await act(o, slot(elena));
  await assert.rejects(act(o, slot(elena)), /already has an appointment slot/);
  // Same clinician, other room: a different schedule, no collision.
  await act(o, slot(elena, { location: 'Room B' }));
  const s = await state(o);
  assert.equal(s.Schedule.length, 2, 'one schedule per clinician and room');
  assert.equal(s.Slot.length, 2);
  const [a] = live(s);
  assert.equal(a.status, 'pending');
  assert.equal(a.start, '2099-09-10T10:00:00-03:00');
  assert.equal(a.end, '2099-09-10T10:30:00-03:00');
  assert.match(bookingCode(a), /^[0-9A-F]{8}$/);
  assert.equal(serviceOfAppointment(a), 'PAP');
  assert.equal(a.serviceType[0].coding[0].code, 'pap');
  assert.equal(patientRefOf(a), 'Patient/' + elena);
  const roles = a.participant.map(
    (p) => p.actor.reference.split('/')[0] + ':' + p.status,
  );
  assert.deepEqual(roles, [
    'Patient:needs-action',
    'Practitioner:accepted',
    'Location:accepted',
  ]);
  const held = s.Slot.find((x) => 'Slot/' + x.id === slotRefOf(a));
  assert.equal(held.status, 'busy');
  assert.equal(held.start, a.start);
  assert.equal(serviceOfAppointment(held), 'PAP');
  assert.equal(s.Practitioner.map((p) => p.name[0].text).join(), 'Dr Demo');
  assert.deepEqual(s.Location.map((l) => l.name).sort(), [
    'Demo Room',
    'Room B',
  ]);
  assert.equal(s.HealthcareService[0].name, 'PAP');
  assert.equal(
    assignedAt(a),
    null,
    'a direct booking did not come from standby',
  );
  assert.equal((await state('clinic-other')).Appointment.length, 0);
  await assert.rejects(
    act('clinic-other', { action: 'cancel', id: a.id }),
    /active appointment/,
  );
});

test('editing an appointment moves its slot and rotates the code only when something moved', async () => {
  const o = 'clinic-edit-appt';
  const ids = await clinic(o, ['Fictional Elena', 'Fictional Mateo']);
  await act(o, slot(ids['Fictional Elena']));
  await act(o, slot(ids['Fictional Mateo'], { time: '11:00' }));
  let [a, b] = live(await state(o));
  const code = bookingCode(a);
  const edit = (extra) => ({
    action: 'update',
    id: a.id,
    patient: ids['Fictional Elena'],
    date: '2099-09-10',
    time: '10:00',
    clinician: 'Dr Demo',
    service: 'PAP',
    location: 'Demo Room',
    ...extra,
  });
  // Confirm it first, so the effect on a confirmation shows.
  await confirmAppointment(o, a, 'test');
  const r0 = await act(o, edit({ service: 'Control prenatal' }));
  assert.match(r0.message, /^Appointment updated\. No message was sent\.$/);
  [a] = live(await state(o));
  assert.equal(
    a.status,
    'booked',
    'a new service alone keeps the confirmation',
  );
  assert.equal(bookingCode(a), code);
  assert.equal(serviceOfAppointment(a), 'Control prenatal');
  const held = (await state(o)).Slot.find(
    (x) => 'Slot/' + x.id === slotRefOf(a),
  );
  assert.equal(
    serviceOfAppointment(held),
    'Control prenatal',
    'the slot follows',
  );
  await assert.rejects(
    act(o, edit({ time: '11:00' })),
    /already has an appointment slot/,
  );
  const r1 = await act(o, edit({ time: '12:00', service: 'Control prenatal' }));
  assert.match(r1.message, /slot changed/);
  const s = await state(o);
  [a] = s.Appointment.filter((x) => x.id === a.id);
  assert.equal(a.status, 'pending', 'moving retires the confirmation');
  assert.notEqual(bookingCode(a), code, 'and rotates the code');
  assert.equal(a.start, '2099-09-10T12:00:00-03:00');
  assert.equal(a.participant[0].status, 'needs-action');
  assert.equal(s.Slot.length, 2, 'the old slot is gone, not left open');
  assert.ok(s.Slot.every((x) => x.status === 'busy'));
  assert.equal(
    s.AppointmentResponse.length,
    1,
    'the earlier acceptance stays on record',
  );
  // A different patient is a move too.
  const r2 = await act(
    o,
    edit({
      time: '12:00',
      service: 'Control prenatal',
      patient: ids['Fictional Mateo'],
    }),
  );
  assert.match(r2.message, /slot changed/);
  [a] = (await state(o)).Appointment.filter((x) => x.id === a.id);
  assert.equal(patientRefOf(a), 'Patient/' + ids['Fictional Mateo']);
  await assert.rejects(
    act(o, edit({ id: b.id, patient: 'nobody' })),
    /Choose a patient/,
  );
  await assert.rejects(
    act(o, edit({ id: 'nobody' })),
    /Select an active appointment/,
  );
});

test('cancel frees the slot; delete removes booking and slot; open slots can be deleted', async () => {
  const o = 'clinic-cancel';
  const { 'Fictional Rosa': rosa } = await clinic(o, ['Fictional Rosa']);
  await act(o, slot(rosa));
  await act(o, slot(rosa, { time: '11:00' }));
  let [a, b] = live(await state(o));
  const r = await act(o, { action: 'cancel', id: a.id });
  assert.match(r.message, /released the slot/);
  let s = await state(o);
  assert.equal(s.Appointment.find((x) => x.id === a.id).status, 'cancelled');
  assert.equal(open(s).length, 1, 'the slot is on the board as open');
  assert.equal(open(s)[0].id, slotRefOf(a).split('/')[1]);
  await assert.rejects(
    act(o, { action: 'cancel', id: a.id }),
    /active appointment/,
  );
  // Booking the same time again takes the open slot over rather than
  // refusing it: the same Slot, busy again, nothing added.
  await act(o, slot(rosa, { service: 'Dental' }));
  s = await state(o);
  assert.equal(open(s).length, 0);
  assert.equal(s.Slot.length, 2);
  const retaken = live(s).find((x) => slotRefOf(x) === slotRefOf(a));
  assert.ok(retaken, 'on the very slot that was open');
  assert.equal(
    serviceOfAppointment(s.Slot.find((x) => 'Slot/' + x.id === slotRefOf(a))),
    'Dental',
    'with the new service',
  );
  await act(o, { action: 'cancel', id: retaken.id });
  assert.equal(open(await state(o)).length, 1);
  // A cancelled appointment can still be deleted, without touching the slot.
  await act(o, { action: 'appointmentDelete', id: a.id });
  s = await state(o);
  assert.equal(s.Appointment.length, 2, 'b and the second cancelled booking');
  assert.equal(open(s).length, 1);
  await assert.rejects(
    act(o, { action: 'slotDelete', id: slotRefOf(b).split('/')[1] }),
    /open slot/,
  );
  await act(o, { action: 'slotDelete', id: open(s)[0].id });
  assert.equal(open(await state(o)).length, 0);
  // Deleting a live booking takes its slot with it.
  await act(o, { action: 'appointmentDelete', id: b.id });
  s = await state(o);
  assert.equal(s.Appointment.filter((x) => x.status !== 'cancelled').length, 0);
  assert.equal(s.Slot.length, 0);
  await assert.rejects(
    act(o, { action: 'appointmentDelete', id: b.id }),
    /Select an appointment/,
  );
});

test('the standby list is waitlist Appointments: one per patient, service and day', async () => {
  const o = 'clinic-standby';
  const ids = await clinic(o, ['Fictional Beto', 'Fictional Camila']);
  const beto = ids['Fictional Beto'];
  await act(o, {
    action: 'standby',
    patient: beto,
    service: 'PAP',
    date: '2099-09-10',
  });
  await assert.rejects(
    act(o, {
      action: 'standby',
      patient: beto,
      service: 'PAP',
      date: '2099-09-10',
    }),
    /already waiting for that service on that day/,
  );
  await act(o, { action: 'standby', patient: beto, service: 'PAP', date: '' });
  await assert.rejects(
    act(o, { action: 'standby', patient: beto, service: 'PAP' }),
    /on any day/,
  );
  await act(o, {
    action: 'standby',
    patient: beto,
    service: 'PAP',
    date: '2099-09-11',
  });
  await assert.rejects(
    act(o, {
      action: 'standby',
      patient: beto,
      service: 'PAP',
      date: '2020-01-01',
    }),
    /future/,
  );
  await assert.rejects(
    act(o, { action: 'standby', patient: 'nobody', service: 'PAP' }),
    /Choose a patient/,
  );
  let s = await state(o);
  assert.equal(waiting(s).length, 3);
  assert.deepEqual(
    waiting(s)
      .map(requestedDay)
      .sort((a, b) => String(a).localeCompare(String(b))),
    ['2099-09-10', '2099-09-11', null],
  );
  const w = waiting(s).find((a) => requestedDay(a) === '2099-09-11');
  assert.equal(w.participant.length, 1);
  assert.equal(w.slot, undefined);
  assert.ok(w.created);
  // Edit: another patient, service and day; the same day for the same patient is refused.
  await assert.rejects(
    act(o, {
      action: 'standbyEdit',
      id: w.id,
      patient: beto,
      service: 'PAP',
      date: '2099-09-10',
    }),
    /already waiting/,
  );
  await act(o, {
    action: 'standbyEdit',
    id: w.id,
    patient: ids['Fictional Camila'],
    service: 'Dental',
    date: '',
  });
  s = await state(o);
  const edited = s.Appointment.find((a) => a.id === w.id);
  assert.equal(patientRefOf(edited), 'Patient/' + ids['Fictional Camila']);
  assert.equal(serviceOfAppointment(edited), 'Dental');
  assert.equal(requestedDay(edited), null);
  assert.equal(
    edited.created,
    w.created,
    'editing keeps the place in the queue',
  );
  await act(o, { action: 'standbyDelete', id: w.id });
  assert.equal(waiting(await state(o)).length, 2);
  await assert.rejects(
    act(o, { action: 'standbyDelete', id: w.id }),
    /Select a standby entry/,
  );
  await assert.rejects(
    act(o, {
      action: 'standbyEdit',
      id: 'nobody',
      patient: beto,
      service: 'PAP',
    }),
    /Select a standby entry/,
  );
});

test('assigning moves the waitlist entry itself onto the slot; undoing it parks the entry as released', async () => {
  const o = 'clinic-assign';
  const ids = await clinic(o, ['Fictional Elena', 'Fictional Beto']);
  const elena = ids['Fictional Elena'],
    beto = ids['Fictional Beto'];
  await act(o, slot(elena));
  const [booked] = live(await state(o));
  await act(o, { action: 'cancel', id: booked.id });
  await act(o, {
    action: 'standby',
    patient: beto,
    service: 'PAP',
    date: '2099-09-10',
  });
  let s = await state(o);
  const [free] = open(s);
  const [entry] = waiting(s);
  await assert.rejects(
    act(o, { action: 'invite', id: free.id, candidate: 'nobody' }),
    /open slot and a waiting patient/,
  );
  await assert.rejects(
    act(o, { action: 'invite', id: 'nobody', candidate: entry.id }),
    /open slot and a waiting patient/,
  );
  await assert.rejects(
    act('clinic-other', { action: 'invite', id: free.id, candidate: entry.id }),
    /open slot and a waiting patient/,
  );
  const r = await act(o, {
    action: 'invite',
    id: free.id,
    candidate: entry.id,
  });
  assert.match(r.message, /not patient acceptance/);
  s = await state(o);
  const a = s.Appointment.find((x) => x.id === entry.id);
  assert.equal(a.status, 'pending', 'the same resource, now on the slot');
  assert.equal(slotRefOf(a), 'Slot/' + free.id);
  assert.equal(a.start, free.start);
  assert.ok(assignedAt(a), 'marked as assigned from standby');
  assert.match(bookingCode(a), /^[0-9A-F]{8}$/);
  assert.equal(
    requestedDay(a),
    '2099-09-10',
    'the day they waited for is kept',
  );
  assert.equal(a.participant.length, 3);
  assert.equal(s.Slot.find((x) => x.id === free.id).status, 'busy');
  assert.equal(waiting(s).length, 0);
  await assert.rejects(
    act(o, { action: 'invite', id: free.id, candidate: entry.id }),
    /open slot and a waiting patient/,
  );
  await assert.rejects(
    act(o, {
      action: 'standbyEdit',
      id: a.id,
      patient: beto,
      service: 'PAP',
      date: '',
    }),
    /already been booked into a slot/,
  );
  await assert.rejects(
    act(o, { action: 'standbyDelete', id: a.id }),
    /Select a standby entry/,
  );

  // Cancel: back to the waitlist, parked as released, slot open again.
  const c = await act(o, { action: 'cancel', id: a.id });
  assert.match(c.message, /back on the list as released/);
  s = await state(o);
  const parked = s.Appointment.find((x) => x.id === entry.id);
  assert.equal(parked.status, 'waitlist');
  assert.ok(releasedAt(parked));
  assert.equal(assignedAt(parked), null);
  assert.equal(parked.slot, undefined);
  assert.equal(parked.start, undefined);
  assert.equal(bookingCode(parked), null);
  assert.equal(parked.participant.length, 1);
  assert.equal(requestedDay(parked), '2099-09-10');
  assert.equal(s.Slot.find((x) => x.id === free.id).status, 'free');
  await assert.rejects(
    act(o, { action: 'invite', id: free.id, candidate: entry.id }),
    /open slot and a waiting patient/,
    'a released entry is not offered',
  );
  // Editing a released entry re-queues it.
  const e = await act(o, {
    action: 'standbyEdit',
    id: entry.id,
    patient: beto,
    service: 'PAP',
    date: '2099-09-10',
  });
  assert.match(e.message, /back on the list/);
  assert.equal(releasedAt(waiting(await state(o))[0]), null);
  // Assign again, then delete the appointment: the slot goes, the entry stays released.
  await act(o, { action: 'invite', id: free.id, candidate: entry.id });
  const d = await act(o, { action: 'appointmentDelete', id: entry.id });
  assert.match(d.message, /back on the list as released/);
  s = await state(o);
  assert.equal(s.Slot.length, 0);
  assert.equal(s.Appointment.find((x) => x.id === entry.id).status, 'waitlist');
  assert.ok(releasedAt(s.Appointment.find((x) => x.id === entry.id)));
  // An unreachable patient cannot be assigned.
  await act(o, slot(elena, { time: '15:00' }));
  await act(o, { action: 'cancel', id: live(await state(o))[0].id });
  await act(o, telegramCredentials);
  await assert.rejects(
    act(o, {
      action: 'invite',
      id: open(await state(o))[0].id,
      candidate: entry.id,
    }),
    /open slot and a waiting patient/,
    'a released entry stays out even after re-registration',
  );
});

test('confirmation is an AppointmentResponse; a new address or slot retires it', async () => {
  const o = 'clinic-confirm';
  const ids = await clinic(o, ['Fictional Mateo']);
  const mateo = ids['Fictional Mateo'];
  await act(o, slot(mateo));
  let [a] = live(await state(o));
  const code = bookingCode(a);
  const booked = await confirmAppointment(
    o,
    a,
    'Recorded by staff from reply C',
  );
  assert.equal(booked.status, 'booked');
  assert.equal(booked.participant[0].status, 'accepted');
  let s = await state(o);
  assert.equal(s.AppointmentResponse.length, 1);
  const r = s.AppointmentResponse[0];
  assert.equal(r.appointment.reference, 'Appointment/' + a.id);
  assert.equal(r.actor.reference, 'Patient/' + mateo);
  assert.equal(r.participantStatus, 'accepted');
  assert.equal(r.start, a.start);
  // A stale copy cannot confirm again.
  await assert.rejects(confirmAppointment(o, a, 'again'), /just changed/);
  // Changing the patient's address re-opens the question.
  await act(o, {
    action: 'contact',
    name: 'Team',
    phone: phoneA,
    consent: true,
  });
  await act(o, {
    action: 'patientEdit',
    id: mateo,
    name: 'Fictional Mateo',
    phone: phoneA,
    notes: '',
  });
  [a] = live(await state(o));
  assert.equal(a.status, 'booked', 'same address, nothing changes');
  assert.equal(bookingCode(a), code);
  // Twilio allows one recipient; re-registering the same number is not new,
  // so switch the number by re-registering under the limit is impossible —
  // use a fresh workspace on Telegram for the address change instead.
  const o2 = 'clinic-confirm-tg';
  owners.add(o2);
  await act(o2, telegramCredentials);
  await DB.prepare(
    "INSERT INTO contacts(id,owner,name,phone,consent) VALUES('t1',?,'A','-2001',1),('t2',?,'B','-2002',1)",
  )
    .bind(o2, o2)
    .run();
  await act(o2, { action: 'patient', name: 'Fictional Rosa', phone: '-2001' });
  const rosa = byName(await state(o2), 'Fictional Rosa').id;
  await act(o2, slot(rosa));
  let [b] = live(await state(o2));
  const code2 = bookingCode(b);
  await confirmAppointment(o2, b, 'test');
  const m = await act(o2, {
    action: 'patientEdit',
    id: rosa,
    name: 'Fictional Rosa',
    phone: '-2002',
    notes: '',
  });
  assert.match(m.message, /send a new reminder/);
  [b] = live(await state(o2));
  assert.equal(
    b.status,
    'pending',
    'the person at the new address never agreed',
  );
  assert.notEqual(bookingCode(b), code2);
  assert.equal(b.participant[0].status, 'needs-action');
  assert.equal(
    (await state(o2)).AppointmentResponse.length,
    1,
    'the old answer stays as history',
  );
});

test('giving up a slot for another day: a direct booking is cancelled and queued, an assignment is re-queued in place', async () => {
  const o = 'clinic-resched';
  const ids = await clinic(o, ['Fictional Elena', 'Fictional Beto']);
  const elena = ids['Fictional Elena'],
    beto = ids['Fictional Beto'];
  await act(o, slot(elena));
  let [a] = live(await state(o));
  let out = await releaseToStandby(o, a, '2099-09-25');
  assert.equal(out.released.status, 'cancelled');
  assert.equal(out.duplicate, false);
  assert.equal(out.queued.status, 'waitlist');
  assert.equal(requestedDay(out.queued), '2099-09-25');
  assert.equal(serviceOfAppointment(out.queued), 'PAP');
  let s = await state(o);
  assert.equal(open(s).length, 1);
  assert.equal(waiting(s).length, 1);
  // Same again with the same day already waiting: not duplicated.
  await act(o, slot(elena, { time: '11:00' }));
  [a] = live(await state(o));
  out = await releaseToStandby(o, a, '2099-09-25');
  assert.equal(out.duplicate, true);
  assert.equal(out.queued, null);
  assert.equal(waiting(await state(o)).length, 1);
  // An assignment re-queues the same entry for the new day, keeping its place.
  await act(o, {
    action: 'standby',
    patient: beto,
    service: 'PAP',
    date: '2099-09-10',
  });
  s = await state(o);
  const entry = waiting(s).find((x) => patientRefOf(x) === 'Patient/' + beto);
  await act(o, { action: 'invite', id: open(s)[0].id, candidate: entry.id });
  const assigned = (await state(o)).Appointment.find((x) => x.id === entry.id);
  out = await releaseToStandby(o, assigned, null);
  assert.equal(out.queued.id, entry.id, 'the same entry');
  assert.equal(out.queued.status, 'waitlist');
  assert.equal(requestedDay(out.queued), null, 'now for any day');
  assert.equal(releasedAt(out.queued), null, 'waiting, not parked');
  assert.equal(assignedAt(out.queued), null);
  assert.equal(out.queued.created, entry.created, 'same place in the queue');
  s = await state(o);
  assert.equal(open(s).length, 2);
  assert.equal(waiting(s).length, 2);
});

test('a patient with live bookings or standby entries cannot be removed; cancelled ones go with the record', async () => {
  const o = 'clinic-delete-2';
  const ids = await clinic(o, ['Fictional Camila']);
  const camila = ids['Fictional Camila'];
  await act(o, slot(camila));
  await assert.rejects(
    act(o, { action: 'patientDelete', id: camila }),
    /still has appointments/,
  );
  const [a] = live(await state(o));
  await act(o, { action: 'cancel', id: a.id });
  await act(o, { action: 'standby', patient: camila, service: 'PAP' });
  await assert.rejects(
    act(o, { action: 'patientDelete', id: camila }),
    /still has appointments/,
  );
  await act(o, { action: 'standbyDelete', id: waiting(await state(o))[0].id });
  await act(o, { action: 'patientDelete', id: camila });
  const s = await state(o);
  assert.equal(s.Patient.length, 0);
  assert.equal(
    s.Appointment.length,
    0,
    'the cancelled appointment went with the record',
  );
  assert.equal(open(s).length, 1, 'the open slot stays on the board');
});

test('twilio: fixed template, one reminder per code, replies recorded for staff review', async () => {
  const o = 'clinic-twilio';
  const ids = await clinic(o, ['Fictional Elena', 'Fictional Mateo']);
  const elena = ids['Fictional Elena'];
  await act(o, slot(elena));
  let [a] = live(await state(o));
  const code = bookingCode(a);
  await assert.rejects(act(o, { action: 'remind', id: a.id }), /Acknowledge/);
  await act(o, { action: 'remind', id: a.id, fixedTemplateAccepted: true });
  await assert.rejects(
    act(o, { action: 'remind', id: a.id, fixedTemplateAccepted: true }),
    /already been sent/,
    'pressing send again is refused, not silently swallowed',
  );
  assert.equal(fake.outgoing.length, 1, 'duplicate reminder is not sent');
  await assert.rejects(
    act(o, { action: 'remind', id: a.id, again: true }),
    /Acknowledge/,
  );
  await act(o, {
    action: 'remind',
    id: a.id,
    again: true,
    fixedTemplateAccepted: true,
  });
  assert.equal(fake.outgoing.length, 2, 'an explicit follow-up is sent');
  let s = await state(o);
  const first = byKey(s, `reminder:${a.id}:${code}`);
  const second = byKey(s, `reminder:${a.id}:${code}:2`);
  assert.ok(first && second, 'the follow-up has its own numbered key');
  assert.equal(
    first.id,
    `reminder.${a.id}.${code}`,
    'the key is the id, colons as dots',
  );
  assert.equal(first.status, 'in-progress');
  assert.equal(deliveryStatus(first), 'queued');
  assert.equal(providerSid(first), 'SM1');
  assert.equal(first.about[0].reference, 'Appointment/' + a.id);
  assert.equal(first.recipient[0].reference, 'Patient/' + elena);
  assert.equal(messageAddress(first), phoneA);
  assert.equal(
    first.extension.find((x) => x.url === EXT.address).valueContactPoint.system,
    'phone',
  );
  assert.deepEqual(Object.keys(fake.outgoing[0]).sort(), [
    'ContentSid',
    'From',
    'To',
  ]);
  assert.equal(fake.outgoing[0].ContentSid, 'HX' + 'c'.repeat(32));
  // The next sync asks Twilio how delivery went.
  await act(o, { action: 'sync' });
  s = await state(o);
  assert.equal(
    deliveryStatus(byKey(s, `reminder:${a.id}:${code}`)),
    'delivered',
  );
  assert.equal(byKey(s, `reminder:${a.id}:${code}`).status, 'completed');

  // Replies: recorded, and only a C from the right phone after the reminder counts.
  await whatsapp(o, phoneB, 'C');
  await assert.rejects(
    act(o, { action: 'confirm', id: a.id }),
    /Sync a \/confirm or C/,
  );
  await whatsapp(o, phoneA, 'R');
  assert.equal(live(await state(o))[0].status, 'pending', 'R never cancels');
  await assert.rejects(
    act(o, { action: 'confirm', id: a.id }),
    /Sync a \/confirm or C/,
  );
  await whatsapp(o, phoneA, 'C');
  s = await state(o);
  assert.equal(live(s)[0].status, 'pending', 'C waits for staff review');
  const c = inboundOf(s).find(
    (m) => messageBody(m) === 'C' && messageAddress(m) === phoneA,
  );
  assert.ok(c);
  assert.equal(c.status, 'completed');
  assert.equal(deliveryStatus(c), 'received');
  assert.ok(c.received);
  assert.equal(c.sent, undefined);
  const sentBeforeInquiry = fake.outgoing.length;
  await whatsapp(o, phoneA, '/cita');
  assert.equal(
    fake.outgoing.length,
    sentBeforeInquiry,
    'a fixed-template provider cannot answer /cita',
  );
  await act(o, { action: 'confirm', id: a.id });
  s = await state(o);
  assert.equal(live(s)[0].status, 'booked');
  assert.equal(s.AppointmentResponse.length, 1);
  assert.match(s.AppointmentResponse[0].comment, /Recorded by staff/);
  const count = s.Communication.length;
  await act(o, { action: 'sync' });
  assert.equal(
    (await state(o)).Communication.length,
    count,
    'inbound duplicates ignored',
  );
  assert.equal(
    fake.outgoing.length,
    sentBeforeInquiry,
    'no custom acknowledgement is sent',
  );

  // Assignment on Twilio is silent; the template is sent by hand.
  await act(o, {
    action: 'standby',
    patient: ids['Fictional Mateo'],
    service: 'PAP',
  });
  const w = waiting(await state(o))[0];
  await act(o, { action: 'cancel', id: a.id });
  const r = await act(o, {
    action: 'invite',
    id: open(await state(o))[0].id,
    candidate: w.id,
  });
  assert.match(r.message, /fixed template only/);
  assert.equal(
    fake.outgoing.length,
    sentBeforeInquiry,
    'cancellation and standby are website only',
  );
  [a] = live(await state(o));
  assert.ok(assignedAt(a));
  await assert.rejects(act(o, { action: 'confirm', id: a.id }), /Sync a/);

  // A definitive vendor rejection is recorded as failed and may be retried.
  await act(o, { action: 'cancel', id: a.id });
  await act(o, slot(elena, { time: '11:00' }));
  [a] = live(await state(o));
  fake.failSend = true;
  await assert.rejects(
    act(o, { action: 'remind', id: a.id, fixedTemplateAccepted: true }),
    /Twilio rejected/,
  );
  s = await state(o);
  const failed = byKey(s, `reminder:${a.id}:${bookingCode(a)}`);
  assert.equal(failed.status, 'not-done');
  assert.equal(deliveryStatus(failed), 'failed');
  assert.match(failed.statusReason.text, /Twilio rejected/);
  fake.failSend = false;
  const sends = fake.outgoing.length;
  await act(o, { action: 'remind', id: a.id, fixedTemplateAccepted: true });
  assert.equal(
    fake.outgoing.length,
    sends + 1,
    'explicit retry after definitive failure',
  );
  const retried = byKey(await state(o), `reminder:${a.id}:${bookingCode(a)}`);
  assert.equal(retried.status, 'in-progress');
  assert.equal(retried.statusReason, undefined);
  assert.equal(retried.id, failed.id, 'the same resource, claimed and retried');
  // Nothing secret reaches the browser.
  const secret = (
    await DB.prepare('SELECT secret FROM connections WHERE owner=?')
      .bind(o)
      .first()
  ).secret;
  assert.ok(!secret.includes('b'.repeat(32)));
  assert.ok(!JSON.stringify(await state(o)).includes(secret));
});

test('telegram: link by code, real details, standby notification, the three commands', async () => {
  const o = 'clinic-tg';
  const chat = '987654321';
  const eva = '555444333';
  const room = '-1001234567890';
  await act(o, telegramCredentials);
  assert.equal((await state(o)).connection.sender, '@carequeue_demo_bot');
  await assert.rejects(
    act(o, { action: 'contact', name: 'Team', phone: chat, consent: true }),
    /link code/,
  );
  const { code } = await act(o, { action: 'link', name: 'Team Telegram' });
  assert.match(code, /^[A-F0-9]{6}$/);
  await telegram(o, '111222333', 'hola');
  assert.equal((await state(o)).contacts.length, 0, 'no code, no contact');
  await telegram(o, chat, '/start ' + code);
  let s = await state(o);
  assert.equal(s.contacts.length, 1);
  assert.equal(s.contacts[0].phone, chat);
  assert.equal(s.connection.linkCode, null, 'the code is single-use');
  assert.equal(
    s.Communication.length,
    1,
    'the link message is on record, like any reply',
  );
  assert.equal(messageBody(s.Communication[0]), '/start ' + code);
  // A second chat and a group, which Telegram addresses as /start@bot.
  const second = await act(o, { action: 'link', name: 'Second device' });
  await telegram(o, eva, '/start ' + second.code);
  const third = await act(o, { action: 'link', name: 'Room 3' });
  await telegram(o, room, '/start@carequeue_demo_bot ' + third.code, {
    title: 'Room 3 group',
  });
  assert.equal(
    (await state(o)).contacts.length,
    3,
    'telegram declares no recipient cap',
  );

  await act(o, { action: 'patient', name: 'Fictional Camila', phone: chat });
  await act(o, { action: 'patient', name: 'Fictional Eva', phone: eva });
  s = await state(o);
  const camila = byName(s, 'Fictional Camila').id;
  const evaId = byName(s, 'Fictional Eva').id;
  const book = (patient, date, time, service, extra = {}) =>
    act(o, {
      action: 'appointment',
      patient,
      date,
      time,
      clinician: 'Dra. Soto',
      service,
      location: 'Sala 2',
      ...extra,
    });
  await book(camila, '2099-09-11', '09:30', 'Control prenatal');
  let [a] = live(await state(o));
  // No fixed template: no acknowledgement gate, and real details go out.
  await act(o, { action: 'remind', id: a.id });
  assert.equal(fake.tgSent.length, 1);
  assert.equal(fake.tgSent[0].chat_id, chat);
  assert.match(fake.tgSent[0].text, /2099-09-11 at 09:30/);
  assert.match(fake.tgSent[0].text, /Control prenatal with Dra\. Soto/);
  assert.match(fake.tgSent[0].text, /Fictional Camila/);
  s = await state(o);
  const reminder = byKey(s, `reminder:${a.id}:${bookingCode(a)}`);
  assert.equal(reminder.status, 'completed', 'Telegram accepts synchronously');
  assert.equal(deliveryStatus(reminder), 'delivered');
  assert.equal(messageAddress(reminder), chat);
  assert.equal(
    reminder.extension.find((x) => x.url === EXT.address).valueContactPoint
      .system,
    'other',
  );
  await assert.rejects(
    act(o, { action: 'remind', id: a.id }),
    /already been sent/,
  );
  await act(o, { action: 'remind', id: a.id, again: true });
  assert.equal(fake.tgSent.length, 2);
  // A plain C is recorded and waits for staff.
  await telegram(o, chat, 'C');
  assert.equal(live(await state(o))[0].status, 'pending');
  await act(o, { action: 'confirm', id: a.id });
  assert.equal(live(await state(o))[0].status, 'booked');
  const before = (await state(o)).Communication.length;
  await act(o, { action: 'sync' });
  assert.equal(
    (await state(o)).Communication.length,
    before,
    'offset advanced',
  );

  // Assignment from standby notifies the standby patient's chat.
  await act(o, {
    action: 'standby',
    patient: evaId,
    service: 'Control prenatal',
  });
  await act(o, { action: 'cancel', id: a.id });
  let entry = waiting(await state(o))[0];
  const r = await act(o, {
    action: 'invite',
    id: open(await state(o))[0].id,
    candidate: entry.id,
  });
  assert.match(r.message, /notified/);
  assert.equal(fake.tgSent.at(-1).chat_id, eva);
  assert.match(fake.tgSent.at(-1).text, /assigned to you, Fictional Eva/);
  assert.match(fake.tgSent.at(-1).text, /2099-09-11 at 09:30/);
  s = await state(o);
  a = s.Appointment.find((x) => x.id === entry.id);
  assert.equal(a.status, 'pending', 'notification does not confirm');
  const notice = byKey(s, `reminder:${a.id}:${bookingCode(a)}`);
  assert.ok(notice, 'the notification is the reminder for this code');
  assert.ok(notice.category.some((c) => c.coding[0].code === 'standby'));
  await assert.rejects(
    act(o, { action: 'remind', id: a.id }),
    /already been sent/,
    'so a reminder is a follow-up now',
  );
  await assert.rejects(act(o, { action: 'confirm', id: a.id }), /Sync a/);
  await telegram(o, eva, 'C');
  await act(o, { action: 'confirm', id: a.id });
  assert.equal(
    (await state(o)).Appointment.find((x) => x.id === a.id).status,
    'booked',
  );

  // "/cita": what this chat's patients have, read-only, once per message.
  await book(camila, '2099-09-24', '10:30', 'Control prenatal');
  await act(o, {
    action: 'standby',
    patient: camila,
    service: 'PAP',
    date: '2099-09-22',
  });
  const snapshot = (st) =>
    JSON.stringify(st.Appointment.map((x) => [x.id, x.status, bookingCode(x)]));
  const snapshotBefore = snapshot(await state(o));
  let sent = fake.tgSent.length;
  const citaSid = await telegram(o, chat, '/cita');
  assert.equal(fake.tgSent.length, sent + 1, 'one reply to /cita');
  const answer = fake.tgSent.at(-1);
  assert.equal(answer.chat_id, chat);
  assert.match(answer.text, /Hola Fictional Camila\./);
  assert.match(answer.text, /jue 24 sept, 10:30 — Control prenatal/);
  assert.match(answer.text, /Dra\. Soto · Sala 2 · pendiente de confirmar/);
  assert.match(answer.text, /Lista de espera: PAP \(mar 22 sept\)/);
  assert.match(answer.text, /demostración con datos ficticios/);
  s = await state(o);
  assert.equal(snapshot(s), snapshotBefore, 'an inquiry changes no booking');
  const inquiry = byKey(s, 'inquiry:' + citaSid);
  assert.ok(inquiry, 'the reply is recorded under the inbound message id');
  assert.equal(
    inquiry.inResponseTo[0].reference,
    'Communication/inbound.' + citaSid.replace(':', '.'),
  );
  assert.ok(
    s.Communication.some(
      (c) => c.id === 'inbound.' + citaSid.replace(':', '.'),
    ),
  );
  await telegram(o, chat, '/cita@carequeue_demo_bot');
  assert.equal(fake.tgSent.length, sent + 2, '/cita@bot is answered too');
  await telegram(o, room, '/cita', { title: 'Room 3 group' });
  assert.match(
    fake.tgSent.at(-1).text,
    /No encontramos un registro para este chat/,
  );

  // "/confirm": the one slot waiting, and it says so.
  const camilaSlot = live(await state(o)).find(
    (x) => patientRefOf(x) === 'Patient/' + camila && x.status === 'pending',
  );
  await act(o, { action: 'remind', id: camilaSlot.id });
  sent = fake.tgSent.length;
  const confirmSid = await telegram(o, chat, '/confirm');
  s = await state(o);
  assert.equal(
    s.Appointment.find((x) => x.id === camilaSlot.id).status,
    'booked',
    '/confirm confirms without staff',
  );
  assert.equal(fake.tgSent.length, sent + 1, 'one acknowledgement');
  assert.match(
    fake.tgSent.at(-1).text,
    /Confirmado\. Te esperamos el jue 24 sept a las 10:30/,
  );
  const ack = byKey(s, 'ack:' + confirmSid);
  assert.ok(ack);
  assert.equal(ack.about[0].reference, 'Appointment/' + camilaSlot.id);
  const response = s.AppointmentResponse.find(
    (x) => x.appointment.reference === 'Appointment/' + camilaSlot.id,
  );
  assert.match(response.comment, /\/confirm/);
  // Again: told it is already confirmed, with the slot named.
  await telegram(o, chat, '/confirm');
  assert.match(
    fake.tgSent.at(-1).text,
    /Tu hora ya está confirmada: jue 24 sept a las 10:30 \(Control prenatal\)/,
  );
  // Two waiting: ambiguous, nothing changes, staff can still resolve it.
  await book(camila, '2099-09-21', '11:00', 'PAP');
  await book(camila, '2099-09-21', '12:00', 'Climaterio');
  const pair = live(await state(o)).filter((x) =>
    x.start.startsWith('2099-09-21'),
  );
  for (const x of pair) await act(o, { action: 'remind', id: x.id });
  await telegram(o, chat, '/confirm@carequeue_demo_bot');
  s = await state(o);
  assert.deepEqual(
    pair.map((x) => s.Appointment.find((y) => y.id === x.id).status),
    ['pending', 'pending'],
  );
  assert.match(fake.tgSent.at(-1).text, /más de una hora pendiente/);
  await act(o, { action: 'confirm', id: pair[0].id });
  assert.equal(
    (await state(o)).Appointment.find((y) => y.id === pair[0].id).status,
    'booked',
  );
  // A /confirm older than the reminder is not a confirmation of it.
  await book(camila, '2099-09-23', '09:00', 'PAP');
  const late = live(await state(o)).find((x) =>
    x.start.startsWith('2099-09-23'),
  );
  await act(o, { action: 'remind', id: late.id });
  await telegram(o, chat, '/confirm', { ago: 120 });
  assert.equal(
    (await state(o)).Appointment.find((y) => y.id === late.id).status,
    'pending',
  );
  await telegram(o, room, '/confirm', { title: 'Room 3 group' });
  assert.match(fake.tgSent.at(-1).text, /No tienes una hora pendiente/);

  // "/reschedule <day>": with two live appointments on the chat it is left
  // to staff; with one, the patient is moved into the earliest free start
  // of that day with their clinician, or queued for it if it is full.
  await book(evaId, '2099-09-23', '10:00', 'PAP');
  const toMove = live(await state(o)).find(
    (x) =>
      patientRefOf(x) === 'Patient/' + evaId &&
      x.start.startsWith('2099-09-23'),
  );
  await telegram(o, eva, '/reschedule 25/09/2099');
  assert.match(fake.tgSent.at(-1).text, /más de una hora agendada/);
  assert.equal(
    (await state(o)).Appointment.find((x) => x.id === toMove.id).status,
    'pending',
  );
  await act(o, { action: 'appointmentDelete', id: a.id });
  assert.equal(
    (await state(o)).Appointment.find((x) => x.id === a.id).status,
    'waitlist',
    'the assigned entry is parked, not gone',
  );
  const othersBefore = snapshot({
    Appointment: (await state(o)).Appointment.filter((x) => x.id !== toMove.id),
  });
  const oldCode = bookingCode(toMove);
  const oldSlot = slotRefOf(toMove);
  // Friday the 25th is a clinic day with nothing on Dra. Soto's timetable
  // in Sala 2: moved to its first start, pending, asked to confirm.
  const movedSid = await telegram(o, eva, '/reschedule 25/09/2099');
  s = await state(o);
  let mv = s.Appointment.find((x) => x.id === toMove.id);
  assert.equal(mv.status, 'pending', 'moved, awaiting confirmation');
  assert.equal(mv.start, '2099-09-25T08:00:00-03:00', 'the earliest start');
  assert.notEqual(bookingCode(mv), oldCode, 'a fresh code');
  assert.notEqual(slotRefOf(mv), oldSlot);
  assert.equal(mv.participant[0].status, 'needs-action');
  assert.ok(
    open(s).some((x) => 'Slot/' + x.id === oldSlot),
    'the old slot is back on the board as open',
  );
  assert.equal(
    s.Slot.find((x) => 'Slot/' + x.id === slotRefOf(mv)).status,
    'busy',
  );
  assert.match(
    fake.tgSent.at(-1).text,
    /Listo\. Te cambiamos al vie 25 sept a las 08:00 \(PAP, Dra\. Soto, Sala 2\)\. Responde \/confirm/,
  );
  const moveNote = byKey(s, `reminder:${mv.id}:${bookingCode(mv)}`);
  assert.ok(moveNote, 'the answer is the reminder for the new code');
  assert.ok(moveNote.category.some((c) => c.coding[0].code === 'reschedule'));
  assert.equal(
    moveNote.inResponseTo[0].reference,
    'Communication/inbound.' + movedSid.replace(':', '.'),
  );
  assert.equal(
    snapshot({
      Appointment: s.Appointment.filter((x) => x.id !== toMove.id),
    }),
    othersBefore,
    'no other booking changed',
  );
  // …so a /confirm now confirms the new time.
  await telegram(o, eva, '/confirm');
  assert.match(
    fake.tgSent.at(-1).text,
    /Confirmado\. Te esperamos el vie 25 sept a las 08:00/,
  );
  assert.equal(
    (await state(o)).Appointment.find((x) => x.id === toMove.id).status,
    'booked',
  );
  // Without a day: asked, and the question stays open through answers the
  // centre cannot use — a closed day, "any day", something unreadable —
  // and through a /cita in between.
  await telegram(o, eva, '/reschedule');
  assert.match(
    fake.tgSent.at(-1).text,
    /¿Para qué día quieres cambiar tu hora\? Responde con la fecha en formato día\/mes\./,
  );
  await telegram(o, eva, '26/09/2099');
  assert.match(fake.tgSent.at(-1).text, /El centro no atiende el sáb 26 sept/);
  await telegram(o, eva, 'cualquier día');
  assert.match(fake.tgSent.at(-1).text, /Necesitamos un día concreto/);
  await telegram(o, eva, '/cita');
  assert.match(
    fake.tgSent.at(-1).text,
    /Hola Fictional Eva\./,
    '/cita in the middle is /cita',
  );
  await telegram(o, eva, 'el martes');
  assert.match(fake.tgSent.at(-1).text, /No entendí la fecha/);
  assert.equal(
    (await state(o)).Appointment.find((x) => x.id === toMove.id).status,
    'booked',
    'nothing moved yet',
  );
  // Wednesday the 30th, filled by staff: full, so the day completes the
  // reschedule by releasing the slot and queueing for that day.
  for (const time of gridTimes('2099-09-30'))
    await book(camila, '2099-09-30', time, 'PAP');
  const waitingBefore = waiting(await state(o)).length;
  const fullSid = await telegram(o, eva, '30/09/2099');
  s = await state(o);
  mv = s.Appointment.find((x) => x.id === toMove.id);
  assert.equal(mv.status, 'cancelled', 'a direct booking is cancelled');
  assert.ok(
    open(s).some(
      (x) =>
        'Slot/' + x.id === slotRefOf(toMove) ||
        'Slot/' + x.id === slotRefOf(mv),
    ),
  );
  const queued = waiting(s).find(
    (x) =>
      patientRefOf(x) === 'Patient/' + evaId &&
      requestedDay(x) === '2099-09-30',
  );
  assert.ok(queued, 'queued for the full day with the slot service');
  assert.equal(serviceOfAppointment(queued), 'PAP');
  assert.equal(waiting(s).length, waitingBefore + 1);
  assert.match(
    fake.tgSent.at(-1).text,
    /El mié 30 sept ya está lleno\. Liberamos tu hora del vie 25 sept a las 08:00 y quedas en lista de espera para PAP ese día/,
  );
  assert.equal(
    byKey(s, 'resched:' + fullSid).about[0].reference,
    'Appointment/' + toMove.id,
  );
  // The question is spent: a later plain day is not an answer.
  sent = fake.tgSent.length;
  await telegram(o, eva, '25/09');
  assert.equal(fake.tgSent.length, sent, 'the question is spent');
  await telegram(o, room, '/reschedule 25/09/2099', { title: 'Room 3 group' });
  assert.match(fake.tgSent.at(-1).text, /No tienes una hora que reagendar/);
  // An assignment from standby moves the same way, keeping its marks; and
  // when the day it asks for is full it goes back to waiting in place.
  const evaEntry = queued;
  const anOpen = open(await state(o)).find((x) =>
    x.start.startsWith('2099-09-25'),
  );
  await act(o, { action: 'invite', id: anOpen.id, candidate: evaEntry.id });
  await telegram(o, eva, '/reschedule 02/10/2099');
  s = await state(o);
  let assigned = s.Appointment.find((x) => x.id === evaEntry.id);
  assert.equal(assigned.status, 'pending');
  assert.equal(
    assigned.start,
    '2099-10-02T08:00:00-03:00',
    'moved to Friday 2 Oct',
  );
  assert.ok(assignedAt(assigned), 'still marked as assigned from standby');
  assert.equal(
    requestedDay(assigned),
    '2099-09-30',
    'the day it waited for is kept',
  );
  assert.equal(s.Slot.find((x) => x.id === anOpen.id).status, 'free');
  await telegram(o, eva, '/reschedule 30/09/2099');
  s = await state(o);
  assigned = s.Appointment.find((x) => x.id === evaEntry.id);
  assert.equal(assigned.status, 'waitlist', 'full day: back on the list');
  assert.equal(requestedDay(assigned), '2099-09-30');
  assert.equal(assigned.created, evaEntry.created, 'same place in the queue');
  assert.equal(releasedAt(assigned), null);
  assert.match(fake.tgSent.at(-1).text, /El mié 30 sept ya está lleno/);
  // A chat that was never linked gets nothing.
  sent = fake.tgSent.length;
  await telegram(o, '999888777', '/cita');
  assert.equal(fake.tgSent.length, sent, 'strangers are not answered');
  assert.equal(
    fake.outgoing.length,
    0 + fake.outgoing.length,
    'the Twilio fake was never used here',
  );
  // Message history is a hundred at most, newest first, every one an R4 Communication.
  const list = (await state(o)).Communication;
  assert.ok(list.length > 10);
  for (let i = 1; i < list.length; i++)
    assert.ok(
      Date.parse(list[i - 1].sent ?? list[i - 1].received) >=
        Date.parse(list[i].sent ?? list[i].received),
    );
});

test('the interface reads rows derived from the resources, ids unchanged', async () => {
  const o = 'clinic-view';
  const ids = await clinic(o, ['Fictional Elena', 'Fictional Beto']);
  const elena = ids['Fictional Elena'],
    beto = ids['Fictional Beto'];
  await act(o, slot(elena));
  await act(o, slot(elena, { time: '11:00', service: 'Dental' }));
  await act(o, {
    action: 'standby',
    patient: beto,
    service: 'PAP',
    date: '2099-09-10',
  });
  await act(o, { action: 'standby', patient: beto, service: 'Dental' });
  let [a, b] = live(await state(o));
  await act(o, { action: 'cancel', id: a.id });
  await act(o, { action: 'remind', id: b.id, fixedTemplateAccepted: true });
  let s = await state(o);
  let v = project(s);
  assert.deepEqual(
    v.patients.map((p) => [p.name, p.phone, !!p.consent]),
    [
      ['Fictional Beto', phoneA, true],
      ['Fictional Elena', phoneA, true],
    ],
  );
  // Two appointment rows: the cancelled booking and its now-open slot are
  // two rows (the slot by its own id), the live booking one.
  assert.deepEqual(
    v.appointments.map((r) => [
      r.kind,
      r.status,
      r.name,
      r.time,
      r.clinician,
      r.location,
      r.service,
    ]),
    [
      [
        'appointment',
        'cancelled',
        'Fictional Elena',
        '10:00',
        'Dr Demo',
        'Demo Room',
        'PAP',
      ],
      ['slot', 'open', null, '10:00', 'Dr Demo', 'Demo Room', 'PAP'],
      [
        'appointment',
        'scheduled',
        'Fictional Elena',
        '11:00',
        'Dr Demo',
        'Demo Room',
        'Dental',
      ],
    ],
  );
  const openRow = v.appointments.find((r) => r.kind === 'slot');
  assert.equal('Slot/' + openRow.id, slotRefOf(a));
  const liveRow = v.appointments.find((r) => r.status === 'scheduled');
  assert.equal(liveRow.id, b.id);
  assert.equal(liveRow.code, bookingCode(b));
  assert.equal(liveRow.phone, phoneA);
  assert.equal(liveRow.date, '2099-09-10');
  assert.deepEqual(
    v.standby.map((w) => [w.name, w.service, w.date, w.status, w.booking]),
    [
      ['Fictional Beto', 'PAP', '2099-09-10', 'waiting', null],
      ['Fictional Beto', 'Dental', null, 'waiting', null],
    ],
  );
  const reminder = v.messages.find(
    (m) => m.key === `reminder:${b.id}:${bookingCode(b)}`,
  );
  assert.ok(reminder);
  assert.equal(reminder.direction, 'outbound');
  assert.equal(reminder.status, 'queued');
  assert.equal(reminder.phone, phoneA);
  assert.equal(reminder.about, 'Appointment/' + b.id);
  assert.ok(reminder.created > 0);
  // Assign: the standby row becomes booked and points at itself as the booking.
  const entry = waiting(s).find((x) => requestedDay(x) === '2099-09-10');
  await act(o, { action: 'invite', id: openRow.id, candidate: entry.id });
  v = project(await state(o));
  assert.deepEqual(
    v.standby.map((w) => [w.service, w.status, w.booking]),
    [
      ['PAP', 'booked', entry.id],
      ['Dental', 'waiting', null],
    ],
  );
  assert.equal(v.appointments.find((r) => r.id === entry.id).status, 'filled');
  assert.equal(
    v.appointments.filter((r) => r.kind === 'slot').length,
    0,
    'the slot is no longer open',
  );
});

test('the timetable: clinic days, the half-hour grid, and what staff may book', async () => {
  assert.equal(hoursLabel(), 'Mon–Fri 08:00–17:00');
  assert.deepEqual(gridTimes('2099-09-26'), [], 'Saturday is closed');
  const thursday = gridTimes('2099-09-10');
  assert.equal(thursday.length, 18);
  assert.equal(thursday[0], '08:00');
  assert.equal(thursday.at(-1), '16:30');
  const o = 'clinic-timetable';
  const { 'Fictional Rosa': rosa } = await clinic(o, ['Fictional Rosa']);
  await assert.rejects(
    act(o, slot(rosa, { date: '2099-09-26' })),
    /does not see patients on that day/,
  );
  await assert.rejects(
    act(o, slot(rosa, { time: '10:15' })),
    /slot start on the timetable/,
  );
  await assert.rejects(
    act(o, slot(rosa, { time: '17:00' })),
    /slot start on the timetable/,
  );
  await assert.rejects(
    act(o, slot(rosa, { time: '07:30' })),
    /slot start on the timetable/,
  );
  await act(o, slot(rosa, { time: '16:30' }));
  await act(o, slot(rosa, { time: '08:00' }));
  const [a] = live(await state(o));
  await assert.rejects(
    act(o, {
      action: 'update',
      id: a.id,
      patient: rosa,
      date: '2099-09-10',
      time: '08:15',
      clinician: 'Dr Demo',
      service: 'PAP',
      location: 'Demo Room',
    }),
    /slot start on the timetable/,
  );
  // The booking form's view of that clinician's day.
  const b = await state(o);
  const day = availability(b, 'Dr Demo', 'Demo Room', '2099-09-10');
  assert.equal(day.length, 18);
  assert.deepEqual(
    day.filter((x) => x.taken).map((x) => x.time),
    ['08:00', '16:30'],
  );
  assert.deepEqual(availability(b, 'Dr Demo', 'Demo Room', '2099-09-26'), []);
  assert.ok(
    availability(b, 'Dr Demo', 'Other Room', '2099-09-10').every(
      (x) => !x.taken,
    ),
    'another room is free',
  );
  assert.ok(
    availability(b, 'Nobody', 'Demo Room', '2099-09-10').every((x) => !x.taken),
    'an unknown clinician has nothing booked',
  );
  // A slot freed by a cancellation is not taken.
  await act(o, { action: 'cancel', id: a.id });
  assert.deepEqual(
    availability(await state(o), 'Dr Demo', 'Demo Room', '2099-09-10')
      .filter((x) => x.taken)
      .map((x) => x.time),
    [a.start.slice(11, 16) === '08:00' ? '16:30' : '08:00'],
  );
});

test("rebook: the earliest free start on the clinician's day, reusing a freed slot, or null when full", async () => {
  const { rebook } = await loadTs('lib/fhir/scheduling.ts', stubs);
  const o = 'clinic-rebook';
  const ids = await clinic(o, ['Fictional Elena', 'Fictional Mateo']);
  const elena = ids['Fictional Elena'],
    mateo = ids['Fictional Mateo'];
  // Friday 11 Sept: 08:00 taken by Mateo, 08:30 freed by a cancellation.
  await act(o, slot(mateo, { date: '2099-09-11', time: '08:00' }));
  await act(o, slot(mateo, { date: '2099-09-11', time: '08:30' }));
  const freed = live(await state(o)).find((x) => x.start.includes('08:30'));
  await act(o, { action: 'cancel', id: freed.id });
  const freedSlot = slotRefOf(freed);
  await act(o, slot(elena));
  let [a] = live(await state(o)).filter(
    (x) => patientRefOf(x) === 'Patient/' + elena,
  );
  const r = await rebook(o, a, '2099-09-11');
  assert.equal(
    r.appointment.start,
    '2099-09-11T08:30:00-03:00',
    'the freed slot, not a new 09:00',
  );
  assert.equal('Slot/' + r.slot.id, freedSlot, 'reused');
  assert.equal(r.slot.status, 'busy');
  let s = await state(o);
  assert.equal(
    s.Slot.filter((x) => x.start.startsWith('2099-09-11')).length,
    2,
    'no slot was added',
  );
  assert.equal(open(s).length, 1, 'the slot she left is open');
  // Fill Friday; then there is nowhere to go.
  a = s.Appointment.find((x) => x.id === a.id);
  for (const time of gridTimes('2099-09-11').slice(2))
    await act(o, slot(mateo, { date: '2099-09-11', time }));
  await act(o, {
    action: 'update',
    id: a.id,
    patient: elena,
    date: '2099-09-10',
    time: '10:00',
    clinician: 'Dr Demo',
    service: 'PAP',
    location: 'Demo Room',
  });
  // Moving her off Friday removed her slot there, so 08:30 is open again
  // on the grid until Mateo takes it.
  a = (await state(o)).Appointment.find((x) => x.id === a.id);
  assert.equal(
    (await rebook(o, a, '2099-09-11')).appointment.start,
    '2099-09-11T08:30:00-03:00',
  );
  await act(o, {
    action: 'update',
    id: a.id,
    patient: elena,
    date: '2099-09-10',
    time: '10:00',
    clinician: 'Dr Demo',
    service: 'PAP',
    location: 'Demo Room',
  });
  await act(o, slot(mateo, { date: '2099-09-11', time: '08:30' }));
  a = (await state(o)).Appointment.find((x) => x.id === a.id);
  assert.equal(await rebook(o, a, '2099-09-11'), null, 'Friday is full');
  assert.equal(await rebook(o, a, '2099-09-12'), null, 'Saturday has no slots');
  // Another room is another timetable.
  await act(o, {
    action: 'update',
    id: a.id,
    patient: elena,
    date: '2099-09-10',
    time: '10:00',
    clinician: 'Dr Demo',
    service: 'PAP',
    location: 'Room B',
  });
  a = (await state(o)).Appointment.find((x) => x.id === a.id);
  const rb = await rebook(o, a, '2099-09-11');
  assert.equal(rb.appointment.start, '2099-09-11T08:00:00-03:00');
});

test('a Bundle from another system comes in: new ids, references rewritten, the rest reported', async () => {
  const o = 'clinic-import';
  owners.add(o);
  // Dr Careful already works here: the import must not make a second one.
  const careful = await practitionerOf(o, 'Adam Careful');
  const input = hospitalBundle();
  // The file is valid R4 apart from the one entry meant to be refused.
  assertFhir({
    ...input,
    entry: input.entry.filter((e) => e.resource.id !== 'bad-status'),
  });
  const report = await importBundle(o, input);
  assert.deepEqual(report.imported, {
    Practitioner: 1,
    Location: 1,
    HealthcareService: 1,
    Patient: 2,
    Consent: 1,
    Schedule: 1,
    Slot: 2,
    Appointment: 4,
    AppointmentResponse: 1,
  });
  assert.deepEqual(
    report.matched,
    { Practitioner: 1 },
    'Adam Careful was already here',
  );
  const why = Object.fromEntries(
    report.skipped.map((x) => [`${x.type}/${x.id}`, x.reason]),
  );
  assert.match(
    why['Observation/example'],
    /not a resource type this system holds/,
  );
  assert.match(why['Encounter/example'], /not a resource type/);
  assert.match(why['Patient/nameless'], /has no name/);
  assert.match(why['Appointment/orphan'], /patient is not in the bundle/);
  assert.match(
    why['Appointment/bad-status'],
    /status must be one of proposed, pending/,
  );
  assert.equal(report.skipped.length, 5);

  const s = await state(o);
  assert.equal(
    s.Practitioner.length,
    2,
    'Adam Careful was matched, Ana Nueva added',
  );
  const nueva = s.Practitioner.find((p) => p.id !== careful.id);
  assert.equal(
    nueva.name[0].text,
    'Ana Nueva',
    'a text is added to a name given in parts',
  );
  assert.deepEqual(nueva.name[0].given, ['Ana'], 'the parts stay');
  assert.ok(
    s.Patient.every((p) => p.id !== 'example' && p.id !== 'pat2'),
    'no id came along',
  );
  assert.ok(
    !JSON.stringify(s).includes('urn:uuid:'),
    'no reference points outside',
  );
  assert.ok(
    !JSON.stringify(s).includes('Organization/'),
    'references to what was not imported are dropped',
  );
  const peter = s.Patient.find(
    (p) => patientName(p) === 'Peter James Chalmers',
  );
  assert.ok(peter, 'named from given and family');
  assert.equal(
    patientRecord(peter),
    '12345',
    'the MRN stands as the record number',
  );
  assert.equal(peter.birthDate, '1974-12-25', 'what came with it stays');
  assert.equal(peter.text, undefined, 'the narrative does not');
  assert.equal(peter.meta.versionId, '1', 'ours, not theirs');
  const duck = s.Patient.find((p) => patientName(p) === 'Duck D Donald');
  assert.match(
    patientRecord(duck),
    /^P-[0-9A-F]{4}$/,
    'a record number is issued when none came',
  );
  assert.equal(s.Consent[0].patient.reference, 'Patient/' + peter.id);
  // The booked appointment holds the slot it named; the pending one got a
  // slot held for it on its clinician's schedule; the free slot is open.
  const rows = project(s);
  const booked = rows.appointments.find((r) => r.status === 'confirmed');
  assert.equal(booked.name, 'Peter James Chalmers');
  assert.equal(booked.clinician, 'Adam Careful');
  assert.equal(booked.location, 'South Wing, second floor');
  assert.equal(
    booked.service,
    'General medical practice',
    'a SNOMED display reads as the service',
  );
  assert.equal(booked.date + ' ' + booked.time, '2099-10-06 10:00');
  assert.match(booked.code, /^[0-9A-F]{8}$/, 'a booking code of ours');
  assert.equal(booked.responses, 1);
  const pending = rows.appointments.find((r) => r.status === 'scheduled');
  assert.equal(pending.name, 'Duck D Donald');
  assert.equal(pending.clinician, 'Ana Nueva');
  assert.equal(pending.date + ' ' + pending.time, '2099-10-07 11:00');
  assert.equal(
    s.Slot.length,
    3,
    'two from the bundle, one held for the pending appointment',
  );
  assert.deepEqual(
    rows.appointments.filter((r) => r.kind === 'slot').map((r) => r.time),
    ['09:00'],
  );
  const history = rows.appointments.find((r) => r.status === 'fulfilled');
  assert.equal(history.date, '2025-03-03');
  assert.equal(history.location, '', 'history needs no room');
  assert.deepEqual(
    rows.standby.map((w) => [w.name, w.service, w.date]),
    [['Peter James Chalmers', 'PAP', '2099-10-10']],
  );
  // Nobody imported is reachable until staff point them at a registered device.
  assert.match(await unreachable(o, peter), /not a registered recipient/);
  // The same file again: a patient with an identifier is recognised, one
  // without cannot be; the slots and bookings are already taken; the
  // standby entry is already waiting.
  const again = await importBundle(o, hospitalBundle());
  assert.deepEqual(again.matched, {
    Practitioner: 2,
    Location: 1,
    HealthcareService: 1,
    Patient: 1,
    Schedule: 1,
  });
  assert.equal(again.imported.Patient, 1, 'Duck, who has no identifier');
  assert.equal(again.imported.Practitioner, undefined);
  assert.equal(again.imported.Slot, undefined);
  assert.equal(again.imported.Appointment, 1, 'only the history entry again');
  const reasons = again.skipped.map((x) => `${x.type}/${x.id}: ${x.reason}`);
  assert.ok(
    reasons.some((r) => r.startsWith('Slot/slot-free: collides')),
    reasons.join('\n'),
  );
  assert.ok(
    reasons.some((r) =>
      /^Appointment\/example: .*already has an appointment slot/.test(r),
    ),
  );
  assert.ok(
    reasons.some((r) => /^Appointment\/waiting: is already waiting/.test(r)),
  );
  assert.ok(
    reasons.some((r) => /^Consent\/consent-1/.test(r)) === false,
    'a second consent for Peter is allowed',
  );
  assert.equal((await state(o)).Practitioner.length, 2);
  assert.equal((await state(o)).Patient.length, 3);
});

test('export is a collection Bundle of the clinical resources, and imports back into another workspace', async () => {
  const o = 'clinic-export';
  const ids = await clinic(o, ['Fictional Elena', 'Fictional Beto']);
  await act(o, slot(ids['Fictional Elena']));
  await act(
    o,
    slot(ids['Fictional Beto'], { time: '11:00', service: 'Dental' }),
  );
  await act(o, {
    action: 'standby',
    patient: ids['Fictional Beto'],
    service: 'PAP',
    date: '2099-09-11',
  });
  let [a] = live(await state(o));
  await act(o, { action: 'remind', id: a.id, fixedTemplateAccepted: true });
  await act(o, { action: 'confirm', id: a.id }).catch(() => {});
  await confirmAppointment(
    o,
    (await state(o)).Appointment.find((x) => x.id === a.id),
    'test',
  );
  const bundle = await exportBundle(o);
  assertFhir(bundle);
  assert.equal(bundle.type, 'collection');
  assert.ok(bundle.timestamp);
  const types = bundle.entry.map((e) => e.resource.resourceType);
  assert.ok(!types.includes('Communication'), 'messages stay home');
  const count = (t) => types.filter((x) => x === t).length;
  assert.equal(count('Patient'), 2);
  assert.equal(count('Consent'), 2);
  assert.equal(count('Appointment'), 3);
  assert.equal(count('Slot'), 2);
  assert.equal(count('AppointmentResponse'), 1);
  assert.ok(
    bundle.entry.every((e) =>
      e.fullUrl.endsWith(`/${e.resource.resourceType}/${e.resource.id}`),
    ),
  );
  // Into an empty workspace, through the same JSON a file would carry.
  const o2 = 'clinic-export-2';
  owners.add(o2);
  const report = await importBundle(o2, JSON.parse(JSON.stringify(bundle)));
  assert.deepEqual(report.skipped, []);
  assert.deepEqual(report.matched, {});
  assert.deepEqual(report.imported, {
    Patient: 2,
    Consent: 2,
    Practitioner: 1,
    Location: 1,
    HealthcareService: 2,
    Schedule: 1,
    Slot: 2,
    Appointment: 3,
    AppointmentResponse: 1,
  });
  const before = project(await state(o));
  const after = project(await state(o2));
  const shape = (v) => ({
    patients: v.patients.map((p) => [p.name, p.phone]),
    appointments: v.appointments.map((r) => [
      r.kind,
      r.status,
      r.name,
      r.date,
      r.time,
      r.clinician,
      r.location,
      r.service,
    ]),
    standby: v.standby.map((w) => [w.name, w.service, w.date, w.status]),
  });
  assert.deepEqual(shape(after), shape(before));
  assert.ok(
    after.patients.every((p) => !before.patients.some((q) => q.id === p.id)),
    'new ids',
  );
  assert.notEqual(
    after.appointments.find((r) => r.status === 'confirmed').code,
    before.appointments.find((r) => r.status === 'confirmed').code,
    'new booking codes',
  );
});

test('import: references resolve by the Bundle rules, and a slot is taken once', async () => {
  const o = 'clinic-import-refs';
  owners.add(o);
  const patient = (id, name) => ({
    resourceType: 'Patient',
    id,
    name: [{ text: name }],
  });
  const appt = (id, patientRef, slotRef, start) => ({
    resourceType: 'Appointment',
    id,
    status: 'booked',
    start,
    end: plusMinutes(start, 30),
    ...(slotRef ? { slot: [{ reference: slotRef }] } : {}),
    participant: [
      { actor: { reference: patientRef }, status: 'accepted' },
      { actor: { reference: 'Practitioner/dr' }, status: 'accepted' },
      { actor: { reference: 'Location/room' }, status: 'accepted' },
    ],
  });
  const bundle = {
    resourceType: 'Bundle',
    type: 'collection',
    entry: [
      // RESTful fullUrls: relative references resolve against the base.
      {
        fullUrl: 'https://hospital-a.example/fhir/Patient/example',
        resource: patient('example', 'Ana de A'),
      },
      {
        fullUrl: 'https://hospital-a.example/fhir/Practitioner/dr',
        resource: {
          resourceType: 'Practitioner',
          id: 'dr',
          name: [{ text: 'Dr Base' }],
        },
      },
      {
        fullUrl: 'https://hospital-a.example/fhir/Location/room',
        resource: { resourceType: 'Location', id: 'room', name: 'Room Base' },
      },
      {
        fullUrl: 'https://hospital-a.example/fhir/Schedule/s',
        resource: {
          resourceType: 'Schedule',
          id: 's',
          actor: [
            { reference: 'Practitioner/dr' },
            { reference: 'Location/room' },
          ],
        },
      },
      // A slot named only by urn:uuid, and two appointments that name it.
      {
        fullUrl: 'urn:uuid:aaaaaaaa-0000-4000-8000-000000000001',
        resource: {
          resourceType: 'Slot',
          schedule: { reference: 'Schedule/s' },
          status: 'busy',
          start: '2099-11-02T09:00:00-03:00',
          end: '2099-11-02T09:30:00-03:00',
        },
      },
      {
        fullUrl: 'https://hospital-a.example/fhir/Appointment/first',
        resource: appt(
          'first',
          'Patient/example',
          'urn:uuid:aaaaaaaa-0000-4000-8000-000000000001',
          '2099-11-02T09:00:00-03:00',
        ),
      },
      {
        fullUrl: 'https://hospital-a.example/fhir/Appointment/second',
        resource: appt(
          'second',
          'Patient/example',
          'urn:uuid:aaaaaaaa-0000-4000-8000-000000000001',
          '2099-11-02T09:00:00-03:00',
        ),
      },
      // An absolute reference to another server's Patient/example is not
      // the Patient/example in this file.
      {
        fullUrl: 'https://hospital-a.example/fhir/Appointment/elsewhere',
        resource: appt(
          'elsewhere',
          'https://hospital-b.example/fhir/Patient/example',
          null,
          '2099-11-02T10:00:00-03:00',
        ),
      },
      // Two appointments at the same start with no slot named: one slot.
      {
        fullUrl: 'https://hospital-a.example/fhir/Appointment/clash1',
        resource: appt(
          'clash1',
          'Patient/example',
          null,
          '2099-11-02T11:00:00-03:00',
        ),
      },
      {
        fullUrl: 'https://hospital-a.example/fhir/Appointment/clash2',
        resource: appt(
          'clash2',
          'Patient/example',
          null,
          '2099-11-02T11:00:00-03:00',
        ),
      },
      // A reference into a contained resource is not followed.
      {
        fullUrl: 'https://hospital-a.example/fhir/Appointment/inner',
        resource: {
          ...appt('inner', '#p', null, '2099-11-02T12:00:00-03:00'),
          contained: [patient('p', 'Contained')],
        },
      },
    ],
  };
  const report = await importBundle(o, bundle);
  const why = Object.fromEntries(report.skipped.map((x) => [x.id, x.reason]));
  assert.deepEqual(report.imported, {
    Practitioner: 1,
    Location: 1,
    Patient: 1,
    Schedule: 1,
    Slot: 1,
    Appointment: 2,
  });
  assert.match(why.second, /names a slot another booking already holds/);
  assert.match(why.elsewhere, /patient is not in the bundle/);
  assert.match(why.clash2, /already has an appointment slot/);
  assert.match(why.inner, /patient is not in the bundle/);
  const s = await state(o);
  const held = s.Slot.find((x) => x.start === '2099-11-02T09:00:00-03:00');
  assert.equal(held.status, 'busy', 'the slot named by urn:uuid is held');
  const first = s.Appointment.find(
    (a) => a.start === '2099-11-02T09:00:00-03:00',
  );
  assert.equal(slotRefOf(first), 'Slot/' + held.id);
  assert.equal(
    project(s).appointments.filter((r) => r.kind === 'slot').length,
    0,
    'nothing open',
  );
  // Booking the same time again by hand is refused: the slot is busy.
  await act(o, twilioCredentials);
  await act(o, {
    action: 'contact',
    name: 'Team',
    phone: phoneA,
    consent: true,
  });
  await act(o, { action: 'patient', name: 'Fictional Rosa', phone: phoneA });
  const rosa = byName(await state(o), 'Fictional Rosa').id;
  await assert.rejects(
    act(
      o,
      slot(rosa, {
        date: '2099-11-02',
        time: '09:00',
        clinician: 'Dr Base',
        location: 'Room Base',
      }),
    ),
    /already has an appointment slot/,
  );
});

test('a booking and its slot change together or not at all', async () => {
  const o = 'clinic-atomic';
  const { rebook } = await loadTs('lib/fhir/scheduling.ts', stubs);
  const ids = await clinic(o, ['Fictional Elena']);
  await act(o, slot(ids['Fictional Elena']));
  const [a] = live(await state(o));
  // The copy in hand goes stale when the appointment is confirmed; every
  // operation that would write it together with its slot is then refused
  // as a whole — no half-done state, and nothing swallowed.
  await confirmAppointment(o, a, 'test');
  const before = JSON.stringify(await store().everything(o));
  await assert.rejects(releaseToStandby(o, a, '2099-09-11'), /just changed/);
  await assert.rejects(rebook(o, a, '2099-09-11'), /just changed/);
  await assert.rejects(confirmAppointment(o, a, 'again'), /just changed/);
  assert.equal(
    JSON.stringify(await store().everything(o)),
    before,
    'nothing moved',
  );
  const s = await state(o);
  assert.equal(s.Appointment[0].status, 'booked');
  assert.equal(s.Slot[0].status, 'busy');
  assert.equal(
    waiting(s).length,
    0,
    'no standby entry was created on the side',
  );
  // With a fresh copy the same release lands: appointment, slot and the
  // new standby entry in one go.
  const fresh = (await state(o)).Appointment[0];
  const out = await releaseToStandby(o, fresh, '2099-09-11');
  assert.equal(out.released.status, 'cancelled');
  assert.equal(out.queued.status, 'waitlist');
  assert.equal((await state(o)).Slot[0].status, 'free');
});

test('import: relative patient references never fall back to another server', async () => {
  const o = 'clinic-import-relative-origin';
  owners.add(o);
  const patient = (server, name) => ({
    fullUrl: `https://${server}.example/fhir/Patient/123`,
    resource: {
      resourceType: 'Patient',
      id: '123',
      identifier: [{ system: `https://${server}.example/mrn`, value: '123' }],
      name: [{ text: name }],
    },
  });
  const appointment = {
    fullUrl: 'https://hospital-a.example/fhir/Appointment/waiting',
    resource: {
      resourceType: 'Appointment',
      id: 'waiting',
      status: 'waitlist',
      serviceType: [{ text: 'PAP' }],
      participant: [
        { actor: { reference: 'Patient/123' }, status: 'needs-action' },
      ],
    },
  };
  const bundle = (entry) => ({
    resourceType: 'Bundle',
    type: 'collection',
    entry,
  });
  const rejected = await importBundle(
    o,
    bundle([patient('hospital-b', 'Fictional B'), appointment]),
  );
  assert.equal(rejected.imported.Appointment, undefined);
  assert.match(
    rejected.skipped.find((x) => x.id === 'waiting').reason,
    /patient is not in the bundle/,
  );
  assert.equal((await store().search(o, 'Appointment')).length, 0);

  // B appears last, so a bare Type/id lookup would pick the wrong patient.
  const accepted = await importBundle(
    o,
    bundle([
      patient('hospital-a', 'Fictional A'),
      patient('hospital-b', 'Fictional B'),
      appointment,
    ]),
  );
  assert.equal(accepted.imported.Appointment, 1);
  const [saved] = await store().search(o, 'Appointment');
  const target = await store().resolve(o, patientRefOf(saved));
  assert.equal(patientName(target), 'Fictional A');
});

test('import: a resource that is not valid R4 is refused with the reason', async () => {
  const o = 'clinic-import-valid';
  owners.add(o);
  const report = await importBundle(o, {
    resourceType: 'Bundle',
    type: 'collection',
    entry: [
      {
        resource: {
          resourceType: 'Patient',
          id: 'bad',
          name: [{ text: 'Not Valid' }],
          birthDate: 'not-a-date',
          active: 'yes',
          favouriteColour: 'green',
        },
      },
      {
        resource: {
          resourceType: 'Patient',
          id: 'good',
          name: [{ text: 'Quite Valid' }],
          birthDate: '1990-02-03',
          active: true,
        },
      },
      {
        // References are rewritten before validation, so a display-only
        // reference left behind is still checked as a Reference.
        resource: {
          resourceType: 'Appointment',
          id: 'odd',
          status: 'waitlist',
          participant: [
            {
              actor: { reference: 'Patient/good' },
              status: 'accepted',
              required: 'sometimes',
            },
          ],
        },
      },
    ],
  });
  assert.deepEqual(report.imported, { Patient: 1 });
  const why = Object.fromEntries(report.skipped.map((x) => [x.id, x.reason]));
  assert.equal(
    why.bad,
    'birthDate is not a valid date; active must be a boolean; favouriteColour is not an element of Patient',
  );
  assert.match(
    why.odd,
    /participant\/0\/required must be one of required, optional, information-only/,
  );
  assert.equal((await state(o)).Patient.length, 1);
});
