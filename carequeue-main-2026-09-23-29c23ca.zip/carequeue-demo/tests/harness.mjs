import { DatabaseSync } from 'node:sqlite';
import { readFileSync, readdirSync } from 'node:fs';
import { build } from 'esbuild';

// Shared test plumbing: an in-memory SQLite database behind the D1 surface
// the code uses, with every migration applied in order, and a way to load a
// TypeScript module with its platform imports replaced. No network, no
// Workers runtime.

export function openDatabase() {
  const database = new DatabaseSync(':memory:');
  for (const f of readdirSync('drizzle')
    .filter((f) => f.endsWith('.sql'))
    .sort())
    database.exec(readFileSync('drizzle/' + f, 'utf8'));
  const statement = (sql, args = []) => ({
    bind: (...a) => statement(sql, a),
    first: async () => database.prepare(sql).get(...args) ?? null,
    all: async () => ({ results: database.prepare(sql).all(...args) }),
    run: async () => ({
      meta: { changes: Number(database.prepare(sql).run(...args).changes) },
    }),
  });
  const DB = {
    prepare: statement,
    batch: async (ss) => {
      database.exec('BEGIN');
      try {
        const results = [];
        for (const s of ss) results.push(await s.run());
        database.exec('COMMIT');
        return results;
      } catch (e) {
        database.exec('ROLLBACK');
        throw e;
      }
    },
  };
  return { DB, database };
}

// Bundle a TypeScript entry point and import it. `stubs` maps a bare import
// specifier to the source that should stand in for it.
export async function loadTs(entry, stubs = {}) {
  const names = Object.keys(stubs);
  const bundle = await build({
    entryPoints: [entry],
    bundle: true,
    write: false,
    platform: 'node',
    format: 'esm',
    plugins: [
      {
        name: 'test-boundaries',
        setup(b) {
          if (!names.length) return;
          b.onResolve(
            {
              filter: new RegExp(
                '^(' +
                  names
                    .map((n) => n.replace(/[.*+?^${}()|[\]\\/]/g, '\\$&'))
                    .join('|') +
                  ')$',
              ),
            },
            (args) => ({ path: args.path, namespace: 'test' }),
          );
          b.onLoad({ filter: /.*/, namespace: 'test' }, (args) => ({
            contents: stubs[args.path],
          }));
        },
      },
    ],
  });
  return import(
    'data:text/javascript;base64,' +
      Buffer.from(bundle.outputFiles[0].text).toString('base64')
  );
}
