// A fake Twilio and a fake Telegram behind global fetch. Each call records
// what the code sent and answers as the vendor would, so a workflow test can
// send, receive and check delivery without a network or a real message.
export function installFakeProviders() {
  const fake = {
    // Twilio: inbound messages the next poll returns, outbound bodies sent,
    // and whether the next send should fail definitively.
    incoming: [],
    outgoing: [],
    failSend: false,
    // Telegram: pending updates and sent messages.
    tgUpdates: [],
    tgSent: [],
    reset() {
      fake.incoming = [];
      fake.outgoing = [];
      fake.failSend = false;
      fake.tgUpdates = [];
      fake.tgSent = [];
    },
  };
  globalThis.fetch = async (url, init = {}) => {
    const u = new URL(url);
    if (u.hostname === 'api.telegram.org') {
      const method = u.pathname.split('/').pop();
      if (method === 'getMe')
        return Response.json({
          ok: true,
          result: { username: 'carequeue_demo_bot' },
        });
      if (method === 'sendMessage') {
        fake.tgSent.push(JSON.parse(init.body));
        return Response.json({
          ok: true,
          result: { message_id: fake.tgSent.length },
        });
      }
      if (method === 'getUpdates') {
        const offset = Number(u.searchParams.get('offset') || 0);
        return Response.json({
          ok: true,
          result: fake.tgUpdates.filter((x) => x.update_id >= offset),
        });
      }
      return Response.json(
        { ok: false, description: 'unknown method' },
        { status: 400 },
      );
    }
    if (init.method === 'POST') {
      if (fake.failSend) return Response.json({ code: 63015 }, { status: 400 });
      const body = Object.fromEntries(new URLSearchParams(init.body));
      fake.outgoing.push(body);
      return Response.json({
        sid: 'SM' + fake.outgoing.length,
        status: 'queued',
      });
    }
    if (u.pathname.match(/Messages\/SM/))
      return Response.json({ status: 'delivered' });
    const from = u.searchParams.get('From');
    return Response.json({
      messages: from
        ? [{ direction: 'inbound', date_sent: new Date().toISOString() }]
        : fake.incoming,
      next_page_uri: null,
    });
  };
  return fake;
}

export const twilioCredentials = {
  action: 'connect',
  provider: 'twilio',
  sid: 'AC' + 'a'.repeat(32),
  token: 'b'.repeat(32),
  sender: '+14150000000',
  contentSid: 'HX' + 'c'.repeat(32),
};
export const telegramCredentials = {
  action: 'connect',
  provider: 'telegram',
  token: '123456789:' + 'x'.repeat(35),
};
