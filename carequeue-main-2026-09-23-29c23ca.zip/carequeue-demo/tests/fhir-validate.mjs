import { readFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import Ajv from 'ajv';
import draft6 from 'ajv/dist/refs/json-schema-draft-06.json' with { type: 'json' };

// The official HL7 FHIR R4 (4.0.1) JSON schema, as published at
// https://hl7.org/fhir/R4/fhir.schema.json.zip, minified and gzipped in
// fhir/fhir.schema.json.gz. Compiling it takes about half a second and
// 200 MB, which is why it runs here and not inside the Worker: the tests
// validate every resource the code produces, the store checks the parts a
// type system cannot at run time.
export const schema = JSON.parse(
  gunzipSync(readFileSync('fhir/fhir.schema.json.gz')).toString(),
);
// The file predates draft-07 and names itself with `id`; ajv wants `$id`.
schema.$id = schema.id;
delete schema.id;

const ajv = new Ajv({ strict: false, allErrors: true, validateFormats: false });
ajv.addMetaSchema(draft6);
ajv.addSchema(schema);
const validators = new Map();
function validatorFor(type) {
  if (!schema.definitions[type]) throw Error(`No R4 definition for ${type}`);
  if (!validators.has(type))
    validators.set(
      type,
      ajv.compile({ $ref: schema.$id + '#/definitions/' + type }),
    );
  return validators.get(type);
}

// Validate one resource against the definition for its own resourceType —
// narrower errors than the top-level oneOf over all 146 types.
export function fhirErrors(resource) {
  const v = validatorFor(resource.resourceType);
  if (v(resource)) return [];
  return v.errors.map((e) => `${e.instancePath || '/'} ${e.message}`);
}
export function assertFhir(resource) {
  const errors = fhirErrors(resource);
  if (errors.length)
    throw Error(
      `${resource.resourceType}/${resource.id} is not valid R4:\n  ` +
        errors.slice(0, 8).join('\n  ') +
        '\n' +
        JSON.stringify(resource, null, 1).slice(0, 1500),
    );
}
export function assertAllFhir(resources) {
  for (const r of resources) assertFhir(r);
  return resources.length;
}

// The enum the schema gives for a coded element, if it gives one: some
// required bindings (Communication.status, AppointmentResponse
// .participantStatus) are plain `code` in the published schema.
export function schemaEnum(type, element) {
  return schema.definitions[type]?.properties?.[element]?.enum ?? null;
}
