# CareQueue · Concepción

## Project purpose

CareQueue is a private appointment and standby-list demonstration for a Concepción public health center. It uses fictional patient data and one consenting team test phone. It is not connected to AVIS or SINETSUR.

## Data model

Everything clinical is an HL7 FHIR R4 resource (see the next section for
the store). The patient is still the centre: a `Patient` holds the name,
the delivery address (its one `telecom`) and notes; appointments and
standby entries reference it as a participant and hold no copy of the
person, so renaming a patient renames them everywhere at once. The
interface derives its rows from the resources (`lib/fhir/view.ts`) and
never reintroduces a name column.

A patient's address must be a registered recipient (the operational
`contacts` table) and their `Consent` active — `unreachable()` in
`lib/fhir/registry.ts`, asked on every path that puts a patient on a slot:
booking, queueing and assigning from standby alike — but many patients may
share one device: that is what lets a single test phone play a whole
waiting room. A patient whose address is no longer registered — after
switching provider, for instance — stays in the list and is reported as
unreachable instead of being silently dropped.

A standby entry is an `Appointment` with status `waitlist` and no slot; it
may carry a day (`requestedPeriod`), or none for any day. A waiting entry
may be edited or removed. Assigning it to a slot moves that same
Appointment onto the slot (`pending`, marked `EXT.assigned`), so the entry
*is* the booking from then on: it is edited or deleted as an appointment,
and the standby list shows it as Booked with a link. When that assignment
is undone — the slot cancelled or the appointment deleted — the Appointment
goes back to `waitlist` marked `EXT.released` (shown as "Assignment
cancelled"): not offered, not counted against duplicates, re-queued by
editing. The standby list is laid out by day. A patient may wait for the
same service on several days, but not twice on one day. When a slot is
being filled, candidates waiting for that day or for any day are offered
first, then longest waiting first (`standbyRank` in `lib/rules.ts`); a
different day is allowed but pointed out. Attendance history is
deliberately not a sort key: in a public clinic it would push the
least-resourced patients to the back. If it is ever recorded, show it to
staff as context.

The booking code is the Appointment's `identifier`, kept because message
keys are built from it. Changing the slot, the patient or the patient's
address rotates it.

## FHIR R4 store

Clinical data is being moved onto HL7 FHIR R4 (the international base
specification, no national profile). Resources live as JSON documents in
`resources`, one row per `Type/id` within a workspace, with their search
parameters extracted into `search_index` in the same batch
(`lib/fhir/store.ts`); which parameters each type has, and which are unique
within a workspace, is decided in `lib/fhir/resources.ts`. There is no FHIR
REST endpoint: the store is internal and every call takes the owner first.

Conformance is checked at two levels. The official R4 JSON schema
(`fhir/fhir.schema.json.gz`, HL7's `fhir.schema.json` for 4.0.1, minified and
gzipped) is compiled in the tests — `tests/fhir-validate.mjs` — and run over
every resource the code produces; it is 2.7 MB and takes ~200 MB to compile,
so it does not run inside the Worker. At run time `assertResource` rejects,
before any write, what a type cannot: a status outside the R4 value set, a
malformed id, an empty required list. Note that the published schema leaves
`Communication.status` and `AppointmentResponse.participantStatus` as bare
`code` and cannot say a list is non-empty, so the runtime lists in `CODES`
are the only enforcement there; the tests pin them to the spec.

`lib/fhir/backend.ts` is `state` and `action`, on top of `lib/workspace.ts`
(owner, database, encrypted connection, registered recipients — the
operational tables `connections` and `contacts`, which describe the
messaging pipeline and are not FHIR). `state` returns the resources grouped
by type plus the operational facts; `lib/fhir/view.ts` derives the rows the
interface shows, keeping each row's id equal to its resource's id, so an
open slot row names a Slot (`slotDelete`, `invite`) and every other row an
Appointment or Patient.

A patient is a `Patient` (record number in `identifier`, the delivery address
as its one `telecom` tagged with the provider, notes in an extension) with
one `Consent` (`provision.type = permit`, the local test-message policy),
created together and removed together; a changed address re-dates the
consent. Practitioner, Location and HealthcareService are found or created
by exact name (`registry.ts`) — a service on the menu carries a coding from
the clinic's own CodeSystem (`serviceCodeSystem()` in `build.ts`), a typed-in
service is text only. Reachability is `unreachable()` in `registry.ts`: the
address must be a registered recipient and the consent active.

Scheduling (`scheduling.ts`, builders in `build.ts`, clinic time in
`time.ts`): a slot is a `Slot` on the `Schedule` of a clinician in a room
(one Schedule per pair, found by the `actors` key), 30 minutes long, its
instants written with Chile's offset for that day (`instantOf`, `wallTime`).
Starts must sit on the centre's timetable (`validClinicSlot`): a clinic
day, on the half hour, within opening hours. Booking a start where an open
Slot already sits takes that Slot over (`holdSlot`) rather than refusing
it; a start another booking holds is refused. The booking form shows a
clinician's day as taken/free chips from the bundle (`availability` in
`view.ts`), one click to pick a free start.
`busy` while an appointment holds it, `free` when open — **an open slot is a
free Slot, not an appointment without a patient**, so `slotDelete` is its
own action. A booking is an `Appointment` on that slot: `pending` until the
patient confirms, `booked` after, with the booking code as its
`identifier`, the patient as a `needs-action` participant and the
Practitioner and Location as `accepted` ones. A standby entry is an
`Appointment` with status `waitlist` and no slot; its day is
`requestedPeriod` (absent for any day). Assigning (`assign`) moves that
same Appointment onto the slot — pending, the slot's service, a fresh code,
`EXT.assigned` stamped — so the "filled" state of the old model is a pending
appointment carrying `EXT.assigned`. Cancel frees the slot; a direct booking
becomes `cancelled` (kept as history, deleted with its patient), an
assignment goes back to `waitlist` with `EXT.released` (parked: not offered,
not counted, edited to re-queue). Delete removes booking and slot, leaving an
assignment's entry released the same way. An assigned entry cannot be edited
or removed from the standby side: it is the appointment now. Editing a live
appointment moves the Slot (the old one is removed, not left open) and
rotates the code when the slot or the patient changed, dropping `booked` to
`pending`; a service change alone keeps the confirmation. Confirmation
(`confirmAppointment`) is an `AppointmentResponse` with `participantStatus
= accepted` plus the Appointment going `booked`; responses stay as history.
`readdress` is the address-change cascade: every live appointment of the
patient gets a new code and returns to pending. `releaseToStandby` is the
core of `/reschedule`: a direct booking is cancelled and a waitlist entry
created for the named day; an assignment becomes a waiting entry for the
new day in place, keeping its `created` and so its place in the queue; an
entry already waiting for that day is not duplicated. Every write goes
through the store's version check, so "just changed, reload" replaces the
old code-guarded UPDATEs, and a booking and its slot are always written in
one transaction.

Messaging (`messaging.ts`): a message is a `Communication`. Its id is its
idempotency key through `idFrom` (`reminder:<appointment>:<code>[:n]`,
`inquiry:<sid>`, `ack:<sid>`, `resched:<sid>`, `inbound:<sid>`), also kept
as an `identifier` under `SYSTEM.messageKey`; the provider's own message id
is a second identifier. The address it went to or came from is
`EXT.address` (a ContactPoint — R4 addresses a Communication to a person,
and one device stands for several patients here), the provider's status
word is `EXT.delivery` verbatim, mapped onto `Communication.status` by
`communicationStatus` (sending → preparation, queued/sent → in-progress,
delivered/read → completed, failed/undelivered → not-done). `about` is the
appointment a reminder or acknowledgement concerns, `recipient` the
patient when known, `inResponseTo` the inbound message a reply answers,
`category` what it is for (`reminder`, `standby`, `inquiry`,
`acknowledgement`, `reschedule`, `inbound`; a standby notification is
`reminder` + `standby`, under the appointment's reminder key, so it is the
reminder for that code). `send` is `createIfAbsent` on the key: a second
call finds the first message and sends nothing, unless it failed for
certain, in which case it is claimed and retried on the same resource.
`remind`, `recordConfirmation` (staff C), `notifyAssignment`, `sync` and the
three commands (`applyReply`) keep the rules stated under Messaging
providers; the "reminder sent before the reply" gate reads the reminder's
`sent` at second granularity (`reminderSentAt`). The `/reschedule` pending
question still lives in `contacts.pending`. Card shapes for the provider
templates come from `cardOf`, which resolves participant names.

Bundles (`bundle.ts`, route `app/api/fhir`): the workspace goes out as one
`Bundle` of type `collection` — the nine clinical and scheduling types,
never Communication — and any R4 Bundle comes in through `importBundle`,
which *adds*: every resource gets a new id and the Bundle's own references
are rewritten to match, so nothing imported collides with or is mistaken
for what was here. Resolution follows the Bundle rules (`Targets`): an
absolute reference — URL or urn — must equal an entry's fullUrl; a
relative `Type/id` resolves against the referring entry's server base when
its fullUrl is RESTful (and only there — no fall back to a bare `Type/id`,
which could be another hospital's patient of that id), else against
resource ids in the Bundle; a URL to another server is never matched by
its tail, and `#contained` is not followed. Resource types
this system does not hold are skipped and reported, as is anything that
fails the R4 schema or `assertResource`: every incoming resource is
validated, as it will be stored, against `fhir/r4-import.schema.json` —
the part of HL7's schema an import can reach (the nine types and their
datatypes, 81 definitions, ~50 KB, `contained` left out), written by
`scripts/fhir-subset.mjs` (`npm run fhir:subset`) and checked against the
official file by the tests — with `lib/fhir/validate.ts`, a validator for
exactly the keywords that schema uses, whose verdicts the tests compare
with ajv's; so the Worker validates uploads without compiling the full
schema. A clinician, room or service with the same name,
and a patient with an identifier already on record, are taken to be the
one already here (reported as `matched`); a name given only in parts gets a
`text` (`humanName`, which the index uses too); a patient with no
identifier is issued a record number. Slots come in free (a blocked status
is kept); a live appointment must hold a slot: the one it named in the
Bundle, taken as it is used so a second appointment naming the same slot
is refused, or one held on its clinician's schedule at its start; a live
appointment without clinician and room is skipped. Other statuses come
in as history without a slot, a waitlist entry as a standby entry under the
one-per-service-per-day rule. Booking codes are always this system's own.
References to what was not imported are dropped, a resource whose required
reference is dropped is skipped. Root `id`, `meta`, `text` and `contained`
do not come along. The route accepts up to 5 MB; the interface's FHIR data
section on Messaging setup downloads and uploads the file and shows the
report.

Writes are versioned: `update` takes the resource as read, with
`meta.versionId`, and refuses to overwrite a newer version (`Conflict`,
`kind: 'stale'`; a unique key taken is `kind: 'unique'`). Several resources
are written together with `transact(o, writes)` — creates, updates and
removals in one D1 batch, which is a transaction; each version-guarded
UPDATE is followed by a guard statement that fails on a NOT NULL constraint
when `changes()` is 0, so a stale version anywhere rolls the whole batch
back. Every operation that touches a booking and its slot (book, edit,
cancel, delete, assign, confirm, readdress, release to standby, rebook,
import) goes through it: all of it lands or none of it, and nothing is
swallowed. `holdSlot` therefore plans a write rather than performing one.
`search` takes `{ sort: { param, descending }, limit }` to order by an
indexed parameter and cut in SQL — the message history is read that way,
the hundred most recent by `sent`/`received`; `state()` otherwise returns
every resource, which is fine at demonstration size and would be the next
thing to page. `createIfAbsent` with a deterministic id is the idempotency mechanism —
message keys become ids through `idFrom`, colons to dots. CareQueue's own
identifier systems, code systems and extensions all hang off
`https://carequeue.example/fhir` (`SYSTEM`, `EXT`); `.example` is reserved for
documentation, which suits a demonstration.

## Messaging providers

CareQueue talks to one provider per workspace, chosen in setup. `lib/providers.ts` is the only file that calls a vendor API; everything else addresses a recipient, sends a reminder and pulls replies through that interface.

- `twilio`: WhatsApp on the free trial. Fixed template, typed-in E.164 recipients.
- `telegram`: bot API. Free text, recipients bound by an in-chat `/start <code>` link. A group counts as a recipient too (negative chat id, command arrives as `/start@botname <code>`), which is how one Telegram account demonstrates several patients as separate chat windows: one group per patient. The bot's privacy mode must be off for it to see a plain `C` in a group; only ever do that in throwaway demo groups, since the bot then reads everything posted there.

Adding a provider means adding an implementation there, not touching `lib/fhir/messaging.ts`. Keep the `since` filter inside the provider: it knows its own timestamp granularity, and declare its `telecom` kind (phone or other) for the FHIR contact points.

Regardless of provider, replies are recorded for staff review. No inbound message may reassign a booking, and none may cancel or move one except `/reschedule`, which is the one deliberate exception (below). Three commands are acted on. `/confirm` (also `/confirm@botname`; `isConfirmCommand` in `lib/rules.ts`) confirms automatically when exactly one appointment on that address is awaiting confirmation (`scheduled` or `filled`) and had a reminder sent before the reply; with nothing pending or more than one pending it changes nothing and is left for staff, and on a free-text provider the patient is told what happened (`ack:<sid>`, once per message): confirmed, already confirmed (naming the slot — a repeat `/confirm` must not read as "you have no appointment"), nothing pending, or more than one pending. A bare `C` is deliberately not automatic: Twilio's fixed template tells patients to reply C, and that path stays staff-reviewed (`confirm` accepts either C or `/confirm` on file). `/reschedule <day>` (also `/reschedule@botname`; `parseRescheduleCommand` and `parseRequestedDay` in `lib/rules.ts`) is the one inbound message that changes a booking, by explicit decision. When exactly one appointment on that address is live (`scheduled`, `confirmed` or `filled`) and the patient names a clinic day (25/09, 25-09, 25/09/2026, 2026-09-25; a past day is refused, «cualquier día» is answered with a request for a specific day, a closed day with the timetable), the day is checked on the appointment's own schedule — same clinician, same room — against the centre's timetable (`lib/timetable.ts`: Mon–Fri, 08:00–17:00, 30-minute starts). If a start is free — no Slot, or one left open by a cancellation — the appointment is moved into the earliest one (`rebook`): fresh code, back to `pending`, the old slot left on the board as open, and the reply names the new time and asks for `/confirm`; that reply is sent under the appointment's new reminder key, so it is the reminder a `/confirm` answers. If the day is full, the slot is released — same effect as staff cancel — and the patient is queued on standby for the slot's service on that day (an entry already waiting for that day is not duplicated; an assignment from standby becomes a waiting entry for the day in place). Nothing happens until a usable day is in hand: a bare `/reschedule` only asks for one and stores `{appointment, code, until}` in `contacts.pending` for 30 minutes; the next plain message from that chat that reads as a day completes it, an unusable one is answered and the question stays open, and `/cita` or `/confirm` in between are handled as themselves. With two live appointments, or none, nothing changes. Replies go under `resched:<sid>` on a free-text provider (the "moved" reply under the reminder key); on Twilio the inline form works silently and the bare form is only recorded. A bare `R` remains record-only. The other automatic answer is `/cita` (also `/cita@botname` in a group): a read-only summary of the asking chat's current appointments and standby entries, in Spanish, sent once per inbound message under `inquiry:<sid>`, only from a registered chat and only on a provider that can send free text — Twilio's fixed template cannot carry it, so there the command is merely logged. It lists every patient on that address, so a shared device reveals all of them; one group per patient avoids that. Answers go out during sync, i.e. within ~15 s while the dashboard is open and not at all otherwise; an always-on answer would need a public webhook, which the private Site does not have.

## Twilio free-trial scope

- Twilio's free WhatsApp trial sends only the pre-approved Appointment Reminders template.
- Do not send a custom `Body` or `ContentVariables`; use the stored `ContentSid`.
- The template contains a sample date that may differ from the CareQueue appointment. The UI must disclose this before sending.
- Incoming replies are polled while the dashboard is open, normally every 15 seconds: Twilio via the Messages API, Telegram via `getUpdates`. There is no public webhook, so a provider that only pushes over webhooks (such as Meta's Cloud API) cannot be added without a separate public endpoint.
- `R` and a bare `C` are recorded for staff review only. `/confirm` auto-confirms and `/reschedule <day>` releases-and-queues, each under the unambiguity rule above. Nothing inbound may reassign a booking.
- Staff may record a C confirmation manually, cancel a demo appointment, edit an active appointment, delete an appointment outright, and assign a standby patient in the website. A standby-assigned slot (`filled`: pending with `EXT.assigned`) is "assigned, awaiting confirmation": it is listed with `scheduled` under Awaiting reply, and a reviewed C moves it to `confirmed` (`booked`) exactly as for a direct booking. Cancel frees the Slot, which stays on the board as `open`, and leaves the booking as a `cancelled` record (deleted with its patient, or from its panel); delete removes the booking and its Slot and keeps message history, because those messages were really sent. Recording, cancelling and editing send nothing. Assigning a standby patient sends nothing on a fixed-template provider (Twilio), where the template must still be sent by hand after the sample-date acknowledgement; on a free-text provider (Telegram) it sends one notification naming the assigned slot and asking for a C reply. In neither case is assignment patient acceptance: the Appointment carries `EXT.assigned`, and a C still goes through staff review. The candidate picker offers only entries waiting for the slot's service (exact, case-insensitive match); `invite` itself does not check service, so a cross-service assignment stays possible for a future explicit override but is not offered.
- One reminder per appointment code, so a double click cannot send twice: a second `remind` is refused. A follow-up to a patient who has not replied is a deliberate `remind` with `again: true`, stored under `reminder:<id>:<code>:<n>`, and on Twilio still needs the sample-date acknowledgement.
- Editing an appointment must not preserve a stale confirmation. Changing the date, time, clinician, location or patient rotates the booking code, which retires the `reminder:<id>:<code>` message key so a new template and a new C reply are required before confirming again; changing the patient's address does the same to all their live appointments.
- Do not require a Twilio upgrade or payment.

## Important files

- `app/carequeue.tsx`: English admin interface, including the Patients tab that lists records and their appointments, standby entries and messages. Reads the FHIR bundle through `project()`.
- `lib/providers.ts`: the provider interface and every vendor API call.
- `lib/rules.ts`: validation and reply parsing helpers.
- `lib/services.ts`: the clinic's programmes and services, in Spanish as the clinic names them; drives the Service menu. The server still accepts any non-empty service so older records keep working.
- `lib/timetable.ts`: the centre's fixed timetable — clinic days, opening hours, 30-minute grid. Decides what staff may book, what the booking form shows as taken, and when a day is full for `/reschedule`. Constants for now; a roster would replace them.
- `lib/workspace.ts`: owner, database, encrypted provider connection, registered recipients.
- `lib/fhir/backend.ts`: `state` and `action` — what the API routes call.
- `lib/fhir/view.ts`: the rows the interface shows, derived from the bundle in the browser.
- `lib/fhir/build.ts`: builders and accessors — plain values in, R4 resources out, and back.
- `lib/fhir/registry.ts`: patients and their consent; find-or-create for clinicians, rooms and services; reachability.
- `lib/fhir/scheduling.ts`: booking, editing, cancelling, deleting, the standby list, assignment, confirmation, the address-change cascade and release-to-standby.
- `lib/fhir/time.ts`: clinic time — instants with Chile's offset, and back to day and time.
- `lib/fhir/messaging.ts`: Communications — send under a key, reminders and follow-ups, staff confirmation, standby notification, sync, and the three inbound commands.
- `lib/fhir/bundle.ts`: the workspace as a FHIR Bundle — export, and import with id rewriting, matching and a report. `app/api/fhir/route.ts` serves both.
- `lib/fhir/validate.ts` and `fhir/r4-import.schema.json`: structural R4 validation of uploads, on the schema subset `scripts/fhir-subset.mjs` writes.
- `tests/fixtures/hospital-bundle.json`: a Bundle in another system's style (HL7-example names, `urn:uuid` references, types this system does not hold, one deliberately invalid entry), used by the import test.
- `lib/fhir/resources.ts`: the R4 resource types CareQueue stores, its own identifier systems and extensions, the runtime conformance check and the search-parameter extraction.
- `lib/fhir/store.ts`: the D1 document store — create, createIfAbsent, read, resolve, update, remove, search — owner-scoped and versioned.
- `fhir/fhir.schema.json.gz`: HL7's official FHIR R4 JSON schema, used by the tests only.
- `db/schema.ts`: D1/SQLite schema — `connections`, `contacts`, `resources`, `search_index`.
- `drizzle/`: generated migrations. Include new migrations when changing the schema.
- `tests/harness.mjs`: the in-memory SQLite stand-in for D1 (all migrations applied) and the TypeScript loader the tests share.
- `tests/fhir-validate.mjs`: compiles the official schema; `assertFhir` / `assertAllFhir` for use in any test.
- `tests/fhir.test.mjs`: the store and the conformance checks themselves.
- `tests/fake-providers.mjs`: fake Twilio and Telegram behind `fetch`, with the credentials the tests connect with.
- `tests/fhir-workflow.test.mjs`: every workflow end to end with fake vendors; after every test, every resource in every workspace touched is validated against the official schema.
- `README.md`: user-facing setup and limitations.
- `.openai/hosting.json`: existing Sites project configuration. Reuse its `project_id`; never create a second Site.

## Security rules

- Never read, print, commit, or upload `.dev.vars`, Auth Tokens, access tokens, or runtime secrets.
- Twilio credentials are encrypted using the `CREDENTIAL_KEY` runtime secret and are never returned to the browser.
- All API operations must call `owner()` and scope every database query by the authenticated owner.
- Test contacts require explicit consent. Address format is the provider's business: E.164 for Twilio, a numeric chat id for Telegram, both validated in `lib/providers.ts`.
- A Telegram contact may only be bound by a staff-generated single-use link code. Never let an arbitrary inbound message register a contact.
- Keep all patient data fictional for this demonstration.

## Validation

Run after changes:

```text
npm run build
npx tsc --noEmit
node --test tests/rules.test.ts tests/fhir.test.mjs tests/fhir-workflow.test.mjs
```

Before modifying behavior, inspect the existing tests and extend them for security-sensitive or state-transition changes. Preserve the current private Sites deployment and existing project configuration.
