'use client';
import {
  useState,
  useEffect,
  useCallback,
  useMemo,
  useRef,
  FormEvent,
} from 'react';
import {
  CalendarDays,
  MessageCircle,
  Plus,
  ArrowUpRight,
  Users,
  Clock3,
  CheckCircle2,
  Send,
  RefreshCw,
  ChevronRight,
  ShieldCheck,
  Phone,
  MapPin,
  XCircle,
  Pencil,
  Settings2,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Toaster, toast } from '@/components/ui/toast';
import { standbyRank } from '@/lib/rules';
import {
  NativeSelect,
  NativeSelectOptGroup,
  NativeSelectOption,
} from '@/components/ui/native-select';
import { programs, services } from '@/lib/services';
import {
  availability,
  emptyBundle,
  project,
  type Bundle,
} from '@/lib/fhir/view';
import { TIMETABLE, hoursLabel } from '@/lib/timetable';
type Row = Record<string, any>;
const labels: Record<string, string> = {
  scheduled: 'Scheduled',
  confirmed: 'Confirmed',
  open: 'Open slot',
  filled: 'Standby assigned by staff',
  cancelled: 'Cancelled',
  waiting: 'Waiting',
  booked: 'Booked',
  released: 'Assignment cancelled',
};
const dateLabel = (d: string) =>
  new Date(d + 'T12:00:00').toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });
const dayLabel = (d: string | null) =>
  d
    ? new Date(d + 'T12:00:00').toLocaleDateString('en-GB', {
        weekday: 'short',
        day: 'numeric',
        month: 'short',
        year: 'numeric',
      })
    : 'Any date';
const sinceLabel = (t: number) =>
  new Date(t).toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'short',
    timeZone: 'America/Santiago',
  });
const timeLabel = (t: number) =>
  new Date(t).toLocaleTimeString('en-GB', {
    hour: '2-digit',
    minute: '2-digit',
    timeZone: 'America/Santiago',
  });
function Status({ s }: { s: string }) {
  return (
    <span className={'status ' + s}>
      <span />
      {labels[s] ?? s}
    </span>
  );
}
function Field({
  label,
  name,
  type = 'text',
  placeholder,
  required = true,
  defaultValue,
  value,
  onChange,
  step,
  min,
  max,
}: {
  label: string;
  name: string;
  type?: string;
  placeholder?: string;
  required?: boolean;
  defaultValue?: string;
  value?: string;
  onChange?: (value: string) => void;
  step?: number;
  min?: string;
  max?: string;
}) {
  return (
    <label className="field">
      {label}
      <Input
        name={name}
        type={type}
        placeholder={placeholder}
        required={required}
        defaultValue={defaultValue}
        value={value}
        onChange={onChange ? (e) => onChange(e.target.value) : undefined}
        step={step}
        min={min}
        max={max}
        maxLength={100}
      />
    </label>
  );
}
export default function CareQueue() {
  // The workspace arrives as FHIR resources grouped by type; the rows the
  // tables show are derived from them here, ids unchanged.
  const [bundle, setBundle] = useState<Bundle>(emptyBundle),
    [tab, setTab] = useState('appointments'),
    [modal, setModal] = useState<string | null>(null),
    [selected, setSelected] = useState<string | null>(null),
    [busy, setBusy] = useState(false),
    [loaded, setLoaded] = useState(false),
    [error, setError] = useState(''),
    [syncError, setSyncError] = useState(''),
    [consent, setConsent] = useState(false),
    [filter, setFilter] = useState('all');
  const [templateAccepted, setTemplateAccepted] = useState(false);
  const [draftProvider, setDraftProvider] = useState('');
  const [chosenPatient, setChosenPatient] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [chosenStandby, setChosenStandby] = useState<string | null>(null);
  // What the booking form says so far, so the clinician's day can be shown
  // as it is typed. Reset whenever the form opens.
  const blankDraft = { clinician: '', location: '', date: '', time: '' };
  const [draft, setDraft] = useState(blankDraft);
  // The last FHIR import's outcome, shown until the next one.
  const [importReport, setImportReport] = useState<{
    imported: Record<string, number>;
    matched: Record<string, number>;
    skipped: { type: string; id: string | null; reason: string }[];
  } | null>(null);
  useEffect(() => setConfirmDelete(false), [modal, selected, chosenStandby]);
  useEffect(() => setTemplateAccepted(false), [selected]);
  const syncing = useRef(false);
  // The hidden file input behind the "Import FHIR Bundle…" button.
  const bundleFile = useRef<HTMLInputElement>(null);
  const reload = useCallback(async () => {
    try {
      const r = await fetch('/api/workspace', { cache: 'no-store' });
      const d: any = await r.json();
      if (!r.ok) throw Error(d.error);
      setBundle(d);
      setError('');
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLoaded(true);
    }
  }, []);
  const execute = useCallback(
    async (data: Row, quiet = false) => {
      if (!quiet) setBusy(true);
      try {
        const r = await fetch('/api/actions', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(data),
        });
        const d: any = await r.json();
        if (!r.ok) throw Error(d.error);
        await reload();
        if (!quiet) toast.add({ title: d.message, type: 'success' });
        return d;
      } catch (e) {
        if (!quiet) toast.add({ title: (e as Error).message, type: 'error' });
        throw e;
      } finally {
        if (!quiet) setBusy(false);
      }
    },
    [reload],
  );
  useEffect(() => {
    void reload();
  }, [reload]);
  const connected = !!bundle.connection;
  useEffect(() => {
    if (!connected) return;
    const tick = async () => {
      if (syncing.current || document.hidden) return;
      syncing.current = true;
      try {
        await execute({ action: 'sync' }, true);
        setSyncError('');
      } catch (e) {
        setSyncError((e as Error).message);
      } finally {
        syncing.current = false;
      }
    };
    const timer = setInterval(tick, 15000);
    return () => clearInterval(timer);
  }, [connected, execute]);
  useEffect(() => {
    const ctx = (document as any).modelContext;
    if (!ctx?.registerTool) return;
    const controller = new AbortController();
    Promise.resolve(
      ctx.registerTool(
        {
          name: 'start_appointment_creation',
          description:
            'Open the new appointment form. Does not save or send messages.',
          inputSchema: {
            type: 'object',
            properties: {},
            additionalProperties: false,
          },
          annotations: { readOnlyHint: false },
          execute: (input: any) => {
            if (!input || Object.keys(input).length)
              throw Error('No fields expected.');
            setModal('appointment');
            return { form: 'appointment', saved: false };
          },
        },
        { signal: controller.signal },
      ),
    ).catch(() => {});
    return () => controller.abort();
  }, []);
  const ws = useMemo(
    () => ({
      ...project(bundle),
      contacts: bundle.contacts,
      connection: bundle.connection,
      providers: bundle.providers,
      secureStorage: bundle.secureStorage,
    }),
    [bundle],
  );
  const act = (data: Row) => void execute(data).catch(() => {});
  // The workspace as a FHIR Bundle, downloaded as a file.
  const exportBundle = async () => {
    setBusy(true);
    try {
      const r = await fetch('/api/fhir', { cache: 'no-store' });
      if (!r.ok) throw Error(((await r.json()) as { error: string }).error);
      const name =
        r.headers
          .get('content-disposition')
          ?.match(/filename="([^"]+)"/)?.[1] ?? 'carequeue-fhir.json';
      const url = URL.createObjectURL(await r.blob());
      const a = document.createElement('a');
      a.href = url;
      a.download = name;
      a.click();
      URL.revokeObjectURL(url);
      toast.add({ title: `Exported ${name}.`, type: 'success' });
    } catch (e) {
      toast.add({ title: (e as Error).message, type: 'error' });
    } finally {
      setBusy(false);
    }
  };
  // A FHIR Bundle from a file — another system's or one of ours — added
  // to the workspace; the report says what came in and what did not.
  const importBundle = async (file: File) => {
    setBusy(true);
    try {
      const r = await fetch('/api/fhir', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: await file.text(),
      });
      const d: any = await r.json();
      if (!r.ok) throw Error(d.error);
      setImportReport(d);
      await reload();
      const n = Object.values(d.imported as Record<string, number>).reduce(
        (a, b) => a + b,
        0,
      );
      toast.add({
        title: `Imported ${n} resource${n === 1 ? '' : 's'}${d.skipped.length ? `, skipped ${d.skipped.length}` : ''}.`,
        type: d.skipped.length ? 'info' : 'success',
      });
    } catch (e) {
      toast.add({ title: (e as Error).message, type: 'error' });
    } finally {
      setBusy(false);
    }
  };
  const submit = async (
    ev: FormEvent<HTMLFormElement>,
    action: string,
    extra: Row = {},
  ) => {
    ev.preventDefault();
    const form = ev.currentTarget;
    const data = Object.fromEntries(new FormData(form));
    try {
      await execute({
        action,
        ...data,
        ...extra,
        ...(action === 'contact' ? { consent } : {}),
      });
      form.reset();
      setConsent(false);
      if (action !== 'connect' && action !== 'contact') setModal(null);
    } catch {}
  };
  // The provider the connection is saved with drives what the workspace can do;
  // the setup form edits a possibly different one until it is saved.
  const active =
    ws.providers.find((p) => p.id === ws.connection?.provider) ?? null;
  const setupProvider =
    draftProvider || ws.connection?.provider || ws.providers[0]?.id || 'twilio';
  const setupMeta = ws.providers.find((p) => p.id === setupProvider) ?? null;
  const needsTemplateAck = active?.fixedTemplate !== false;
  // Standby entries grouped by the day they wait for; '' is "any day".
  const standbyByDay = new Map<string, Row[]>();
  for (const w of ws.standby)
    standbyByDay.set(w.date ?? '', [
      ...(standbyByDay.get(w.date ?? '') ?? []),
      w,
    ]);
  const current = ws.appointments.find((a) => a.id === selected);
  const patient = ws.patients.find((p) => p.id === chosenPatient) ?? null;
  useEffect(() => {
    setDraft(
      modal === 'edit' && current
        ? {
            clinician: current.clinician,
            location: current.location,
            date: current.date,
            time: current.time,
          }
        : blankDraft,
    );
    // The form is keyed on modal and selection; so is its draft.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [modal, selected]);
  // The clinician's day as the form describes it so far.
  const day =
    (modal === 'appointment' || modal === 'edit') &&
    draft.clinician.trim() &&
    draft.location.trim() &&
    /^\d{4}-\d{2}-\d{2}$/.test(draft.date)
      ? availability(bundle, draft.clinician, draft.location, draft.date)
      : null;
  // When editing, the appointment's own start is taken by itself.
  const ownTime =
    modal === 'edit' &&
    current &&
    current.clinician === draft.clinician.trim() &&
    current.location === draft.location.trim() &&
    current.date === draft.date
      ? current.time
      : null;
  // Candidates offered for an open slot: waiting, and for that slot's service.
  // The service menu makes an exact match meaningful; case-insensitive so a
  // hand-typed legacy value still lines up.
  const forThisSlot = (w: Row) =>
    w.status === 'waiting' &&
    !!current &&
    w.service.toLowerCase() === current.service.toLowerCase();
  const standbyRow = ws.standby.find((w) => w.id === chosenStandby) ?? null;
  // A patient can outlive the device that used to reach them, e.g. after
  // switching provider. Surface that rather than failing at send time.
  const reachable = (row: Row) =>
    ws.contacts.some((c) => c.phone === row.phone);
  const views: Record<string, string[]> = {
    // A standby-assigned slot is "assigned, awaiting confirmation", so it
    // sits with scheduled until a reviewed C moves it to confirmed.
    scheduled: ['scheduled', 'filled'],
    open: ['open'],
    filled: ['scheduled', 'confirmed', 'filled'],
  };
  const rows = ws.appointments.filter(
    (a) => filter === 'all' || (views[filter] ?? [filter]).includes(a.status),
  );
  const stats = [
    [
      CalendarDays,
      'Appointments',
      ws.appointments.filter((a) => a.status !== 'cancelled').length,
    ],
    [
      Clock3,
      'Awaiting confirmation',
      ws.appointments.filter((a) => ['scheduled', 'filled'].includes(a.status))
        .length,
    ],
    [
      Users,
      'Open slots',
      ws.appointments.filter((a) => a.status === 'open').length,
    ],
    [
      CheckCircle2,
      'Standby assigned',
      ws.appointments.filter((a) => a.status === 'filled').length,
    ],
  ] as const;
  return (
    <main>
      <Toaster />
      <header className="topbar">
        <div className="brand">
          <span className="brand-icon">
            <img src="/brand-icon.png" alt="" width={28} height={28} />
          </span>
          carequeue<span className="brand-sub">Concepción</span>
        </div>
        <span className="environment">Free trial · Fictional patients</span>
      </header>
      <div className="workspace">
        <div className="heading">
          <div>
            <div className="eyebrow">HEALTH CENTER WORKSPACE</div>
            <h1>Every appointment counts.</h1>
            <p>
              {needsTemplateAck
                ? 'Test a fixed WhatsApp reminder. Review replies with staff.'
                : 'Send appointment reminders. Review replies with staff.'}
            </p>
          </div>
          <Button
            className="primary"
            onClick={() => {
              if (!ws.contacts.length) {
                setTab('setup');
                toast.add({
                  title: 'Register a test device first.',
                  type: 'info',
                });
              } else if (!ws.patients.filter(reachable).length) {
                setTab('patients');
                toast.add({
                  title: 'Create a patient record first.',
                  type: 'info',
                });
              } else setModal('appointment');
            }}
          >
            <Plus size={17} />
            New appointment
          </Button>
        </div>
        {error && (
          <div role="alert" className="error-box">
            {error}{' '}
            <a href="/signin-with-chatgpt?return_to=%2F" target="_top">
              Sign in
            </a>{' '}
            <button onClick={() => void reload()}>Retry</button>
          </div>
        )}
        <div className="stats">
          {stats.map(([Icon, label, n]) => (
            <div className="stat" key={label}>
              <span>
                {label}
                <Icon size={18} />
              </span>
              <strong>{loaded ? n : '—'}</strong>
            </div>
          ))}
        </div>
        <div className={'connection ' + (ws.connection ? 'connected' : '')}>
          <MessageCircle size={21} />
          <div>
            <strong>
              {ws.connection
                ? `${active?.label ?? 'Provider'} connected · ${ws.connection.sender}`
                : 'Connect a messaging provider'}
            </strong>
            <p>
              {ws.connection
                ? `Keep this page open. Replies sync every 15 seconds${ws.connection.synced ? ' · Last sync ' + timeLabel(ws.connection.synced) : ''}.`
                : 'Book as many fictional appointments as you like. WhatsApp sends a fixed template; Telegram sends the real details.'}
            </p>
          </div>
          <Button variant="ghost" onClick={() => setTab('setup')}>
            {ws.connection ? 'Manage connection' : 'Set up messaging'}
            <ArrowUpRight size={15} />
          </Button>
        </div>
        {syncError && (
          <div role="alert" className="error-box">
            Reply sync needs attention: {syncError}
          </div>
        )}
        <Tabs value={tab} onValueChange={setTab}>
          <TabsList variant="line" className="navtabs">
            <TabsTrigger value="appointments">Appointments</TabsTrigger>
            <TabsTrigger value="standby">
              Standby list{' '}
              <span className="count">
                {ws.standby.filter((w) => w.status === 'waiting').length}
              </span>
            </TabsTrigger>
            <TabsTrigger value="patients">
              Patients <span className="count">{ws.patients.length}</span>
            </TabsTrigger>
            <TabsTrigger value="setup">Messaging setup</TabsTrigger>
          </TabsList>
          <TabsContent value="appointments">
            <div className="sectionbar">
              <div>
                <h2>Appointment schedule</h2>
                <p>All times in Concepción, Chile</p>
              </div>
              <div className="section-actions">
                <Button
                  variant="outline"
                  disabled={busy || !ws.connection}
                  onClick={() => act({ action: 'sync' })}
                >
                  <RefreshCw size={14} />
                  Sync replies
                </Button>
              </div>
            </div>
            <Tabs value={filter} onValueChange={setFilter}>
              <TabsList className="filters">
                <TabsTrigger value="all">All</TabsTrigger>
                <TabsTrigger value="scheduled">Awaiting reply</TabsTrigger>
                <TabsTrigger value="open">Open & invited</TabsTrigger>
                <TabsTrigger value="filled">Filled</TabsTrigger>
              </TabsList>
            </Tabs>
            {!loaded ? (
              <section className="surface empty-state">
                <p>Loading your workspace…</p>
              </section>
            ) : !rows.length ? (
              <section className="surface empty-state">
                <CalendarDays size={32} />
                <h2>
                  {ws.appointments.length
                    ? 'No appointments in this view'
                    : 'Your schedule starts here'}
                </h2>
                <p>
                  Register a test device, create a patient record, then book
                  them here.
                </p>
                <Button
                  variant="outline"
                  onClick={() =>
                    !ws.contacts.length
                      ? setTab('setup')
                      : !ws.patients.filter(reachable).length
                        ? setTab('patients')
                        : setModal('appointment')
                  }
                >
                  {!ws.contacts.length
                    ? 'Register a test device'
                    : !ws.patients.filter(reachable).length
                      ? 'Add a patient record'
                      : 'Add first appointment'}
                </Button>
              </section>
            ) : (
              <div className="schedule-layout">
                <section className="surface table-surface">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Patient</TableHead>
                        <TableHead>Appointment</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>
                          <span className="sr-only">Details</span>
                        </TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {rows.map((a) => (
                        <TableRow
                          key={a.id}
                          className={selected === a.id ? 'chosen' : ''}
                        >
                          <TableCell>
                            <button
                              className="patient-link"
                              onClick={() => setSelected(a.id)}
                            >
                              <span className="avatar">
                                {a.name
                                  ? a.name
                                      .split(' ')
                                      .map((x: string) => x[0])
                                      .slice(0, 2)
                                      .join('')
                                  : '—'}
                              </span>
                              <span>
                                <strong>{a.name ?? 'Open slot'}</strong>
                                <small>{a.service}</small>
                              </span>
                            </button>
                          </TableCell>
                          <TableCell>
                            <strong>
                              {dateLabel(a.date)} · {a.time}
                            </strong>
                            <small>{a.clinician}</small>
                          </TableCell>
                          <TableCell>
                            <Status s={a.status} />
                          </TableCell>
                          <TableCell>
                            <Button
                              variant="ghost"
                              size="icon"
                              aria-label={'View ' + (a.name ?? 'open slot')}
                              onClick={() => setSelected(a.id)}
                            >
                              <ChevronRight size={17} />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </section>
                {current ? (
                  <aside className="surface detail">
                    <div className="detail-top">
                      <span className="eyebrow">APPOINTMENT DETAILS</span>
                      <button
                        aria-label="Close details"
                        onClick={() => setSelected(null)}
                      >
                        <XCircle size={18} />
                      </button>
                    </div>
                    <h2>{current.name ?? 'Open slot'}</h2>
                    <Status s={current.status} />
                    <dl>
                      <dt>When</dt>
                      <dd>
                        {dateLabel(current.date)} at {current.time}
                      </dd>
                      <dt>Clinician & service</dt>
                      <dd>
                        {current.clinician}
                        <br />
                        {current.service}
                      </dd>
                      <dt>Location</dt>
                      <dd>
                        <MapPin size={13} />
                        {current.location}
                      </dd>
                      {current.phone && (
                        <>
                          <dt>Delivery address</dt>
                          <dd>
                            <Phone size={13} />
                            {current.phone}
                          </dd>
                        </>
                      )}
                    </dl>
                    {['scheduled', 'confirmed', 'filled'].includes(
                      current.status,
                    ) && (
                      <Button
                        variant="outline"
                        className="wide"
                        disabled={busy}
                        onClick={() => setModal('edit')}
                      >
                        <Pencil size={15} />
                        Edit appointment
                      </Button>
                    )}
                    {['scheduled', 'confirmed', 'filled'].includes(
                      current.status,
                    ) && (
                      <div className="info-note">
                        {needsTemplateAck ? (
                          <>
                            <strong>Fixed template test</strong>
                            <p>
                              The WhatsApp message contains Twilio’s sample
                              date, not the appointment details above. Patient
                              replies are reviewed by staff.
                            </p>
                            <label className="consent">
                              <Checkbox
                                checked={templateAccepted}
                                onCheckedChange={setTemplateAccepted}
                              />
                              <span>
                                I understand the message uses a sample date.
                              </span>
                            </label>
                          </>
                        ) : (
                          <>
                            <strong>Free-text message</strong>
                            <p>
                              This provider has no template approval, so the
                              message carries the real date, time, clinician and
                              location above. Replies are still reviewed by
                              staff.
                            </p>
                          </>
                        )}
                      </div>
                    )}
                    {['scheduled', 'confirmed', 'filled'].includes(
                      current.status,
                    ) && (
                      <Button
                        className="primary wide"
                        disabled={
                          busy ||
                          !ws.connection ||
                          (needsTemplateAck && !templateAccepted) ||
                          ws.messages.some(
                            (m) =>
                              m.key ===
                                `reminder:${current.id}:${current.code}` &&
                              m.status !== 'failed',
                          )
                        }
                        onClick={() =>
                          act({
                            action: 'remind',
                            id: current.id,
                            fixedTemplateAccepted: true,
                          })
                        }
                      >
                        <Send size={15} />
                        {ws.messages.some(
                          (m) =>
                            m.key ===
                              `reminder:${current.id}:${current.code}` &&
                            m.status !== 'failed',
                        )
                          ? 'Reminder submitted'
                          : needsTemplateAck
                            ? 'Send fixed test template'
                            : 'Send reminder'}
                      </Button>
                    )}
                    {['scheduled', 'confirmed', 'filled'].includes(
                      current.status,
                    ) &&
                      ws.messages.some(
                        (m) =>
                          m.key === `reminder:${current.id}:${current.code}` &&
                          m.status !== 'failed',
                      ) && (
                        <Button
                          variant="outline"
                          className="wide"
                          disabled={
                            busy ||
                            !ws.connection ||
                            (needsTemplateAck && !templateAccepted)
                          }
                          onClick={() =>
                            act({
                              action: 'remind',
                              id: current.id,
                              again: true,
                              fixedTemplateAccepted: true,
                            })
                          }
                        >
                          <Send size={14} />
                          Send again
                          {(() => {
                            const n = ws.messages.filter(
                              (m) =>
                                m.key?.startsWith(
                                  `reminder:${current.id}:${current.code}:`,
                                ) && m.status !== 'failed',
                            ).length;
                            return n
                              ? ` · ${n} follow-up${n === 1 ? '' : 's'} sent`
                              : '';
                          })()}
                        </Button>
                      )}
                    {['scheduled', 'filled'].includes(current.status) && (
                      <div className="info-note">
                        <p>
                          {needsTemplateAck
                            ? 'After the test phone replies C, sync and review its message below.'
                            : 'A /confirm reply confirms this slot on its own when it is the only one waiting. Use this if the reply was a plain C, or if staff confirmed another way.'}
                        </p>
                        <Button
                          variant="outline"
                          disabled={busy}
                          onClick={() =>
                            act({ action: 'confirm', id: current.id })
                          }
                        >
                          Record confirmation
                        </Button>
                      </div>
                    )}
                    {['scheduled', 'confirmed', 'filled'].includes(
                      current.status,
                    ) && (
                      <div className="info-note">
                        <p>
                          R means a request to reschedule. It never
                          automatically cancels an appointment.
                        </p>
                        <Button
                          variant="outline"
                          disabled={busy}
                          onClick={() =>
                            act({ action: 'cancel', id: current.id })
                          }
                        >
                          Staff: cancel demo appointment
                        </Button>
                        <p>
                          Releases this slot on the website only. No message is
                          sent.
                        </p>
                      </div>
                    )}
                    {current.status === 'cancelled' && (
                      <div className="danger-zone">
                        <p>
                          This booking was cancelled; its slot went back on the
                          board. The record is kept as history until the patient
                          is removed, or deleted here.
                        </p>
                        <Button
                          variant="outline"
                          className="danger wide"
                          disabled={busy}
                          onClick={() =>
                            void execute({
                              action: 'appointmentDelete',
                              id: current.id,
                            })
                              .then(() => setSelected(null))
                              .catch(() => {})
                          }
                        >
                          <XCircle size={14} />
                          Delete cancelled booking
                        </Button>
                      </div>
                    )}
                    {current.status === 'open' && (
                      <>
                        <Button
                          className="primary wide"
                          disabled={busy}
                          onClick={() => setModal('invite')}
                        >
                          <Users size={16} />
                          {needsTemplateAck
                            ? 'Assign standby · website only'
                            : 'Assign standby & notify'}
                        </Button>
                        {/* An open slot has no patient, so there is no edit
                            dialog to hold the delete. Same two-step control,
                            here in the panel. */}
                        <div className="danger-zone">
                          {confirmDelete ? (
                            <>
                              <p>
                                Delete this open slot permanently? It leaves the
                                board. No message is sent.
                              </p>
                              <div className="record-actions">
                                <Button
                                  variant="outline"
                                  className="danger"
                                  disabled={busy}
                                  onClick={() =>
                                    void execute({
                                      action: 'slotDelete',
                                      id: current.id,
                                    })
                                      .then(() => setSelected(null))
                                      .catch(() => {})
                                  }
                                >
                                  Delete slot
                                </Button>
                                <Button
                                  variant="outline"
                                  disabled={busy}
                                  onClick={() => setConfirmDelete(false)}
                                >
                                  Keep it
                                </Button>
                              </div>
                            </>
                          ) : (
                            <Button
                              variant="outline"
                              className="danger wide"
                              disabled={busy}
                              onClick={() => setConfirmDelete(true)}
                            >
                              <XCircle size={14} />
                              Delete open slot…
                            </Button>
                          )}
                        </div>
                      </>
                    )}
                    <div className="message-heading">
                      Test phone activity · all appointments
                    </div>
                    {ws.messages
                      .filter(
                        (m) => !!current.phone && m.phone === current.phone,
                      )
                      .slice(0, 6)
                      .map((m) => (
                        <div className={'message ' + m.direction} key={m.id}>
                          <div>
                            {m.direction === 'inbound'
                              ? 'Received'
                              : 'To ' + m.phone}
                            <span>{timeLabel(m.created)}</span>
                          </div>
                          <p>{m.body}</p>
                          <small>
                            {m.status}
                            {m.error ? ' · ' + m.error : ''}
                          </small>
                        </div>
                      ))}
                    {!ws.messages.some(
                      (m) => !!current.phone && m.phone === current.phone,
                    ) && (
                      <p className="quiet">
                        No messages for this test phone yet.
                      </p>
                    )}
                  </aside>
                ) : (
                  <aside className="surface detail-placeholder">
                    <MessageCircle size={26} />
                    <h3>Select an appointment</h3>
                    <p>
                      Send a fixed template, review replies or assign standby on
                      the website.
                    </p>
                  </aside>
                )}
              </div>
            )}
          </TabsContent>
          <TabsContent value="patients">
            <div className="sectionbar">
              <div>
                <h2>Patient records</h2>
                <p>
                  Every reminder and every standby entry starts from a record
                  here.
                </p>
              </div>
              <Button
                variant="outline"
                onClick={() =>
                  ws.contacts.length ? setModal('patient') : setTab('setup')
                }
              >
                <Plus size={15} />
                Add patient
              </Button>
            </div>
            {!ws.patients.length ? (
              <section className="surface empty-state">
                <Users size={32} />
                <h2>No patient records yet</h2>
                <p>
                  {ws.contacts.length
                    ? 'Add a fictional patient, then book or queue them from their record.'
                    : 'Register a test device in messaging setup first.'}
                </p>
                <Button
                  variant="outline"
                  onClick={() =>
                    ws.contacts.length ? setModal('patient') : setTab('setup')
                  }
                >
                  {ws.contacts.length ? 'Add first patient' : 'Go to setup'}
                </Button>
              </section>
            ) : (
              <div className="schedule-layout">
                <section className="surface table-surface">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Record</TableHead>
                        <TableHead>Patient</TableHead>
                        <TableHead>Activity</TableHead>
                        <TableHead>
                          <span className="sr-only">Details</span>
                        </TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {ws.patients.map((pt) => {
                        const appts = ws.appointments.filter(
                          (a) => a.patient === pt.id,
                        );
                        const waits = ws.standby.filter(
                          (x) => x.patient === pt.id && x.status === 'waiting',
                        );
                        return (
                          <TableRow
                            key={pt.id}
                            className={chosenPatient === pt.id ? 'chosen' : ''}
                          >
                            <TableCell>
                              <strong className="record">{pt.record}</strong>
                            </TableCell>
                            <TableCell>
                              <button
                                className="patient-link"
                                onClick={() => setChosenPatient(pt.id)}
                              >
                                <span className="avatar">
                                  {pt.name
                                    .split(' ')
                                    .map((x: string) => x[0])
                                    .slice(0, 2)
                                    .join('')}
                                </span>
                                <span>
                                  <strong>{pt.name}</strong>
                                  <small>
                                    {reachable(pt)
                                      ? pt.phone
                                      : pt.phone + ' · unreachable'}
                                  </small>
                                </span>
                              </button>
                            </TableCell>
                            <TableCell>
                              <strong>
                                {appts.length} appointment
                                {appts.length === 1 ? '' : 's'}
                              </strong>
                              <small>
                                {waits.length
                                  ? waits.length + ' waiting'
                                  : 'not on standby'}
                              </small>
                            </TableCell>
                            <TableCell>
                              <Button
                                variant="ghost"
                                size="icon"
                                aria-label={'View ' + pt.name}
                                onClick={() => setChosenPatient(pt.id)}
                              >
                                <ChevronRight size={17} />
                              </Button>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </section>
                {patient ? (
                  <aside className="surface detail">
                    <div className="detail-top">
                      <span className="eyebrow">PATIENT RECORD</span>
                      <button
                        aria-label="Close record"
                        onClick={() => setChosenPatient(null)}
                      >
                        <XCircle size={18} />
                      </button>
                    </div>
                    <h2>{patient.name}</h2>
                    <span className="status waiting">{patient.record}</span>
                    <dl>
                      <dt>Delivery address</dt>
                      <dd>
                        <Phone size={13} />
                        {patient.phone}
                      </dd>
                      {patient.notes && (
                        <>
                          <dt>Notes</dt>
                          <dd>{patient.notes}</dd>
                        </>
                      )}
                    </dl>
                    {!reachable(patient) && (
                      <div className="info-note">
                        <strong>No reachable device</strong>
                        <p>
                          {patient.phone} is not a registered recipient, so this
                          patient cannot be booked or reminded. Edit the record
                          to point at a registered device.
                        </p>
                      </div>
                    )}
                    <div className="record-actions">
                      <Button
                        variant="outline"
                        disabled={busy}
                        onClick={() => setModal('patientEdit')}
                      >
                        <Pencil size={14} />
                        Edit record
                      </Button>
                      <Button
                        variant="outline"
                        disabled={busy}
                        onClick={() =>
                          act({ action: 'patientDelete', id: patient.id })
                        }
                      >
                        Remove
                      </Button>
                    </div>
                    <div className="message-heading">Appointments</div>
                    {ws.appointments.filter((a) => a.patient === patient.id)
                      .length ? (
                      ws.appointments
                        .filter((a) => a.patient === patient.id)
                        .map((a) => (
                          <button
                            className="record-row"
                            key={a.id}
                            onClick={() => {
                              setSelected(a.id);
                              setTab('appointments');
                            }}
                          >
                            <span>
                              <strong>
                                {dateLabel(a.date)} · {a.time}
                              </strong>
                              <small>
                                {a.service} · {a.clinician}
                              </small>
                            </span>
                            <Status s={a.status} />
                          </button>
                        ))
                    ) : (
                      <p className="quiet">No appointments yet.</p>
                    )}
                    <div className="message-heading">Standby</div>
                    {ws.standby.filter((x) => x.patient === patient.id)
                      .length ? (
                      ws.standby
                        .filter((x) => x.patient === patient.id)
                        .map((x) => (
                          <div className="record-row" key={x.id}>
                            <span>
                              <strong>{x.service}</strong>
                              <small>{dayLabel(x.date ?? null)}</small>
                            </span>
                            <Status s={x.status} />
                          </div>
                        ))
                    ) : (
                      <p className="quiet">Not on any standby list.</p>
                    )}
                    <div className="message-heading">Messages</div>
                    {ws.messages.filter((m) => m.phone === patient.phone)
                      .length ? (
                      ws.messages
                        .filter((m) => m.phone === patient.phone)
                        .slice(0, 8)
                        .map((m) => (
                          <div className={'message ' + m.direction} key={m.id}>
                            <div>
                              {m.direction === 'inbound' ? 'Received' : 'Sent'}
                              <span>{timeLabel(m.created)}</span>
                            </div>
                            <p>{m.body}</p>
                            <small>{m.status}</small>
                          </div>
                        ))
                    ) : (
                      <p className="quiet">
                        No messages for this device yet. Shared devices show
                        every patient’s messages.
                      </p>
                    )}
                  </aside>
                ) : (
                  <aside className="surface detail-placeholder">
                    <Users size={26} />
                    <h3>Select a patient</h3>
                    <p>
                      Their appointments, standby entries and messages appear
                      here.
                    </p>
                  </aside>
                )}
              </div>
            )}
          </TabsContent>
          <TabsContent value="standby">
            <div className="sectionbar">
              <div>
                <h2>Patients waiting for an opening</h2>
                <p>
                  {needsTemplateAck
                    ? 'Staff assign standby patients here; the fixed template is then sent by hand from the appointment panel.'
                    : 'Staff assign standby patients here; the patient is told which slot they were given and asked to reply /confirm.'}
                </p>
              </div>
              <Button
                variant="outline"
                onClick={() =>
                  ws.patients.filter(reachable).length
                    ? setModal('standby')
                    : setTab('patients')
                }
              >
                <Plus size={15} />
                Add to standby
              </Button>
            </div>
            {!ws.standby.length ? (
              <section className="surface empty-state">
                <Users size={32} />
                <h2>A second chance at an open slot</h2>
                <p>
                  Add fictional standby patients with registered team phone
                  numbers.
                </p>
              </section>
            ) : (
              <div className="day-groups">
                {Array.from(standbyByDay).map(([day, rows]) => {
                  const waiting = rows.filter((w) => w.status === 'waiting');
                  return (
                    <section
                      className="surface table-surface day-group"
                      key={day || 'any'}
                    >
                      <div className="day-heading">
                        <strong>{dayLabel(day || null)}</strong>
                        <span>
                          {waiting.length} waiting
                          {rows.length !== waiting.length
                            ? ` · ${rows.length} total`
                            : ''}
                        </span>
                      </div>
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Patient</TableHead>
                            <TableHead>Service</TableHead>
                            <TableHead>Waiting since</TableHead>
                            <TableHead>Device</TableHead>
                            <TableHead>Status</TableHead>
                            <TableHead>
                              <span className="sr-only">Open</span>
                            </TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {rows.map((w) => {
                            // A booked entry is the appointment it became:
                            // same resource, same id.
                            const booking = w.booking;
                            const bookingExists = ws.appointments.some(
                              (a) => a.id === booking,
                            );
                            const openPatient = () => {
                              setChosenPatient(w.patient);
                              setTab('patients');
                            };
                            return (
                              <TableRow key={w.id}>
                                <TableCell>
                                  <button
                                    className="patient-link"
                                    onClick={openPatient}
                                  >
                                    <span>
                                      <strong>{w.name}</strong>
                                      <small className="record">
                                        {w.record}
                                      </small>
                                    </span>
                                  </button>
                                </TableCell>
                                <TableCell>{w.service}</TableCell>
                                <TableCell>{sinceLabel(w.created)}</TableCell>
                                <TableCell>{w.phone}</TableCell>
                                <TableCell>
                                  <Status s={w.status} />
                                </TableCell>
                                <TableCell>
                                  <div className="row-actions">
                                    {w.status !== 'booked' && (
                                      <Button
                                        variant="ghost"
                                        size="sm"
                                        disabled={busy}
                                        onClick={() => {
                                          setChosenStandby(w.id);
                                          setModal('standbyEdit');
                                        }}
                                      >
                                        <Pencil size={13} />
                                        {w.status === 'released'
                                          ? 'Re-queue'
                                          : 'Edit'}
                                      </Button>
                                    )}
                                    {w.status === 'booked' && bookingExists ? (
                                      <Button
                                        variant="ghost"
                                        size="sm"
                                        onClick={() => {
                                          setSelected(booking);
                                          setTab('appointments');
                                        }}
                                      >
                                        Open appointment
                                        <ChevronRight size={14} />
                                      </Button>
                                    ) : (
                                      <Button
                                        variant="ghost"
                                        size="icon"
                                        aria-label={'Open record of ' + w.name}
                                        onClick={openPatient}
                                      >
                                        <ChevronRight size={17} />
                                      </Button>
                                    )}
                                  </div>
                                </TableCell>
                              </TableRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                    </section>
                  );
                })}
              </div>
            )}
            <div className="info-note">
              Staff can cancel a demo appointment and assign a patient who is
              waiting for that slot’s service.
              {needsTemplateAck
                ? ' No message is sent on assignment with a fixed-template provider; send the template from the appointment panel.'
                : ' On assignment the patient is notified of the new slot and asked to confirm.'}{' '}
              Assignment is never recorded as patient acceptance until the
              patient replies /confirm (or staff record it).
            </div>
          </TabsContent>
          <TabsContent value="setup">
            <div className="sectionbar">
              <div>
                <h2>Your messaging demonstration</h2>
                <p>
                  {active?.fixedTemplate === false
                    ? 'Free-text reminders with one linked chat. No template approval, no paid plan.'
                    : 'Fixed-template WhatsApp testing with one team phone. No upgrade required for this limited scope.'}
                </p>
              </div>
              <ShieldCheck size={27} />
            </div>
            <div className="setup-grid">
              <section className="surface setup-panel">
                <div className="step">01</div>
                {setupProvider === 'telegram' ? (
                  <>
                    <h3>Create your bot</h3>
                    <ol className="guide">
                      <li>
                        In Telegram, open a chat with{' '}
                        <strong>@BotFather</strong>.
                      </li>
                      <li>
                        Send <strong>/newbot</strong> and follow the prompts to
                        name it.
                      </li>
                      <li>
                        BotFather replies with a token like{' '}
                        <strong>123456789:AA…</strong>. Paste it on the right.
                      </li>
                      <li>
                        Keep the bot’s @username: the test device sends the link
                        code to it in step 03.
                      </li>
                      <li>
                        Once linked, a patient can send <strong>/cita</strong>{' '}
                        to see their appointments, <strong>/confirm</strong> to
                        confirm one, and <strong>/reschedule día/mes</strong> to
                        move to another day: the earliest free slot with their
                        clinician that day, or that day’s standby list if it is
                        full — all while this page is open. Register the three
                        in @BotFather with /setcommands so they show in the
                        chat’s command menu.
                      </li>
                    </ol>
                    <div className="info-note">
                      Telegram has no template approval, so reminders carry the
                      real appointment date, time and clinician. Replies are
                      still only recorded for staff review, never acted on
                      automatically.
                    </div>
                    <a
                      className="doc-link"
                      href="https://core.telegram.org/bots/features#botfather"
                      target="_blank"
                      rel="noreferrer"
                    >
                      Official BotFather guide <ArrowUpRight size={14} />
                    </a>
                  </>
                ) : (
                  <>
                    <h3>Connect your trial phone</h3>
                    <ol className="guide">
                      <li>
                        In Twilio, open{' '}
                        <strong>Messaging → WhatsApp → Try out WhatsApp</strong>
                        .
                      </li>
                      <li>
                        Select your verified test phone and scan the current QR
                        code. Keep the Twilio page open until the sending form
                        appears.
                      </li>
                      <li>
                        Choose <strong>Appointment Reminders</strong> and send
                        it once to check delivery.
                      </li>
                      <li>
                        Open the <strong>API</strong> tab and find the sender
                        number and <strong>ContentSid</strong>.
                      </li>
                    </ol>
                    <div className="info-note">
                      The free trial sends a fixed sample reminder. Its date and
                      C/R instructions are not your clinic booking details. This
                      app sends no custom replies or standby notifications.
                    </div>
                    <a
                      className="doc-link"
                      href="https://www.twilio.com/docs/usage/trials/try-out-whatsapp"
                      target="_blank"
                      rel="noreferrer"
                    >
                      Official free-trial guide <ArrowUpRight size={14} />
                    </a>
                  </>
                )}
              </section>
              <section className="surface setup-panel">
                <div className="step">02</div>
                <h3>Connect securely</h3>
                <p>
                  Enter credentials here, not in chat. Your Auth Token is
                  encrypted on the server. Saving verifies access to message
                  history without sending a message.
                </p>
                <form
                  key={setupProvider}
                  onSubmit={(e) =>
                    void submit(e, 'connect', { provider: setupProvider })
                  }
                >
                  <label className="field">
                    Messaging provider
                    <NativeSelect
                      value={setupProvider}
                      onChange={(e) => setDraftProvider(e.target.value)}
                    >
                      {ws.providers.map((p) => (
                        <NativeSelectOption key={p.id} value={p.id}>
                          {p.label}
                        </NativeSelectOption>
                      ))}
                    </NativeSelect>
                  </label>
                  {setupProvider === 'telegram' ? (
                    <Field
                      label="Bot token from @BotFather"
                      name="token"
                      type="password"
                      placeholder="123456789:AA…"
                    />
                  ) : (
                    <>
                      <Field label="Account SID" name="sid" placeholder="AC…" />
                      <Field
                        label="Auth Token"
                        name="token"
                        type="password"
                        placeholder="From your Twilio account dashboard"
                      />
                      <Field
                        label="Trial sender number (From)"
                        name="sender"
                        placeholder="+1737…"
                        defaultValue={ws.connection?.sender}
                      />
                      <Field
                        label="Appointment Reminders Content SID"
                        name="contentSid"
                        placeholder="HX…"
                        defaultValue="HXfe5ab5f00277942d4d4200328b4d403c"
                      />
                    </>
                  )}
                  {ws.connection &&
                    ws.connection.provider !== setupProvider && (
                      <p className="error-text">
                        Switching provider clears the registered recipients,
                        because their addresses belong to the old one.
                      </p>
                    )}
                  <Button
                    type="submit"
                    className="primary wide"
                    disabled={busy || !ws.secureStorage}
                  >
                    {busy ? 'Checking…' : 'Verify & save connection'}
                  </Button>
                </form>
                {!ws.secureStorage && (
                  <p className="error-text">
                    Secure storage is not ready. Do not enter credentials yet.
                  </p>
                )}
                {ws.connection && (
                  <p className="success-text">
                    Credentials saved · {ws.connection.sender}
                  </p>
                )}
              </section>
              <section className="surface setup-panel">
                <div className="step">03</div>
                {active?.linkedContacts ? (
                  <>
                    <h3>Link the test device</h3>
                    <p>
                      Telegram identifies people by chat id, and a bot only
                      learns it once that person writes to it. Generate a code,
                      then send it from the test device.
                    </p>
                    <form onSubmit={(e) => void submit(e, 'link')}>
                      <Field
                        label="Contact label"
                        name="name"
                        placeholder="Team Telegram"
                      />
                      <Button
                        type="submit"
                        variant="outline"
                        disabled={busy || !ws.connection}
                      >
                        Generate link code
                      </Button>
                    </form>
                    {ws.connection?.linkCode && (
                      <div className="info-note">
                        <strong>
                          Send this to {ws.connection.sender} on Telegram
                        </strong>
                        <p className="link-code">
                          /start {ws.connection.linkCode}
                        </p>
                        <p>
                          Then sync replies. The code binds whichever chat sends
                          it, and works once.
                        </p>
                      </div>
                    )}
                  </>
                ) : (
                  <>
                    <h3>Register one team test phone</h3>
                    <p>
                      Use the same verified recipient as in Twilio. One phone
                      plays the fictional patients in this free demonstration.
                    </p>
                    <form onSubmit={(e) => void submit(e, 'contact')}>
                      <Field
                        label="Team contact label"
                        name="name"
                        placeholder="Team test phone"
                      />
                      <Field
                        label="Verified WhatsApp recipient (To)"
                        name="phone"
                        type="tel"
                        placeholder="+56…"
                      />
                      <label className="consent">
                        <Checkbox
                          checked={consent}
                          onCheckedChange={setConsent}
                        />
                        <span>
                          This team member agreed to test messages and linked
                          this phone in Twilio.
                        </span>
                      </label>
                      <Button
                        type="submit"
                        variant="outline"
                        disabled={busy || !consent}
                      >
                        Register test phone
                      </Button>
                    </form>
                  </>
                )}
                <div className="contact-list">
                  {ws.contacts.map((c) => (
                    <div key={c.id}>
                      <div>
                        <strong>{c.name}</strong>
                        <small>{c.phone}</small>
                      </div>
                      <span>
                        {c.lastInbound
                          ? 'Reply received'
                          : 'No reply synced yet'}
                      </span>
                    </div>
                  ))}
                </div>
              </section>
              <section className="surface setup-panel">
                <div className="step">04</div>
                <h3>Run the free demonstration</h3>
                <ol className="guide">
                  <li>
                    Create a fictional appointment using the registered
                    recipient. Select the appointment to open its details.
                  </li>
                  {needsTemplateAck ? (
                    <li>
                      Acknowledge the fixed sample date, then click{' '}
                      <strong>Send fixed test template</strong>.
                    </li>
                  ) : (
                    <li>
                      Click <strong>Send reminder</strong>. It carries this
                      appointment’s real date, time and clinician.
                    </li>
                  )}
                  {needsTemplateAck ? (
                    <>
                      <li>
                        Reply <strong>C</strong> or <strong>R</strong> from the
                        test device. Keep this page open and sync replies.
                      </li>
                      <li>
                        For C, review the reply and click{' '}
                        <strong>Record confirmation</strong>. R is only a
                        rescheduling request.
                      </li>
                    </>
                  ) : (
                    <>
                      <li>
                        Reply <strong>/confirm</strong> from the test device.
                        Keep this page open: within about 15 seconds the slot
                        confirms itself and the patient gets an acknowledgement.
                      </li>
                      <li>
                        If the same chat has two slots waiting, nothing is
                        confirmed automatically — review and click{' '}
                        <strong>Record confirmation</strong>. R is only a
                        rescheduling request.
                      </li>
                    </>
                  )}
                  <li>
                    To show cancellation and standby, use{' '}
                    <strong>Staff: cancel demo appointment</strong>, then assign
                    a fictional standby patient. These steps send no messages.
                  </li>
                </ol>
                <div className="info-note">
                  No reply automatically changes a booking. This page polls for
                  replies every 15 seconds while visible. Live API access still
                  needs a real account test; failures appear here. This app
                  cannot upgrade your plan or purchase credits.
                </div>
                <Button
                  variant="outline"
                  disabled={busy || !ws.connection}
                  onClick={() => act({ action: 'sync' })}
                >
                  <RefreshCw size={15} />
                  Sync replies now
                </Button>
              </section>
            </div>
            <section className="surface activity-panel">
              <h3>FHIR data</h3>
              <p className="quiet">
                Everything clinical here is stored as HL7 FHIR R4. Export it as
                one Bundle, or import a Bundle from another system: each
                resource gets a new id, references inside the file are rewritten
                to match, and anything this system does not hold is skipped and
                listed. Messages are not exported.
              </p>
              <div className="record-actions fhir-actions">
                <Button
                  variant="outline"
                  disabled={busy}
                  onClick={() => void exportBundle()}
                >
                  Export FHIR Bundle
                </Button>
                <input
                  ref={bundleFile}
                  type="file"
                  accept="application/json,.json"
                  hidden
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    e.target.value = '';
                    if (f) void importBundle(f);
                  }}
                />
                <Button
                  variant="outline"
                  disabled={busy}
                  onClick={() => bundleFile.current?.click()}
                >
                  Import FHIR Bundle…
                </Button>
              </div>
              {importReport && (
                <div className="info-note import-report">
                  <strong>Last import</strong>
                  <p>
                    {Object.entries(importReport.imported).length
                      ? 'Added ' +
                        Object.entries(importReport.imported)
                          .map(([t, n]) => `${n} ${t}`)
                          .join(' · ')
                      : 'Nothing was added.'}
                  </p>
                  {Object.entries(importReport.matched).length > 0 && (
                    <p>
                      Already here, reused:{' '}
                      {Object.entries(importReport.matched)
                        .map(([t, n]) => `${n} ${t}`)
                        .join(' · ')}
                    </p>
                  )}
                  {importReport.skipped.length > 0 && (
                    <ul>
                      {importReport.skipped.map((x, i) => (
                        <li key={i}>
                          {x.type}
                          {x.id ? ` ${x.id}` : ''}: {x.reason}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              )}
            </section>
            {ws.messages.length > 0 && (
              <section className="surface activity-panel">
                <h3>Recent message activity</h3>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Time</TableHead>
                      <TableHead>Direction</TableHead>
                      <TableHead>Test phone</TableHead>
                      <TableHead>State</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {ws.messages.slice(0, 20).map((m) => (
                      <TableRow key={m.id}>
                        <TableCell>{timeLabel(m.created)}</TableCell>
                        <TableCell>{m.direction}</TableCell>
                        <TableCell>{m.phone}</TableCell>
                        <TableCell>
                          {m.status}
                          {m.error && (
                            <small className="error-text">{m.error}</small>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </section>
            )}
          </TabsContent>
        </Tabs>
        <footer>
          CareQueue pilot <span>Clinic timezone: America/Santiago</span>
        </footer>
      </div>
      <Dialog
        open={modal !== null}
        onOpenChange={(v) => {
          if (!v) setModal(null);
        }}
      >
        <DialogContent className="form-dialog">
          <DialogTitle>
            {
              {
                appointment: 'New appointment',
                edit: 'Edit appointment',
                standby: 'Add to standby list',
                standbyEdit: 'Edit standby entry',
                patient: 'New patient record',
                patientEdit: 'Edit patient record',
                invite: 'Choose a standby patient',
              }[modal ?? 'invite']
            }
          </DialogTitle>
          <DialogDescription>
            {modal === 'invite'
              ? needsTemplateAck
                ? `Patients waiting for ${current?.service}. No message is sent now; send the fixed template from the appointment panel. This is not patient acceptance.`
                : `Patients waiting for ${current?.service}. They will be told which slot they were given and asked to reply /confirm. Not patient acceptance until they do.`
              : modal === 'edit'
                ? 'Editing sends no message. Changing the slot, the patient or their device clears a recorded confirmation, because nobody agreed to the new arrangement.'
                : modal === 'standbyEdit'
                  ? 'Change who is waiting, for what, or on which day. Saving puts the entry on the list as waiting. Editing sends no message. An entry currently booked into a slot cannot be edited, only removed.'
                  : modal === 'patient' || modal === 'patientEdit'
                    ? 'Fictional patient data only. The delivery address must be a device registered in messaging setup; several patients may share one.'
                    : 'Pick an existing patient record. Create one on the Patients tab if it is missing.'}
          </DialogDescription>
          {modal === 'invite' ? (
            <div className="candidate-list">
              {ws.standby
                .filter(forThisSlot)
                .sort(standbyRank(current?.date ?? null))
                .map((w) => (
                  <div key={w.id}>
                    <div>
                      <strong>{w.name}</strong>
                      <small>
                        {dayLabel(w.date ?? null)} · {w.service} · waiting since{' '}
                        {sinceLabel(w.created)}
                      </small>
                      {current && w.date && w.date !== current.date && (
                        <small className="quiet">
                          Waiting for {dayLabel(w.date)}, not this slot’s day.
                        </small>
                      )}
                      {!reachable(w) && (
                        <small className="error-text">
                          No reachable device: {w.phone} is not registered. Edit
                          the patient record first.
                        </small>
                      )}
                    </div>
                    <Button
                      className="primary"
                      disabled={busy || !reachable(w)}
                      onClick={() =>
                        void execute({
                          action: 'invite',
                          id: current?.id,
                          candidate: w.id,
                        })
                          .then(() => setModal(null))
                          .catch(() => {})
                      }
                    >
                      <Send size={14} />
                      {needsTemplateAck
                        ? 'Assign on website'
                        : 'Assign & notify'}
                    </Button>
                  </div>
                ))}
              {!ws.standby.some(forThisSlot) && (
                <p>
                  No patients are waiting for {current?.service}. Add one in the
                  Standby list first
                  {ws.standby.some((w) => w.status === 'waiting')
                    ? ', or edit a waiting entry to this service.'
                    : '.'}
                </p>
              )}
            </div>
          ) : (
            <form
              key={
                modal +
                ':' +
                (current?.id ?? chosenPatient ?? chosenStandby ?? '')
              }
              onSubmit={(e) =>
                void submit(
                  e,
                  {
                    standby: 'standby',
                    standbyEdit: 'standbyEdit',
                    edit: 'update',
                    patient: 'patient',
                    patientEdit: 'patientEdit',
                    appointment: 'appointment',
                  }[modal ?? 'appointment'] ?? 'appointment',
                  modal === 'edit'
                    ? { id: current?.id }
                    : modal === 'patientEdit'
                      ? { id: patient?.id }
                      : modal === 'standbyEdit'
                        ? { id: standbyRow?.id }
                        : {},
                )
              }
            >
              {modal === 'patient' || modal === 'patientEdit' ? (
                <>
                  <Field
                    label="Fictional patient name"
                    name="name"
                    placeholder="e.g. Elena Rojas"
                    defaultValue={
                      modal === 'patientEdit' ? patient?.name : undefined
                    }
                  />
                  <label className="field">
                    Delivery address (registered device)
                    <NativeSelect
                      name="phone"
                      defaultValue={
                        modal === 'patientEdit'
                          ? patient?.phone
                          : ws.contacts[0]?.phone
                      }
                    >
                      {ws.contacts.map((c) => (
                        <NativeSelectOption key={c.id} value={c.phone}>
                          {c.name} · {c.phone}
                        </NativeSelectOption>
                      ))}
                    </NativeSelect>
                  </label>
                  <Field
                    label="Notes (optional)"
                    name="notes"
                    required={false}
                    placeholder="e.g. prefers morning slots"
                    defaultValue={
                      modal === 'patientEdit'
                        ? (patient?.notes ?? undefined)
                        : undefined
                    }
                  />
                  <p className="input-help">
                    Several patients may share one device. That is how a single
                    test phone plays a whole waiting room.
                  </p>
                </>
              ) : (
                <>
                  <label className="field">
                    Patient
                    <NativeSelect
                      name="patient"
                      defaultValue={
                        modal === 'edit'
                          ? (current?.patient ?? undefined)
                          : modal === 'standbyEdit'
                            ? standbyRow?.patient
                            : ws.patients.filter(reachable)[0]?.id
                      }
                    >
                      {ws.patients.filter(reachable).map((pt) => (
                        <NativeSelectOption key={pt.id} value={pt.id}>
                          {pt.record} · {pt.name}
                        </NativeSelectOption>
                      ))}
                    </NativeSelect>
                  </label>
                  {!ws.patients.filter(reachable).length && (
                    <p className="error-text">
                      No patient has a reachable device. Add or fix one on the
                      Patients tab first.
                    </p>
                  )}
                  {modal !== 'standby' && modal !== 'standbyEdit' && (
                    <>
                      <div className="two-fields">
                        <Field
                          label="Date"
                          name="date"
                          type="date"
                          value={draft.date}
                          onChange={(date) => setDraft({ ...draft, date })}
                        />
                        <Field
                          label="Time (Chile)"
                          name="time"
                          type="time"
                          value={draft.time}
                          onChange={(time) => setDraft({ ...draft, time })}
                          step={TIMETABLE.step * 60}
                          min={TIMETABLE.open}
                          max={TIMETABLE.close}
                        />
                      </div>
                      <Field
                        label="Clinician"
                        name="clinician"
                        placeholder="e.g. Dr. Sofia Morales"
                        value={draft.clinician}
                        onChange={(clinician) =>
                          setDraft({ ...draft, clinician })
                        }
                      />
                    </>
                  )}
                  {(() => {
                    // A record made before the menu, or with a service typed
                    // in by hand, keeps its value selectable so an edit does
                    // not silently drop it.
                    const onRecord =
                      modal === 'edit'
                        ? current?.service
                        : modal === 'standbyEdit'
                          ? standbyRow?.service
                          : undefined;
                    const offMenu = !!onRecord && !services.includes(onRecord);
                    return (
                      <label className="field">
                        Service
                        <NativeSelect
                          name="service"
                          required
                          defaultValue={onRecord ?? ''}
                        >
                          <NativeSelectOption value="" disabled>
                            Choose a service…
                          </NativeSelectOption>
                          {offMenu && (
                            <NativeSelectOptGroup label="Currently on this record">
                              <NativeSelectOption value={onRecord}>
                                {onRecord}
                              </NativeSelectOption>
                            </NativeSelectOptGroup>
                          )}
                          {programs.map((p) => (
                            <NativeSelectOptGroup key={p.name} label={p.name}>
                              {p.services.map((s) => (
                                <NativeSelectOption key={s} value={s}>
                                  {s}
                                </NativeSelectOption>
                              ))}
                            </NativeSelectOptGroup>
                          ))}
                        </NativeSelect>
                      </label>
                    );
                  })()}
                  {(modal === 'standby' || modal === 'standbyEdit') && (
                    <>
                      <Field
                        label="Waiting for which day (optional)"
                        name="date"
                        type="date"
                        required={false}
                        defaultValue={
                          modal === 'standbyEdit'
                            ? (standbyRow?.date ?? undefined)
                            : undefined
                        }
                      />
                      <p className="input-help">
                        Leave blank if any day will do. The standby list is
                        grouped by this date.
                      </p>
                    </>
                  )}
                  {modal !== 'standby' && modal !== 'standbyEdit' && (
                    <>
                      <Field
                        label="Location"
                        name="location"
                        placeholder="e.g. Demo Health Center, Room 2"
                        value={draft.location}
                        onChange={(location) =>
                          setDraft({ ...draft, location })
                        }
                      />
                      {/* The clinician's day, once the form says which one:
                          taken starts greyed, free ones one click away. */}
                      {day ? (
                        <div className="availability">
                          <small>
                            {draft.clinician.trim()} · {draft.location.trim()} ·{' '}
                            {dayLabel(draft.date)}
                            {day.length
                              ? ` · ${day.filter((x) => x.taken).length} of ${day.length} slots taken`
                              : ''}
                          </small>
                          {day.length ? (
                            <div className="chips">
                              {day.map((x) => {
                                const own = x.time === ownTime;
                                const taken = x.taken && !own;
                                return (
                                  <button
                                    type="button"
                                    key={x.time}
                                    className={
                                      'chip' +
                                      (taken ? ' taken' : '') +
                                      (draft.time === x.time ? ' chosen' : '')
                                    }
                                    disabled={taken}
                                    title={
                                      taken
                                        ? 'Already booked'
                                        : own
                                          ? 'This appointment’s current time'
                                          : 'Free'
                                    }
                                    onClick={() =>
                                      setDraft({ ...draft, time: x.time })
                                    }
                                  >
                                    {x.time}
                                  </button>
                                );
                              })}
                            </div>
                          ) : (
                            <p className="error-text">
                              The centre is closed that day ({hoursLabel()}).
                            </p>
                          )}
                        </div>
                      ) : (
                        <p className="input-help">
                          Slots are {TIMETABLE.step} minutes, {hoursLabel()}.
                          Fill in clinician, location and date to see which are
                          taken.
                        </p>
                      )}
                    </>
                  )}
                </>
              )}
              <Button
                type="submit"
                className="primary wide"
                disabled={
                  busy ||
                  (modal !== 'patient' &&
                    modal !== 'patientEdit' &&
                    !ws.patients.filter(reachable).length)
                }
              >
                {busy
                  ? 'Saving…'
                  : {
                      standby: 'Add to standby',
                      standbyEdit: 'Save entry',
                      edit: 'Save changes',
                      patient: 'Create patient record',
                      patientEdit: 'Save record',
                      appointment: 'Save appointment',
                    }[modal ?? 'appointment']}
              </Button>
              <p className="input-help">Saving does not send a message.</p>
              {modal === 'standbyEdit' && standbyRow && (
                <div className="danger-zone">
                  {confirmDelete ? (
                    <>
                      <p>
                        Remove this standby entry? The patient record stays. No
                        message is sent.
                      </p>
                      <div className="record-actions">
                        <Button
                          type="button"
                          variant="outline"
                          className="danger"
                          disabled={busy}
                          onClick={() =>
                            void execute({
                              action: 'standbyDelete',
                              id: standbyRow.id,
                            })
                              .then(() => {
                                setModal(null);
                                setChosenStandby(null);
                              })
                              .catch(() => {})
                          }
                        >
                          Remove entry
                        </Button>
                        <Button
                          type="button"
                          variant="outline"
                          disabled={busy}
                          onClick={() => setConfirmDelete(false)}
                        >
                          Keep it
                        </Button>
                      </div>
                    </>
                  ) : (
                    <Button
                      type="button"
                      variant="outline"
                      className="danger wide"
                      disabled={busy}
                      onClick={() => setConfirmDelete(true)}
                    >
                      <XCircle size={14} />
                      Remove from standby…
                    </Button>
                  )}
                </div>
              )}
              {modal === 'edit' && current && (
                <div className="danger-zone">
                  {confirmDelete ? (
                    <>
                      <p>
                        Delete this appointment permanently? Cancelling keeps
                        the slot open on the board; deleting removes the booking
                        entirely. Message history is kept. No message is sent.
                      </p>
                      <div className="record-actions">
                        <Button
                          type="button"
                          variant="outline"
                          className="danger"
                          disabled={busy}
                          onClick={() =>
                            void execute({
                              action: 'appointmentDelete',
                              id: current.id,
                            })
                              .then(() => {
                                setModal(null);
                                setSelected(null);
                              })
                              .catch(() => {})
                          }
                        >
                          Delete permanently
                        </Button>
                        <Button
                          type="button"
                          variant="outline"
                          disabled={busy}
                          onClick={() => setConfirmDelete(false)}
                        >
                          Keep it
                        </Button>
                      </div>
                    </>
                  ) : (
                    <Button
                      type="button"
                      variant="outline"
                      className="danger wide"
                      disabled={busy}
                      onClick={() => setConfirmDelete(true)}
                    >
                      <XCircle size={14} />
                      Delete appointment…
                    </Button>
                  )}
                </div>
              )}
            </form>
          )}
        </DialogContent>
      </Dialog>
    </main>
  );
}
