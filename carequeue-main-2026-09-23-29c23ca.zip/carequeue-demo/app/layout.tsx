import type { Metadata } from 'next';
import { Geist, Geist_Mono } from 'next/font/google';
import './globals.css';

const geistSans = Geist({
  variable: '--font-geist-sans',
  subsets: ['latin'],
});

const geistMono = Geist_Mono({
  variable: '--font-geist-mono',
  subsets: ['latin'],
});

export const metadata: Metadata = {
  title: 'CareQueue | Concepción',
  description:
    'WhatsApp appointment and standby coordination for a team demonstration.',
  icons: {
    icon: [{ url: '/favicon.png', type: 'image/png', sizes: '64x64' }],
    apple: [{ url: '/apple-touch-icon.png', sizes: '180x180' }],
  },
};

// "ResizeObserver loop completed with undelivered notifications" is the
// browser deferring one observer pass to the next frame after a layout change
// re-triggered observation in the same frame. It is benign — Chrome's own
// DevTools hides it — but it arrives as a window `error` event carrying only a
// message, and vinext's dev overlay reports anything with a message, so it
// pops a full-screen error over the demo. Listeners on the same target run in
// registration order, and the overlay installs from a deferred module script,
// so an inline script here runs first and can stop the event before it gets
// there. Development only; production has no overlay.
const swallowResizeObserverNoise = `window.addEventListener('error',function(e){if(/^ResizeObserver loop/.test(e.message||'')){e.stopImmediatePropagation();e.preventDefault();}});`;

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        {process.env.NODE_ENV !== 'production' && (
          <script
            dangerouslySetInnerHTML={{ __html: swallowResizeObserverNoise }}
          />
        )}
        {children}
      </body>
    </html>
  );
}
