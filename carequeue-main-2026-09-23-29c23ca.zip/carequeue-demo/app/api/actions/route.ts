import { action, owner } from '@/lib/fhir/backend';
export const dynamic = 'force-dynamic';
export async function POST(req: Request) {
  try {
    const origin = req.headers.get('origin');
    if (!origin || origin !== new URL(req.url).origin)
      return Response.json(
        { error: 'Request origin not allowed.' },
        { status: 403 },
      );
    if (!req.headers.get('content-type')?.startsWith('application/json'))
      return Response.json({ error: 'JSON required.' }, { status: 415 });
    const raw = await req.text();
    if (raw.length > 12000) throw Error('Request too large.');
    return Response.json(await action(await owner(), JSON.parse(raw)), {
      headers: { 'Cache-Control': 'no-store' },
    });
  } catch (e) {
    return Response.json(
      { error: e instanceof Error ? e.message : 'Request failed.' },
      { status: 400 },
    );
  }
}
