import { owner, state } from '@/lib/fhir/backend';
export const dynamic = 'force-dynamic';
export async function GET() {
  try {
    return Response.json(await state(await owner()), {
      headers: { 'Cache-Control': 'no-store' },
    });
  } catch (e) {
    return Response.json(
      { error: e instanceof Error ? e.message : 'Workspace unavailable.' },
      { status: 401 },
    );
  }
}
