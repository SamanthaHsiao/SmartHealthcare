import { owner } from '@/lib/fhir/backend';
import { exportBundle, importBundle } from '@/lib/fhir/bundle';
export const dynamic = 'force-dynamic';

// The workspace as a FHIR Bundle: GET downloads it, POST takes one in.
// Same sign-in and owner scoping as every other route; a larger body than
// the actions route allows, because a Bundle is a whole workspace.

export async function GET() {
  try {
    const bundle = await exportBundle(await owner());
    const day = bundle.timestamp!.slice(0, 10);
    return Response.json(bundle, {
      headers: {
        'Cache-Control': 'no-store',
        'Content-Type': 'application/fhir+json',
        'Content-Disposition': `attachment; filename="carequeue-${day}.json"`,
      },
    });
  } catch (e) {
    return Response.json(
      { error: e instanceof Error ? e.message : 'Export failed.' },
      { status: 401 },
    );
  }
}

export async function POST(req: Request) {
  try {
    const origin = req.headers.get('origin');
    if (!origin || origin !== new URL(req.url).origin)
      return Response.json(
        { error: 'Request origin not allowed.' },
        { status: 403 },
      );
    const type = req.headers.get('content-type') ?? '';
    if (
      !type.startsWith('application/json') &&
      !type.startsWith('application/fhir+json')
    )
      return Response.json({ error: 'JSON required.' }, { status: 415 });
    const raw = await req.text();
    if (raw.length > 5_000_000)
      throw Error(
        'That file is over 5 MB. Split the bundle and import it in parts.',
      );
    let bundle: unknown;
    try {
      bundle = JSON.parse(raw);
    } catch {
      throw Error('That file is not valid JSON.');
    }
    return Response.json(await importBundle(await owner(), bundle), {
      headers: { 'Cache-Control': 'no-store' },
    });
  } catch (e) {
    return Response.json(
      { error: e instanceof Error ? e.message : 'Import failed.' },
      { status: 400 },
    );
  }
}
