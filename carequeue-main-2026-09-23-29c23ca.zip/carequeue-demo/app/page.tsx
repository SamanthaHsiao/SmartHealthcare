import CareQueue from './carequeue';
export default function Page() {
  return <CareQueue />;
}
