import {
  field,
  isConfirmCommand,
  normalizePhone,
  parseRescheduleCommand,
} from './rules';

// One messaging provider per workspace. The rest of the app addresses a
// recipient, sends a reminder and pulls replies without knowing which one is
// active; only this file talks to a vendor API.

export type Credentials = Record<string, any>;

export type Inbound = {
  // Stable per-provider id, used to deduplicate what sync writes.
  sid: string;
  address: string;
  body: string;
  at: number;
  // Telegram only: "/start <code>" carries a pending link.
  linkCode?: string;
  linkName?: string;
  // The patient asked for their appointments ("/cita"). Answered read-only.
  inquiry?: boolean;
  // The patient confirmed ("/confirm"). Acted on when unambiguous.
  confirm?: boolean;
  // The patient asked to move ("/reschedule [day]"). `arg` is what followed.
  reschedule?: { arg: string | null };
};

// What a reschedule reply is about.
export type RescheduleOutcome =
  | 'ask' // no day given: ask for one
  | 'bad-day' // could not read the day
  | 'need-day' // "any day" is not enough: a specific day is needed
  | 'closed' // the centre does not see patients that day
  | 'moved' // rebooked into the earliest free slot of that day
  | 'done' // day full: slot released, patient queued for it
  | 'already-queued' // day full: slot released; was already queued for it
  | 'nothing' // no appointment to move
  | 'ambiguous'; // more than one appointment

// What a patient on one address currently has, for an inquiry reply.
export type Card = {
  name: string;
  appointments: (Slot & { status: string })[];
  standby: { service: string; date: string | null }[];
};

export type Outbound = { sid: string; status: string; body: string };

export type Slot = {
  name: string;
  date: string;
  time: string;
  clinician: string;
  service: string;
  location: string;
};

export type Provider = {
  id: string;
  label: string;
  // Whether the vendor forces a pre-approved template with a sample date that
  // staff must acknowledge before sending.
  fixedTemplate: boolean;
  // Whether contacts are bound by an in-chat link code rather than typed in.
  linkedContacts: boolean;
  // How many recipients this provider may register, or null for no limit.
  // A vendor limit, not a product rule: the Twilio trial only reaches one
  // linked recipient, while a Telegram bot can reach anyone who starts it.
  maxContacts: number | null;
  // What kind of contact point an address is, in FHIR's terms: a phone
  // number for WhatsApp, `other` for a Telegram chat id.
  telecom: 'phone' | 'other';
  credentials(data: any): Credentials;
  // Prove the credentials work without sending a message. Returns the sending
  // identity to display.
  verify(c: Credentials): Promise<string>;
  address(value: unknown): string;
  // `reason` lets a free-text provider explain why the message is coming —
  // 'standby' means the slot was just assigned from the waiting list.
  reminder(slot: Slot, reason?: 'standby'): string;
  // Compose the read-only answer to "/cita". Only a free-text provider can
  // say anything useful, so a fixed-template provider leaves this out and the
  // inquiry is simply recorded like any other reply.
  inquiry?(cards: Card[]): string;
  // What to tell the patient after "/confirm": it took; it was already
  // confirmed; there was nothing to confirm; or more than one slot was waiting
  // and staff will settle it. `slots` carries the slot(s) the message is
  // about — the one just confirmed, or the ones already confirmed.
  acknowledge?(
    outcome: 'confirmed' | 'already' | 'nothing' | 'ambiguous',
    slots: Slot[],
  ): string;
  // What to tell the patient after "/reschedule". `released` is the slot
  // they gave up, `moved` the one they were rebooked into, `day` the day
  // they asked for.
  rescheduleAck?(
    outcome: RescheduleOutcome,
    ctx: { released: Slot | null; moved?: Slot | null; day: string | null },
  ): string;
  send(c: Credentials, address: string, body: string): Promise<Outbound>;
  inbound(
    c: Credentials,
    cursor: string | null,
    since: number,
    synced: number,
  ): Promise<{ messages: Inbound[]; cursor: string | null }>;
  // Twilio reports delivery asynchronously; Telegram does not.
  status?(
    c: Credentials,
    sid: string,
  ): Promise<{ status: string; error: string | null }>;
};

// A failure is `definitive` when the vendor answered and rejected us: the
// message certainly did not go out, so retrying is safe. A network or timeout
// failure leaves delivery unknown and must not be retried blindly.
function definitive(message: string) {
  const err: any = Error(message);
  err.definitive = true;
  return err;
}

async function json(
  url: string,
  init: RequestInit,
  reject: (data: any, status: number) => string,
) {
  const r = await fetch(url, { ...init, signal: AbortSignal.timeout(12000) });
  const data: any = await r.json();
  if (!r.ok || data?.ok === false) throw definitive(reject(data, r.status));
  return data;
}

const twilio: Provider = {
  id: 'twilio',
  label: 'Twilio WhatsApp (free trial)',
  fixedTemplate: true,
  linkedContacts: false,
  maxContacts: 1,
  telecom: 'phone',
  credentials(data) {
    const sid = field(data.sid, 'Account SID');
    if (!/^AC[0-9a-f]{32}$/i.test(sid))
      throw Error('Use the Account SID beginning with AC.');
    const token = field(data.token, 'Auth Token');
    if (!/^[0-9a-f]{32}$/i.test(token))
      throw Error('Use the Twilio Auth Token from your account.');
    const sender = normalizePhone(data.sender);
    const contentSid = field(data.contentSid, 'Template Content SID');
    if (!/^HX[0-9a-f]{32}$/i.test(contentSid))
      throw Error(
        'Copy the ContentSid from the Appointment Reminders API example.',
      );
    return { sid, token, sender, contentSid };
  },
  async verify(c) {
    await call(c, 'Messages.json?PageSize=1');
    return c.sender;
  },
  address: normalizePhone,
  reminder() {
    return 'Twilio fixed Appointment Reminders template (sample date; not this booking).';
  },
  async send(c, address, body) {
    const m = await call(
      c,
      'Messages.json',
      new URLSearchParams({
        From: 'whatsapp:' + c.sender,
        To: 'whatsapp:' + address,
        ContentSid: c.contentSid,
      }),
    );
    return { sid: m.sid, status: m.status ?? 'queued', body: m.body ?? body };
  },
  async inbound(c, _cursor, since, synced) {
    let path =
      'Messages.json?' +
      new URLSearchParams({
        To: 'whatsapp:' + c.sender,
        PageSize: '100',
        'DateSent>': new Date(Math.max(since, synced - 86400000))
          .toISOString()
          .slice(0, 10),
      });
    const messages: Inbound[] = [];
    for (let page = 0; page < 10; page++) {
      const data = await call(c, path);
      for (const m of data.messages ?? []) {
        if (m.direction !== 'inbound' || !m.sid) continue;
        const at = Date.parse(
          m.date_sent || m.dateSent || m.date_created || m.dateCreated,
        );
        if (!Number.isFinite(at) || at < since) continue;
        const body = String(m.body ?? '').slice(0, 1600);
        const resched = parseRescheduleCommand(body);
        messages.push({
          sid: m.sid,
          address: String(m.from).replace(/^whatsapp:/, ''),
          body,
          at,
          ...(isConfirmCommand(body) ? { confirm: true } : {}),
          ...(resched ? { reschedule: resched } : {}),
        });
      }
      if (!data.next_page_uri) break;
      const expected = `/2010-04-01/Accounts/${c.sid}/`;
      if (!data.next_page_uri.startsWith(expected))
        throw Error('Unexpected message history response.');
      if (page === 9)
        throw Error(
          'Too much message history. Use a dedicated test account for this demo.',
        );
      path = data.next_page_uri.slice(expected.length);
    }
    return { messages, cursor: null };
  },
  async status(c, sid) {
    const m = await call(c, `Messages/${sid}.json`);
    const code = m.error_code ?? m.errorCode;
    return { status: m.status, error: code ? 'Twilio error ' + code : null };
  },
};

function call(c: Credentials, path: string, body?: URLSearchParams) {
  return json(
    `https://api.twilio.com/2010-04-01/Accounts/${c.sid}/${path}`,
    {
      method: body ? 'POST' : 'GET',
      headers: {
        Authorization: 'Basic ' + btoa(c.sid + ':' + c.token),
        ...(body
          ? { 'Content-Type': 'application/x-www-form-urlencoded' }
          : {}),
      },
      body: body?.toString(),
    },
    (data, status) =>
      `Twilio rejected the request (code ${data.code ?? status}). Check trial access, the fixed template and your currently linked recipient.`,
  );
}

const DIAS = ['dom', 'lun', 'mar', 'mié', 'jue', 'vie', 'sáb'];
const MESES = [
  'ene',
  'feb',
  'mar',
  'abr',
  'may',
  'jun',
  'jul',
  'ago',
  'sept',
  'oct',
  'nov',
  'dic',
];
function diaLabel(date: string) {
  const d = new Date(date + 'T12:00:00Z');
  return `${DIAS[d.getUTCDay()]} ${d.getUTCDate()} ${MESES[d.getUTCMonth()]}`;
}
const ESTADO: Record<string, string> = {
  scheduled: 'pendiente de confirmar → responde /confirm',
  confirmed: 'confirmada',
  filled: 'asignada desde lista de espera → responde /confirm',
};

const telegram: Provider = {
  id: 'telegram',
  label: 'Telegram bot',
  fixedTemplate: false,
  linkedContacts: true,
  maxContacts: null,
  telecom: 'other',
  credentials(data) {
    const token = field(data.token, 'Bot token', 100);
    if (!/^\d{6,12}:[A-Za-z0-9_-]{30,}$/.test(token))
      throw Error(
        'Paste the bot token BotFather gave you, in the form 123456:ABC-DEF…',
      );
    return { token };
  },
  async verify(c) {
    const me = await bot(c, 'getMe');
    return me.result?.username ? '@' + me.result.username : 'Telegram bot';
  },
  address(value) {
    const v = String(value ?? '').trim();
    if (!/^-?\d{1,20}$/.test(v))
      throw Error(
        'A Telegram chat id is numeric. Link the contact from the bot instead of typing it.',
      );
    return v;
  },
  reminder(slot, reason) {
    return [
      reason === 'standby'
        ? `A slot has opened up and has been assigned to you, ${slot.name}.`
        : `Appointment reminder for ${slot.name}`,
      '',
      `${slot.date} at ${slot.time}`,
      `${slot.service} with ${slot.clinician}`,
      slot.location,
      '',
      'Reply /confirm to confirm, or /reschedule día/mes to move to another day.',
      'This is a demonstration with fictional patient data.',
    ].join('\n');
  },
  // In Spanish: the patient typed a Spanish command and reads Spanish. Dates
  // are spelled by hand rather than through Intl so the text does not depend
  // on which locales the runtime ships.
  inquiry(cards) {
    const out: string[] = [];
    for (const card of cards) {
      if (out.length) out.push('');
      out.push(`Hola ${card.name}.`);
      if (card.appointments.length) {
        out.push('Tus próximas horas:');
        for (const a of card.appointments)
          out.push(
            `• ${diaLabel(a.date)}, ${a.time} — ${a.service}`,
            `  ${a.clinician} · ${a.location} · ${ESTADO[a.status] ?? a.status}`,
          );
      } else out.push('No tienes horas agendadas.');
      if (card.standby.length)
        out.push(
          'Lista de espera: ' +
            card.standby
              .map(
                (s) =>
                  `${s.service} (${s.date ? diaLabel(s.date) : 'cualquier día'})`,
              )
              .join('; '),
        );
    }
    if (!cards.length) out.push('No encontramos un registro para este chat.');
    out.push('', 'Esta es una demostración con datos ficticios.');
    return out.join('\n');
  },
  acknowledge(outcome, slots) {
    const when = (s: Slot) =>
      `${diaLabel(s.date)} a las ${s.time} (${s.service})`;
    if (outcome === 'confirmed' && slots[0])
      return `Confirmado. Te esperamos el ${when(slots[0])}.`;
    if (outcome === 'already' && slots.length === 1)
      return `Tu hora ya está confirmada: ${when(slots[0])}. No hace falta volver a confirmar.`;
    if (outcome === 'already')
      return [
        'Tus horas ya están confirmadas:',
        ...slots.map((s) => `• ${when(s)}`),
        'No hace falta volver a confirmar.',
      ].join('\n');
    if (outcome === 'ambiguous')
      return 'Tienes más de una hora pendiente de confirmar. El centro la confirmará contigo.';
    return 'No tienes una hora pendiente de confirmar. Escribe /cita para ver tus horas.';
  },
  rescheduleAck(outcome, { released, moved, day }) {
    const when = (s: Slot) => `${diaLabel(s.date)} a las ${s.time}`;
    const target = day ? diaLabel(day) : 'ese día';
    switch (outcome) {
      case 'ask':
        return '¿Para qué día quieres cambiar tu hora? Responde con la fecha en formato día/mes.';
      case 'bad-day':
        return 'No entendí la fecha. Escribe la fecha en formato día/mes.';
      case 'need-day':
        return 'Necesitamos un día concreto. Escribe la fecha en formato día/mes.';
      case 'closed':
        return `El centro no atiende el ${target}. Escribe otro día en formato día/mes.`;
      case 'moved':
        return `Listo. Te cambiamos al ${when(moved!)} (${moved!.service}, ${moved!.clinician}, ${moved!.location}). Responde /confirm para confirmar esta nueva hora.`;
      case 'done':
        return `El ${target} ya está lleno. Liberamos tu hora del ${when(released!)} y quedas en lista de espera para ${released!.service} ese día. El centro te avisará cuando haya un cupo.`;
      case 'already-queued':
        return `El ${target} ya está lleno. Liberamos tu hora del ${when(released!)}. Ya estabas en lista de espera para ${released!.service} ese día; el centro te avisará cuando haya un cupo.`;
      case 'ambiguous':
        return 'Tienes más de una hora agendada. El centro te contactará para reagendar.';
      default:
        return 'No tienes una hora que reagendar. Escribe /cita para ver tus horas.';
    }
  },
  async send(c, address, body) {
    const m = await bot(c, 'sendMessage', { chat_id: address, text: body });
    return {
      sid: `${address}:${m.result?.message_id}`,
      // Telegram accepts or rejects synchronously; there is nothing to poll.
      status: 'delivered',
      body,
    };
  },
  async inbound(c, cursor, since) {
    // Telegram timestamps have second granularity, so compare at that
    // granularity: a reply in the same second as connecting is not "before" it.
    const floor = Math.floor(since / 1000) * 1000;
    const params = new URLSearchParams({
      timeout: '0',
      allowed_updates: '["message"]',
    });
    if (cursor) params.set('offset', cursor);
    const data = await bot(c, 'getUpdates?' + params);
    const messages: Inbound[] = [];
    let next = cursor;
    for (const u of data.result ?? []) {
      next = String(Number(u.update_id) + 1);
      const m = u.message;
      if (!m?.chat?.id || typeof m.date !== 'number') continue;
      const text = String(m.text ?? '').slice(0, 1600);
      const at = m.date * 1000;
      if (at < floor) continue;
      // In a group Telegram addresses the command to the bot, so the same
      // code arrives as "/start@botname CODE". Accept both spellings.
      const start = text.match(/^\/start(?:@\w+)?\s+([A-Z0-9]{6,12})$/i);
      messages.push({
        sid: `${m.chat.id}:${m.message_id}`,
        address: String(m.chat.id),
        body: text,
        at,
        // "/cita" — or "/cita@botname" as Telegram spells it in a group.
        ...(/^\/cita(?:@\w+)?\s*$/i.test(text) ? { inquiry: true } : {}),
        ...(isConfirmCommand(text) ? { confirm: true } : {}),
        ...(() => {
          const r = parseRescheduleCommand(text);
          return r ? { reschedule: r } : {};
        })(),
        ...(start
          ? {
              linkCode: start[1].toUpperCase(),
              linkName:
                [m.chat.first_name, m.chat.last_name]
                  .filter(Boolean)
                  .join(' ') ||
                m.chat.title ||
                m.chat.username ||
                'Telegram contact',
            }
          : {}),
      });
    }
    return { messages, cursor: next };
  },
};

function bot(c: Credentials, method: string, body?: any) {
  return json(
    `https://api.telegram.org/bot${c.token}/${method}`,
    body
      ? {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(body),
        }
      : { method: 'GET' },
    (data, status) =>
      `Telegram rejected the request (${data?.description ?? 'status ' + status}). Check the bot token, and that the contact has started a chat with the bot.`,
  );
}

export const providers: Record<string, Provider> = { twilio, telegram };

export function provider(id: unknown): Provider {
  const p = providers[String(id ?? 'twilio')];
  if (!p) throw Error('Choose a supported messaging provider.');
  return p;
}
