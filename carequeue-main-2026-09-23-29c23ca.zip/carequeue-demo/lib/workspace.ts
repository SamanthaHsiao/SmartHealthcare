import { env } from 'cloudflare:workers';
import { getChatGPTUser } from '@/app/chatgpt-auth';
import { fhirStore } from './fhir/store';

// What every backend module needs about the workspace it is running in: the
// authenticated owner, the database, the encrypted provider connection and
// the registered recipients. Nothing clinical lives here — those are FHIR
// resources in the store — only the plumbing that scopes and reaches them.

const e = env as unknown as { DB: D1Database; CREDENTIAL_KEY?: string };
export const db = () => e.DB;
export const secureStorage = () => !!e.CREDENTIAL_KEY;
export const now = () => Date.now();
// A short, upper-case token for codes staff read out or type: record
// numbers, booking codes, link codes.
export const id = () =>
  crypto.randomUUID().replaceAll('-', '').slice(0, 8).toUpperCase();
export const q = (sql: string, ...args: unknown[]) =>
  db()
    .prepare(sql)
    .bind(...args);
export const one = async (sql: string, ...args: unknown[]): Promise<any> =>
  q(sql, ...args).first();
export const all = async (sql: string, ...args: unknown[]): Promise<any[]> =>
  (await q(sql, ...args).all()).results;
export const store = () => fhirStore(db());

export async function owner() {
  const u = await getChatGPTUser();
  if (!u) throw Error('Sign in to manage this private workspace.');
  return u.userId;
}

async function key() {
  if (!e.CREDENTIAL_KEY)
    throw Error('Secure connection storage is not configured.');
  return crypto.subtle.importKey(
    'raw',
    Uint8Array.from(atob(e.CREDENTIAL_KEY), (c) => c.charCodeAt(0)),
    { name: 'AES-GCM' },
    false,
    ['encrypt', 'decrypt'],
  );
}
export async function seal(o: string, data: any) {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const bytes = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv, additionalData: new TextEncoder().encode(o) },
    await key(),
    new TextEncoder().encode(JSON.stringify(data)),
  );
  return btoa(String.fromCharCode(...iv, ...new Uint8Array(bytes)));
}
// The workspace's provider connection with its credentials decrypted. Only
// the server ever sees the result; `state()` sends the browser a projection.
export async function connection(o: string) {
  const c = await one('SELECT * FROM connections WHERE owner=?', o);
  if (!c) throw Error('Connect a messaging provider first.');
  const b = Uint8Array.from(atob(c.secret), (v) => v.charCodeAt(0));
  const raw = await crypto.subtle.decrypt(
    {
      name: 'AES-GCM',
      iv: b.slice(0, 12),
      additionalData: new TextEncoder().encode(o),
    },
    await key(),
    b.slice(12),
  );
  return { ...c, ...JSON.parse(new TextDecoder().decode(raw)) };
}
// A registered, consented recipient address, or an error that says what to
// do about it. Registration is the device owner's consent to test messages;
// it lives in the `contacts` table because it is about the messaging
// pipeline — which chats the bot may write to — not about a patient.
export async function testContact(o: string, phone: string) {
  const c = await one(
    'SELECT * FROM contacts WHERE owner=? AND phone=? AND consent=1',
    o,
    phone,
  );
  if (!c)
    throw Error(
      'Register this recipient and its consent in messaging setup first.',
    );
  return c;
}
export async function registered(o: string, phone: string) {
  return !!(await one(
    'SELECT id FROM contacts WHERE owner=? AND phone=? AND consent=1',
    o,
    phone,
  ));
}
