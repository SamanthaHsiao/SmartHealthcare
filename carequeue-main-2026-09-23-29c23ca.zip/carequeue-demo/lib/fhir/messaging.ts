import type * as R4 from 'fhir/r4';
import { parseRequestedDay } from '../rules';
import { isClinicDay } from '../timetable';
import {
  provider,
  type Card,
  type Provider,
  type RescheduleOutcome,
  type Slot as SlotCard,
} from '../providers';
import {
  connection,
  db,
  id,
  now,
  one,
  q,
  registered,
  store,
  testContact,
} from '../workspace';
import { Conflict } from './store';
import { reference } from './resources';
import {
  appointmentState,
  bookingCode,
  buildInbound,
  buildOutbound,
  deliveryStatus,
  isWaiting,
  messageBody,
  messageKey,
  patientAddress,
  patientName,
  patientRefOf,
  practitionerName,
  providerSid,
  requestedDay,
  serviceOfAppointment,
  withDelivery,
  type MessageCategory,
} from './build';
import { wallTime } from './time';
import { confirmAppointment, rebook, releaseToStandby } from './scheduling';

// Messages as Communication resources, and everything that reads or writes
// them: sending a reminder or a notification, pulling replies from the
// provider, and the three commands a patient may send. The provider layer
// (lib/providers.ts) still speaks to the vendor and composes the words;
// this module decides what is sent, to whom, under which key, and what a
// reply does.

// ---------------------------------------------------------------- cards

// A live appointment in the plain shape the provider templates take,
// names resolved. `status` uses the words the templates know.
export async function cardOf(
  o: string,
  a: R4.Appointment,
  patient?: R4.Patient | null,
): Promise<SlotCard & { status: string }> {
  const s = store();
  const pt =
    patient ??
    ((await s.resolve(o, patientRefOf(a) ?? undefined)) as R4.Patient | null);
  const who = (type: string) =>
    a.participant.find((p) => p.actor?.reference?.startsWith(type + '/'))?.actor
      ?.reference;
  const practitioner = (await s.resolve(
    o,
    who('Practitioner'),
  )) as R4.Practitioner | null;
  const location = (await s.resolve(o, who('Location'))) as R4.Location | null;
  const when = a.start ? wallTime(a.start) : { date: '', time: '' };
  return {
    name: pt ? patientName(pt) : '',
    date: when.date,
    time: when.time,
    clinician: practitioner ? practitionerName(practitioner) : '',
    service: serviceOfAppointment(a),
    location: location?.name ?? '',
    status: appointmentState(a),
  };
}

// The patients reached at one address — a shared device carries several.
async function patientsAt(o: string, address: string) {
  const list = await store().search(o, 'Patient', { telecom: address });
  list.sort((a, b) => patientName(a).localeCompare(patientName(b)));
  return list;
}

// Live appointments of the patients at one address, in slot order.
async function liveAt(
  o: string,
  address: string,
  statuses: ('pending' | 'booked')[],
) {
  const s = store();
  const out: { appointment: R4.Appointment; patient: R4.Patient }[] = [];
  for (const patient of await patientsAt(o, address))
    for (const appointment of await s.search(o, 'Appointment', {
      patient: reference('Patient', patient.id!),
      status: statuses,
    }))
      out.push({ appointment, patient });
  out.sort((x, y) =>
    (x.appointment.start ?? '').localeCompare(y.appointment.start ?? ''),
  );
  return out;
}

// ---------------------------------------------------------------- sending

// The reminders sent for an appointment under its current code — the first
// one and any follow-ups — that did not fail outright.
export async function remindersFor(o: string, a: R4.Appointment) {
  const base = 'reminder:' + a.id + ':' + bookingCode(a);
  return (
    await store().search(o, 'Communication', {
      about: reference('Appointment', a.id!),
      category: 'reminder',
    })
  ).filter((c) => {
    const key = messageKey(c);
    return (
      (key === base || key?.startsWith(base + ':')) &&
      deliveryStatus(c) !== 'failed'
    );
  });
}

// When the first reminder under the appointment's current code went out,
// or null if it did not (failed, unknown, never sent). Compared at second
// granularity by callers: some providers timestamp replies to the second.
export async function reminderSentAt(o: string, a: R4.Appointment) {
  const base = 'reminder:' + a.id + ':' + bookingCode(a);
  const sent = (await remindersFor(o, a)).filter(
    (c) =>
      providerSid(c) && !['undelivered', 'unknown'].includes(deliveryStatus(c)),
  );
  if (!sent.length) return null;
  const first = sent.find((c) => messageKey(c) === base) ?? sent[0];
  return Date.parse(first.sent!);
}
export const floorSecond = (ms: number) => Math.floor(ms / 1000) * 1000;

type SendOptions = {
  categories: MessageCategory[];
  about?: string | null;
  recipient?: string | null;
  inResponseTo?: string | null;
};

// Send one message under one key. A second call with the same key finds
// the first message and sends nothing — unless that attempt failed for
// certain, in which case it is claimed and retried. What the vendor said
// is written back onto the same resource.
export async function send(
  o: string,
  c: any,
  address: string,
  body: string,
  key: string,
  options: SendOptions,
) {
  const s = store();
  const p = provider(c.provider);
  await testContact(o, address);
  const draft = buildOutbound({
    key,
    address: { value: address, system: p.telecom },
    body,
    categories: options.categories,
    sent: now(),
    about: options.about,
    recipient: options.recipient,
    inResponseTo: options.inResponseTo,
  });
  const first = await s.createIfAbsent(o, draft);
  let current = first.resource;
  if (!first.created) {
    if (deliveryStatus(current) !== 'failed') return current;
    try {
      current = await s.update(
        o,
        withDelivery({ ...current, sent: draft.sent }, { delivery: 'sending' }),
      );
    } catch (err) {
      if (err instanceof Conflict)
        throw Error('This message is already processing.');
      throw err;
    }
  }
  try {
    const m = await p.send(c, address, body);
    return await s.update(
      o,
      withDelivery(current, { delivery: m.status, sid: m.sid, body: m.body }),
    );
  } catch (err: any) {
    const definitive = !!err?.definitive;
    await s
      .update(
        o,
        withDelivery(current, {
          delivery: definitive ? 'failed' : 'unknown',
          error: definitive
            ? err.message
            : 'Sending outcome is unknown. Check the provider logs before trying again.',
        }),
      )
      .catch(() => {
        /* The message row keeps its last state; the throw below says so. */
      });
    throw Error(
      definitive
        ? err.message
        : 'Connection interrupted. Delivery is unknown. Check the provider logs before retrying.',
    );
  }
}

// A reminder for a live appointment, or a deliberate follow-up to a patient
// who has not replied. One reminder per booking code: the second press is
// refused, the follow-up is a separately numbered send.
export async function remind(o: string, data: any) {
  const s = store();
  const a = await s.read(o, 'Appointment', String(data.id ?? ''));
  if (!a || !['pending', 'booked'].includes(a.status))
    throw Error('This appointment is not available for a reminder.');
  const patient = (await s.resolve(
    o,
    patientRefOf(a) ?? undefined,
  )) as R4.Patient | null;
  if (!patient || !patientAddress(patient))
    throw Error('This appointment is not available for a reminder.');
  const c = await connection(o);
  const p = provider(c.provider);
  // Only a fixed-template provider makes staff acknowledge the sample date.
  // A provider that sends free text carries the real appointment details.
  if (p.fixedTemplate && data.fixedTemplateAccepted !== true)
    throw Error(
      'Acknowledge that the template uses a fixed sample date, not this appointment date.',
    );
  const base = 'reminder:' + a.id + ':' + bookingCode(a);
  const prior = await remindersFor(o, a);
  if (prior.length && data.again !== true)
    throw Error(
      'A reminder for this slot has already been sent. Use "Send again" to follow up.',
    );
  await send(
    o,
    c,
    patientAddress(patient)!,
    p.reminder(await cardOf(o, a, patient)),
    prior.length ? `${base}:${prior.length + 1}` : base,
    {
      categories: ['reminder'],
      about: reference('Appointment', a.id!),
      recipient: reference('Patient', patient.id!),
    },
  );
  return {
    followUp: prior.length > 0,
    fixedTemplate: p.fixedTemplate,
  };
}

// Tell a standby patient about the slot they were just assigned, on a
// provider that can say so. Under the appointment's reminder key, so the
// notification is the reminder for this code.
export async function notifyAssignment(
  o: string,
  a: R4.Appointment,
  patient: R4.Patient,
) {
  const active = await one('SELECT provider FROM connections WHERE owner=?', o);
  const p = active ? provider(active.provider) : null;
  if (!p || p.fixedTemplate) return { sent: false as const };
  try {
    await send(
      o,
      await connection(o),
      patientAddress(patient)!,
      p.reminder(await cardOf(o, a, patient), 'standby'),
      'reminder:' + a.id + ':' + bookingCode(a),
      {
        categories: ['reminder', 'standby'],
        about: reference('Appointment', a.id!),
        recipient: reference('Patient', patient.id!),
      },
    );
    return { sent: true as const };
  } catch (err: any) {
    return { sent: false as const, error: String(err?.message ?? err) };
  }
}

// Staff record a confirmation from a reply they reviewed: the reminder
// under the current code went out, and a C or /confirm arrived from the
// patient's address after it.
export async function recordConfirmation(o: string, data: any) {
  const s = store();
  const a = await s.read(o, 'Appointment', String(data.id ?? ''));
  if (!a || a.status !== 'pending')
    throw Error('Select an appointment that is awaiting confirmation.');
  const patient = (await s.resolve(
    o,
    patientRefOf(a) ?? undefined,
  )) as R4.Patient | null;
  const address = patient && patientAddress(patient);
  const sentAt = await reminderSentAt(o, a);
  const replied =
    address &&
    sentAt !== null &&
    (
      await store().search(o, 'Communication', { address, category: 'inbound' })
    ).some(
      (m) =>
        /^(C|\/CONFIRM(@\w+)?)$/i.test(messageBody(m).trim()) &&
        Date.parse(m.received!) >= floorSecond(sentAt),
    );
  if (!replied)
    throw Error(
      'Sync a /confirm or C reply received after this appointment reminder was sent, then review it.',
    );
  await confirmAppointment(o, a, 'Recorded by staff from the patient’s reply');
}

// ---------------------------------------------------------------- replies

async function overContactLimit(o: string, p: Provider, address: string) {
  if (p.maxContacts === null) return false;
  if (
    await one('SELECT id FROM contacts WHERE owner=? AND phone=?', o, address)
  )
    return false;
  const count = await one('SELECT COUNT(*) n FROM contacts WHERE owner=?', o);
  return count.n >= p.maxContacts;
}

async function applyReply(o: string, m: any, c: any, p: Provider) {
  if (!m.sid || !Number.isFinite(m.at)) return;
  // A "/start <code>" message binds a pending link to the chat it came from.
  // This is the only way a linked provider gains a contact, and it requires
  // staff to have generated the code first.
  if (
    m.linkCode &&
    c.linkCode &&
    m.linkCode === c.linkCode &&
    // Leave the code pending rather than consuming it, so staff can see the
    // link did not take and free a slot first.
    !(await overContactLimit(o, p, m.address))
  ) {
    await db().batch([
      q(
        'INSERT INTO contacts(id,owner,name,phone,consent) VALUES(?,?,?,?,1) ON CONFLICT(owner,phone) DO UPDATE SET name=excluded.name,consent=1',
        id(),
        o,
        c.linkName || m.linkName || 'Telegram contact',
        m.address,
      ),
      q('UPDATE connections SET linkCode=NULL,linkName=NULL WHERE owner=?', o),
    ]);
    c.linkCode = null;
  }
  if (!(await registered(o, m.address))) return;
  await q(
    'UPDATE contacts SET lastInbound=MAX(lastInbound,?) WHERE owner=? AND phone=?',
    m.at,
    o,
    m.address,
  ).run();
  const { created, resource } = await store().createIfAbsent(
    o,
    buildInbound({
      sid: m.sid,
      address: { value: m.address, system: p.telecom },
      body: m.body,
      received: m.at,
    }),
  );
  // Replies are recorded for staff review. Three commands are acted on,
  // each once per inbound message — a re-fetch of the same update finds the
  // message already recorded and does nothing.
  if (!created) return;
  const inbound = reference('Communication', resource.id!);
  if (m.inquiry && p.inquiry) await answerInquiry(o, c, p, m, inbound);
  if (m.confirm) await autoConfirm(o, c, p, m, inbound);
  if (m.reschedule)
    await startReschedule(o, c, p, m, inbound, m.reschedule.arg);
  else if (!m.inquiry && !m.confirm)
    await continueReschedule(o, c, p, m, inbound);
}

async function reply(
  o: string,
  c: any,
  m: any,
  body: string,
  key: string,
  categories: MessageCategory[],
  inResponseTo: string,
  about?: string | null,
  recipient?: string | null,
) {
  try {
    await send(o, c, m.address, body, key, {
      categories,
      inResponseTo,
      about,
      recipient,
    });
  } catch {
    /* Recorded as failed on the message; sync carries on. */
  }
}

// "/cita": a read-only summary of what every patient at this address has.
async function answerInquiry(
  o: string,
  c: any,
  p: Provider,
  m: any,
  inbound: string,
) {
  const s = store();
  const cards: Card[] = [];
  for (const patient of await patientsAt(o, m.address)) {
    const appointments: Card['appointments'] = [];
    for (const a of await s.search(o, 'Appointment', {
      patient: reference('Patient', patient.id!),
      status: ['pending', 'booked'],
    }))
      appointments.push(await cardOf(o, a, patient));
    appointments.sort((x, y) =>
      (x.date + x.time).localeCompare(y.date + y.time),
    );
    const standby = (
      await s.search(o, 'Appointment', {
        patient: reference('Patient', patient.id!),
        status: 'waitlist',
      })
    )
      .filter(isWaiting)
      .map((a) => ({ service: serviceOfAppointment(a), date: requestedDay(a) }))
      .sort((x, y) => (x.date ?? '9').localeCompare(y.date ?? '9'));
    cards.push({ name: patientName(patient), appointments, standby });
  }
  await reply(
    o,
    c,
    m,
    p.inquiry!(cards),
    'inquiry:' + m.sid,
    ['inquiry'],
    inbound,
  );
}

// "/confirm": acted on only when it cannot be misread — exactly one
// appointment at this address is awaiting confirmation and had its reminder
// sent before the reply. Anything else is left for staff, and the patient
// is told what happened.
async function autoConfirm(
  o: string,
  c: any,
  p: Provider,
  m: any,
  inbound: string,
) {
  const eligible: { appointment: R4.Appointment; patient: R4.Patient }[] = [];
  for (const x of await liveAt(o, m.address, ['pending'])) {
    const sentAt = await reminderSentAt(o, x.appointment);
    if (sentAt !== null && floorSecond(sentAt) <= m.at) eligible.push(x);
  }
  let outcome: 'confirmed' | 'already' | 'nothing' | 'ambiguous' = 'nothing';
  const slots: SlotCard[] = [];
  let about: string | null = null;
  if (eligible.length === 1) {
    const { appointment, patient } = eligible[0];
    try {
      await confirmAppointment(
        o,
        appointment,
        'Confirmed by the patient with /confirm',
      );
      outcome = 'confirmed';
      slots.push(await cardOf(o, appointment, patient));
      about = reference('Appointment', appointment.id!);
    } catch {
      /* Changed underneath us; answer as "nothing pending". */
    }
  } else if (eligible.length > 1) outcome = 'ambiguous';
  else {
    // Nothing waiting. If that is because it is already confirmed, say so —
    // "nothing to confirm" reads as "you have no appointment" to a patient
    // who just confirmed one.
    for (const x of await liveAt(o, m.address, ['booked']))
      slots.push(await cardOf(o, x.appointment, x.patient));
    if (slots.length) outcome = 'already';
  }
  if (!p.acknowledge) return;
  await reply(
    o,
    c,
    m,
    p.acknowledge(outcome, slots),
    'ack:' + m.sid,
    ['acknowledgement'],
    inbound,
    about,
  );
}

// "/reschedule [day]": the one inbound message that changes a booking, by
// explicit decision. The patient names a clinic day; if that day still has
// a free start on their clinician's timetable they are moved into the
// earliest one and asked to confirm it, and if it is full their slot is
// released and they join that day's standby list. Nothing happens until a
// specific day is in hand — "any day" is not one — and without a day the
// question is asked and remembered for thirty minutes; the next plain
// message from the chat that reads as a day completes it.
const PENDING_MS = 30 * 60 * 1000;
async function pendingFor(o: string, address: string) {
  const row = await one(
    'SELECT pending FROM contacts WHERE owner=? AND phone=?',
    o,
    address,
  );
  if (!row?.pending) return null;
  try {
    const p = JSON.parse(row.pending);
    return p.until > now() ? p : null;
  } catch {
    return null;
  }
}
async function setPending(o: string, address: string, value: any) {
  await q(
    'UPDATE contacts SET pending=? WHERE owner=? AND phone=?',
    value ? JSON.stringify(value) : null,
    o,
    address,
  ).run();
}
type RescheduleContext = {
  released: SlotCard | null;
  moved?: SlotCard | null;
  day: string | null;
};
const noDay: RescheduleContext = { released: null, day: null };
async function replyReschedule(
  o: string,
  c: any,
  p: Provider,
  m: any,
  inbound: string,
  outcome: RescheduleOutcome,
  ctx: RescheduleContext,
  about?: string | null,
) {
  if (!p.rescheduleAck) return;
  await reply(
    o,
    c,
    m,
    p.rescheduleAck(outcome, ctx),
    'resched:' + m.sid,
    ['reschedule'],
    inbound,
    about,
  );
}
// The day the patient wrote, if the centre can use it. Otherwise the
// patient is told why — unreadable, "any day", or a day the centre is
// closed — the question stays open, and null is returned.
async function usableDay(
  o: string,
  c: any,
  p: Provider,
  m: any,
  inbound: string,
  text: string,
  remember: () => Promise<void>,
) {
  const day = parseRequestedDay(text);
  const outcome: RescheduleOutcome | null = !day
    ? 'bad-day'
    : 'any' in day
      ? 'need-day'
      : !isClinicDay(day.date)
        ? 'closed'
        : null;
  if (!outcome) return (day as { date: string }).date;
  await remember();
  await replyReschedule(o, c, p, m, inbound, outcome, {
    ...noDay,
    day: day && 'date' in day ? day.date : null,
  });
  return null;
}
async function startReschedule(
  o: string,
  c: any,
  p: Provider,
  m: any,
  inbound: string,
  arg: string | null,
) {
  const live = await liveAt(o, m.address, ['pending', 'booked']);
  if (live.length !== 1) {
    await setPending(o, m.address, null);
    return replyReschedule(
      o,
      c,
      p,
      m,
      inbound,
      live.length ? 'ambiguous' : 'nothing',
      noDay,
    );
  }
  const { appointment, patient } = live[0];
  const remember = () =>
    setPending(o, m.address, {
      intent: 'reschedule',
      appointment: appointment.id,
      code: bookingCode(appointment),
      until: now() + PENDING_MS,
    });
  if (!arg) {
    await remember();
    return replyReschedule(o, c, p, m, inbound, 'ask', noDay);
  }
  const day = await usableDay(o, c, p, m, inbound, arg, remember);
  if (day)
    await finishReschedule(o, c, p, m, inbound, appointment, patient, day);
}
async function continueReschedule(
  o: string,
  c: any,
  p: Provider,
  m: any,
  inbound: string,
) {
  const pending = await pendingFor(o, m.address);
  if (!pending || pending.intent !== 'reschedule') return;
  const s = store();
  const a = await s.read(o, 'Appointment', String(pending.appointment));
  const patient =
    a &&
    ((await s.resolve(o, patientRefOf(a) ?? undefined)) as R4.Patient | null);
  if (
    !a ||
    !patient ||
    !['pending', 'booked'].includes(a.status) ||
    bookingCode(a) !== pending.code
  ) {
    // The slot changed hands or was edited since the question was asked.
    await setPending(o, m.address, null);
    return replyReschedule(o, c, p, m, inbound, 'nothing', noDay);
  }
  // The question is already remembered; an unusable answer keeps it open.
  const day = await usableDay(o, c, p, m, inbound, m.body, async () => {});
  if (day) await finishReschedule(o, c, p, m, inbound, a, patient, day);
}
async function finishReschedule(
  o: string,
  c: any,
  p: Provider,
  m: any,
  inbound: string,
  a: R4.Appointment,
  patient: R4.Patient,
  day: string,
) {
  const card = await cardOf(o, a, patient);
  const about = reference('Appointment', a.id!);
  let outcome: RescheduleOutcome;
  let moved: R4.Appointment | null = null;
  try {
    const result = await rebook(o, a, day);
    if (result) {
      moved = result.appointment;
      outcome = 'moved';
    } else {
      const { duplicate } = await releaseToStandby(o, a, day);
      outcome = duplicate ? 'already-queued' : 'done';
    }
  } catch {
    // Changed underneath us: nothing was moved or released.
    await setPending(o, m.address, null);
    return replyReschedule(o, c, p, m, inbound, 'nothing', noDay);
  }
  await setPending(o, m.address, null);
  if (moved) {
    // The answer names the new time and asks for /confirm, so it is the
    // reminder for the new booking code: a /confirm can answer it.
    if (!p.rescheduleAck) return;
    await reply(
      o,
      c,
      m,
      p.rescheduleAck('moved', {
        released: card,
        moved: await cardOf(o, moved, patient),
        day,
      }),
      'reminder:' + a.id + ':' + bookingCode(moved),
      ['reminder', 'reschedule'],
      inbound,
      about,
      reference('Patient', patient.id!),
    );
    return;
  }
  await replyReschedule(
    o,
    c,
    p,
    m,
    inbound,
    outcome,
    { released: card, day },
    about,
  );
}

// ---------------------------------------------------------------- sync

// Pull replies and delivery reports from the provider. Runs while the
// dashboard is open, under a lease so two tabs do not both apply the same
// batch.
export async function sync(o: string) {
  const c = await connection(o);
  const p = provider(c.provider);
  const lock = await q(
    'UPDATE connections SET syncLock=? WHERE owner=? AND syncLock<?',
    now() + 60000,
    o,
    now(),
  ).run();
  if (!lock.meta.changes) return { message: 'Reply sync already running.' };
  try {
    const { messages, cursor } = await p.inbound(
      c,
      c.cursor,
      c.since,
      c.synced,
    );
    messages.sort((a, b) => a.at - b.at);
    for (const m of messages) await applyReply(o, m, c, p);
    if (p.status) {
      // Outbound messages the vendor may still report on: sent but not yet
      // read, most recent first.
      const s = store();
      const pending = (
        await s.search(o, 'Communication', {
          status: ['in-progress', 'completed'],
        })
      )
        .filter(
          (x) =>
            x.sent &&
            providerSid(x) &&
            !['read', 'failed', 'undelivered', 'received'].includes(
              deliveryStatus(x),
            ),
        )
        .sort((x, y) => Date.parse(y.sent!) - Date.parse(x.sent!))
        .slice(0, 20);
      for (const msg of pending) {
        try {
          const r = await p.status(c, providerSid(msg)!);
          await s.update(
            o,
            withDelivery(msg, { delivery: r.status, error: r.error }),
          );
        } catch {
          /* Preserve last known delivery state. */
        }
      }
    }
    await q(
      'UPDATE connections SET synced=?,cursor=? WHERE owner=?',
      now(),
      cursor,
      o,
    ).run();
    return { message: 'Replies synchronized.' };
  } finally {
    await q('UPDATE connections SET syncLock=0 WHERE owner=?', o).run();
  }
}

// The hundred most recent messages, newest first, for the dashboard —
// ordered and cut in the database by when they went out or came in.
export async function recentMessages(o: string) {
  return store().search(
    o,
    'Communication',
    {},
    { sort: { param: ['sent', 'received'], descending: true }, limit: 100 },
  );
}
