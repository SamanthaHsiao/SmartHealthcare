import type * as R4 from 'fhir/r4';
import {
  appointmentState,
  assignedAt,
  bookingCode,
  deliveryStatus,
  messageAddress,
  messageAt,
  messageBody,
  messageDirection,
  messageKey,
  patientAddress,
  patientName,
  patientNotes,
  patientRecord,
  practitionerName,
  requestedDay,
  serviceOfAppointment,
  slotRefOf,
} from './build';
import { wallTime } from './time';
import { gridTimes } from '../timetable';

// What the interface reads. The workspace endpoint returns FHIR resources
// grouped by type; the tables and panels want rows — a booking with its
// patient's name, the clinician's name and a clinic-time date, a standby
// entry with the day it waits for. This module derives those rows from the
// resources, in the browser, keeping each row's id equal to its resource's
// id so every action still names a resource. No database, no network: pure
// functions over the bundle.

export type Bundle = {
  Patient: R4.Patient[];
  Consent: R4.Consent[];
  Practitioner: R4.Practitioner[];
  Location: R4.Location[];
  HealthcareService: R4.HealthcareService[];
  Schedule: R4.Schedule[];
  Slot: R4.Slot[];
  Appointment: R4.Appointment[];
  AppointmentResponse: R4.AppointmentResponse[];
  Communication: R4.Communication[];
  contacts: { id: string; name: string; phone: string; lastInbound: number }[];
  connection: {
    provider: string;
    sender: string;
    synced: number;
    linkCode: string | null;
  } | null;
  providers: {
    id: string;
    label: string;
    fixedTemplate: boolean;
    linkedContacts: boolean;
  }[];
  secureStorage: boolean;
};

export const emptyBundle: Bundle = {
  Patient: [],
  Consent: [],
  Practitioner: [],
  Location: [],
  HealthcareService: [],
  Schedule: [],
  Slot: [],
  Appointment: [],
  AppointmentResponse: [],
  Communication: [],
  contacts: [],
  connection: null,
  providers: [],
  secureStorage: false,
};

export type PatientRow = {
  id: string;
  record: string;
  name: string;
  phone: string;
  notes: string | null;
  consent: string | null;
};

// A booking, or an open slot. `kind` says which resource the id names.
export type AppointmentRow = {
  id: string;
  kind: 'appointment' | 'slot';
  patient: string | null;
  name: string | null;
  record: string | null;
  phone: string | null;
  date: string;
  time: string;
  clinician: string;
  service: string;
  location: string;
  status: string;
  code: string | null;
  responses: number;
};

export type StandbyRow = {
  id: string;
  patient: string;
  name: string;
  record: string;
  phone: string;
  service: string;
  date: string | null;
  status: 'waiting' | 'released' | 'booked';
  created: number;
  // For a booked entry: the appointment it became — the same id.
  booking: string | null;
};

export type MessageRow = {
  id: string;
  key: string | null;
  phone: string;
  body: string;
  direction: 'inbound' | 'outbound';
  status: string;
  error: string | null;
  created: number;
  about: string | null;
};

export type Workspace = {
  patients: PatientRow[];
  appointments: AppointmentRow[];
  standby: StandbyRow[];
  messages: MessageRow[];
};

export function project(b: Bundle): Workspace {
  const patients = new Map(b.Patient.map((p) => [p.id!, p]));
  const practitioners = new Map(
    b.Practitioner.map((p) => [`Practitioner/${p.id}`, practitionerName(p)]),
  );
  const locations = new Map(
    b.Location.map((l) => [`Location/${l.id}`, l.name ?? '']),
  );
  const schedules = new Map(b.Schedule.map((s) => [`Schedule/${s.id}`, s]));
  const consents = new Map<string, string>();
  for (const c of b.Consent)
    if (c.status === 'active' && c.patient?.reference)
      consents.set(c.patient.reference, c.dateTime ?? '');
  const responses = new Map<string, number>();
  for (const r of b.AppointmentResponse)
    responses.set(
      r.appointment.reference ?? '',
      (responses.get(r.appointment.reference ?? '') ?? 0) + 1,
    );
  const busy = new Set(
    b.Appointment.filter((a) => ['pending', 'booked'].includes(a.status)).map(
      slotRefOf,
    ),
  );

  const who = (a: R4.Appointment, type: string) =>
    a.participant.find((p) => p.actor?.reference?.startsWith(type + '/'))?.actor
      ?.reference ?? '';
  const patientOf = (a: R4.Appointment) =>
    patients.get(who(a, 'Patient').slice('Patient/'.length)) ?? null;
  const namesOf = (a: R4.Appointment) => ({
    clinician: practitioners.get(who(a, 'Practitioner')) ?? '',
    location: locations.get(who(a, 'Location')) ?? '',
  });
  const slotNames = (s: R4.Slot) => {
    const schedule = schedules.get(s.schedule.reference ?? '');
    const refs = schedule?.actor.map((x) => x.reference ?? '') ?? [];
    return {
      clinician:
        refs.map((r) => practitioners.get(r)).find((x) => x !== undefined) ??
        '',
      location:
        refs.map((r) => locations.get(r)).find((x) => x !== undefined) ?? '',
    };
  };

  const appointments: AppointmentRow[] = [];
  for (const a of b.Appointment) {
    if (a.status === 'waitlist' || !a.start) continue;
    const pt = patientOf(a);
    const when = wallTime(a.start);
    appointments.push({
      id: a.id!,
      kind: 'appointment',
      patient: pt?.id ?? null,
      name: pt ? patientName(pt) : null,
      record: pt ? patientRecord(pt) : null,
      phone: pt ? patientAddress(pt) : null,
      date: when.date,
      time: when.time,
      ...namesOf(a),
      service: serviceOfAppointment(a),
      status: appointmentState(a),
      code: bookingCode(a),
      responses: responses.get(`Appointment/${a.id}`) ?? 0,
    });
  }
  for (const s of b.Slot) {
    // A slot is on the board as open when it is free and nothing holds it.
    if (s.status !== 'free' || busy.has(`Slot/${s.id}`)) continue;
    const when = wallTime(s.start);
    appointments.push({
      id: s.id!,
      kind: 'slot',
      patient: null,
      name: null,
      record: null,
      phone: null,
      date: when.date,
      time: when.time,
      ...slotNames(s),
      service: serviceOfAppointment(s),
      status: 'open',
      code: null,
      responses: 0,
    });
  }
  // By time; at the same time a booking before an open slot, then by id,
  // so the order is stable across reloads.
  appointments.sort(
    (x, y) =>
      (x.date + x.time).localeCompare(y.date + y.time) ||
      x.kind.localeCompare(y.kind) ||
      x.id.localeCompare(y.id),
  );

  const standby: StandbyRow[] = [];
  for (const a of b.Appointment) {
    const state = appointmentState(a);
    const onList =
      state === 'waiting' ||
      state === 'released' ||
      (['pending', 'booked'].includes(a.status) && assignedAt(a));
    if (!onList) continue;
    const pt = patientOf(a);
    if (!pt) continue;
    standby.push({
      id: a.id!,
      patient: pt.id!,
      name: patientName(pt),
      record: patientRecord(pt),
      phone: patientAddress(pt) ?? '',
      service: serviceOfAppointment(a),
      date: requestedDay(a),
      status: state === 'waiting' || state === 'released' ? state : 'booked',
      created: Date.parse(a.created ?? '') || 0,
      booking: state === 'waiting' || state === 'released' ? null : a.id!,
    });
  }
  standby.sort(
    (x, y) =>
      Number(!!y.date) - Number(!!x.date) ||
      (x.date ?? '').localeCompare(y.date ?? '') ||
      x.created - y.created,
  );

  return {
    patients: b.Patient.map((p) => ({
      id: p.id!,
      record: patientRecord(p),
      name: patientName(p),
      phone: patientAddress(p) ?? '',
      notes: patientNotes(p),
      consent: consents.get(`Patient/${p.id}`) ?? null,
    })),
    appointments,
    standby,
    messages: b.Communication.map((c) => ({
      id: c.id!,
      key: messageKey(c),
      phone: messageAddress(c) ?? '',
      body: messageBody(c),
      direction: messageDirection(c),
      status: deliveryStatus(c),
      error: c.statusReason?.text ?? null,
      created: messageAt(c),
      about: c.about?.[0]?.reference ?? null,
    })),
  };
}

// A clinician's day in a room as the booking form shows it: every start
// on the timetable, marked taken where a booking holds it. Names are
// matched exactly, as the server matches them; a clinician or room not yet
// on record has nothing booked. Empty on a day the centre is closed.
export function availability(
  b: Bundle,
  clinician: string,
  location: string,
  date: string,
): { time: string; taken: boolean }[] {
  const taken = new Set<string>();
  const practitioner = b.Practitioner.find(
    (p) => practitionerName(p) === clinician.trim(),
  );
  const room = b.Location.find((l) => l.name === location.trim());
  if (practitioner && room) {
    const refs = [`Practitioner/${practitioner.id}`, `Location/${room.id}`];
    const schedule = b.Schedule.find((s) =>
      refs.every((r) => s.actor.some((a) => a.reference === r)),
    );
    if (schedule)
      for (const x of b.Slot) {
        if (
          x.schedule.reference !== `Schedule/${schedule.id}` ||
          x.status !== 'busy'
        )
          continue;
        const w = wallTime(x.start);
        if (w.date === date) taken.add(w.time);
      }
  }
  return gridTimes(date).map((time) => ({ time, taken: taken.has(time) }));
}
