import schema from '../../fhir/r4-import.schema.json';

// Structural validation of a resource against HL7's R4 JSON schema, for
// what comes in from outside. The full schema cannot run in the Worker,
// but the part an import can reach — the nine resource types CareQueue
// takes in and the datatypes they use, 81 definitions, ~50 KB — can
// (scripts/fhir-subset.mjs writes it; the tests keep it in step with the
// official file). The schema uses a handful of keywords, and this is a
// validator for exactly those: $ref, type, properties, additionalProperties,
// required, enum, const, pattern, items. The tests check its verdicts
// against ajv on the official schema.

type Schema = {
  $ref?: string;
  type?: 'string' | 'number' | 'boolean' | 'array';
  properties?: Record<string, Schema>;
  additionalProperties?: boolean;
  required?: string[];
  enum?: string[];
  const?: string;
  pattern?: string;
  items?: Schema;
};

const definitions = schema.definitions as Record<string, Schema>;
const patterns = new Map<string, RegExp>();
const regex = (p: string) => {
  let r = patterns.get(p);
  if (!r) patterns.set(p, (r = new RegExp(p)));
  return r;
};

export type Violation = { path: string; message: string };

// Every way the resource departs from R4, up to a limit. The path is a
// JSON pointer without the leading slash ("name/0/given/1"); the message
// says what was expected.
export function violations(resource: unknown, limit = 20): Violation[] {
  const out: Violation[] = [];
  const type = (resource as { resourceType?: unknown })?.resourceType;
  if (typeof type !== 'string' || !definitions[type])
    return [{ path: '', message: `no R4 definition for ${String(type)}` }];
  check(resource, { $ref: '#/definitions/' + type }, '', type, out, limit);
  return out;
}

export function isValidR4(resource: unknown) {
  return violations(resource, 1).length === 0;
}

function check(
  value: unknown,
  s: Schema,
  path: string,
  named: string,
  out: Violation[],
  limit: number,
) {
  if (out.length >= limit) return;
  if (s.$ref) {
    named = s.$ref.replace('#/definitions/', '');
    s = definitions[named];
    if (!s) return;
  }
  const fail = (message: string) => out.push({ path, message });
  if (s.const !== undefined && value !== s.const)
    return fail(`must be "${s.const}"`);
  if (s.enum && !s.enum.includes(value as string))
    return fail(`must be one of ${s.enum.join(', ')}`);
  if (s.type) {
    const ok =
      s.type === 'array'
        ? Array.isArray(value)
        : s.type === 'number'
          ? typeof value === 'number' && Number.isFinite(value)
          : typeof value === s.type;
    if (!ok) return fail(`must be a ${s.type === 'array' ? 'list' : s.type}`);
  }
  if (s.pattern && typeof value === 'string' && !regex(s.pattern).test(value))
    return fail(`is not a valid ${named}`);
  if (s.items && Array.isArray(value))
    value.forEach((v, i) =>
      check(v, s.items!, path ? `${path}/${i}` : String(i), named, out, limit),
    );
  if (s.properties) {
    if (!value || typeof value !== 'object' || Array.isArray(value))
      return fail(`must be a ${named}`);
    const obj = value as Record<string, unknown>;
    for (const k of s.required ?? [])
      if (!(k in obj)) fail(`${path ? path + '/' : ''}${k} is required`);
    for (const [k, v] of Object.entries(obj)) {
      const sub = s.properties[k];
      const at = path ? `${path}/${k}` : k;
      if (sub) check(v, sub, at, named, out, limit);
      else if (s.additionalProperties === false)
        out.push({ path: at, message: `is not an element of ${named}` });
      if (out.length >= limit) return;
    }
  }
}
