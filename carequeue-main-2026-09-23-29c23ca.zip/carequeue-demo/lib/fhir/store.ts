import {
  assertResource,
  indexOf,
  type Of,
  type Stored,
  type StoredType,
} from './resources';

// A FHIR document store on D1: each resource is one JSON document in
// `resources`, addressed as Type/id within a workspace, with its search
// parameters written to `search_index` alongside it in the same batch. Every
// call takes the owner first and scopes every statement by it; there is no
// way to read or write across workspaces.
//
// Writes are versioned. `create` starts a resource at version 1; `update`
// takes the resource as it was read, with meta.versionId, and refuses to
// write over a newer version — the caller re-reads and decides. That replaces
// the guard columns of the old tables (an appointment's code, a WHERE on the
// status) with the one mechanism R4 itself defines for it.

// A write refused by the database: a version that moved on (`stale`) or a
// unique key already taken (`unique`).
export class Conflict extends Error {
  constructor(
    message: string,
    public kind: 'stale' | 'unique' = 'stale',
  ) {
    super(message);
  }
}

export type Params = Record<string, string | string[] | undefined>;
// How a search is ordered and cut: by the greatest value of one or more
// indexed parameters (ISO timestamps sort as text), newest first when
// `descending`, and at most `limit` resources.
export type SearchOptions = {
  sort?: { param: string | string[]; descending?: boolean };
  limit?: number;
};

// One write in a transaction: a new resource, a resource read earlier to
// write back (its meta.versionId is the version it was read at), or a
// removal.
export type Write =
  | { create: Stored }
  | { update: Stored }
  | { remove: { type: StoredType; id: string } };

export function newId() {
  return crypto.randomUUID();
}

function stamp<T extends Stored>(r: T, version: number, at: number): T {
  return {
    ...r,
    meta: {
      ...r.meta,
      versionId: String(version),
      lastUpdated: new Date(at).toISOString(),
    },
  };
}

function unique(err: unknown) {
  const message = err instanceof Error ? err.message : String(err);
  return /UNIQUE constraint/i.test(message);
}
// The guard statement below fails on a NOT NULL constraint when the
// statement before it changed nothing.
function stale(err: unknown) {
  const message = err instanceof Error ? err.message : String(err);
  return /NOT NULL constraint/i.test(message);
}

export function fhirStore(db: D1Database) {
  const q = (sql: string, ...args: unknown[]) => db.prepare(sql).bind(...args);

  // The index rows of a resource, rewritten as two statements — drop what
  // was there, insert what the document says now — each guarded by the
  // stored document being exactly the one this write produced. Inside a
  // batch that guard is what keeps a refused write (a stale update, an id
  // already taken) from touching the index at all: the document on disk is
  // then someone else's, and the guard is false. The comparison is exact
  // because meta.versionId and meta.lastUpdated are part of the document.
  function indexRows(o: string, r: Stored, json: string) {
    const rows = indexOf(r);
    const guard =
      'EXISTS(SELECT 1 FROM resources WHERE owner=? AND type=? AND id=? AND json=?)';
    const key = [o, r.resourceType, r.id, json];
    const out = [
      q(
        `DELETE FROM search_index WHERE owner=? AND type=? AND resource=? AND ${guard}`,
        o,
        r.resourceType,
        r.id,
        ...key,
      ),
    ];
    if (rows.length)
      out.push(
        q(
          `INSERT INTO search_index(owner,type,resource,param,value,"unique") SELECT column1,column2,column3,column4,column5,column6 FROM (VALUES ${rows.map(() => '(?,?,?,?,?,?)').join(',')}) WHERE ${guard}`,
          ...rows.flatMap((x) => [
            o,
            r.resourceType,
            r.id,
            x.param,
            x.value,
            x.unique ? 1 : 0,
          ]),
          ...key,
        ),
      );
    return out;
  }

  async function run(statements: D1PreparedStatement[]) {
    try {
      return await db.batch(statements);
    } catch (err) {
      if (unique(err))
        throw new Conflict(
          'Another record already holds that key. Reload and try again.',
          'unique',
        );
      if (stale(err))
        throw new Conflict(
          'Something here just changed. Reload and try again.',
          'stale',
        );
      throw err;
    }
  }

  // A statement that fails when the statement before it changed no row:
  // SQLite's changes() is the row count of the last INSERT, UPDATE or
  // DELETE, and inserting NULLs into NOT NULL columns is an error. Placed
  // right after a version-guarded UPDATE it turns "nothing matched" into a
  // failed batch — and a D1 batch is a transaction, so everything else in
  // it rolls back too. That is what lets several resources be written
  // together: all of them at the versions they were read at, or none.
  const guard = () =>
    q(
      'INSERT INTO resources(owner,type,id,version,updated,json) SELECT NULL,NULL,NULL,NULL,NULL,NULL WHERE changes()=0',
    );

  function insertStatements(o: string, r: Stored, json: string) {
    return [
      q(
        'INSERT INTO resources(owner,type,id,version,updated,json) VALUES(?,?,?,1,?,?)',
        o,
        r.resourceType,
        r.id,
        Date.parse(r.meta!.lastUpdated!),
        json,
      ),
      ...indexRows(o, r, json),
    ];
  }
  function updateStatements(
    o: string,
    r: Stored,
    expected: number,
    json: string,
  ) {
    return [
      q(
        'UPDATE resources SET version=?,updated=?,json=? WHERE owner=? AND type=? AND id=? AND version=?',
        Number(r.meta!.versionId),
        Date.parse(r.meta!.lastUpdated!),
        json,
        o,
        r.resourceType,
        r.id,
        expected,
      ),
      guard(),
      ...indexRows(o, r, json),
    ];
  }
  function removeStatements(o: string, type: StoredType, id: string) {
    return [
      q('DELETE FROM resources WHERE owner=? AND type=? AND id=?', o, type, id),
      q(
        'DELETE FROM search_index WHERE owner=? AND type=? AND resource=?',
        o,
        type,
        id,
      ),
    ];
  }
  // A resource as it will be written, and the version it must still be at.
  function prepare(w: Write, at: number) {
    if ('create' in w) {
      const r = stamp({ ...w.create, id: w.create.id ?? newId() }, 1, at);
      assertResource(r);
      return { r, expected: 0 };
    }
    if ('update' in w) {
      const expected = Number(w.update.meta?.versionId);
      if (!Number.isInteger(expected) || expected < 1 || !w.update.id)
        throw Error('update needs a resource read from the store.');
      const r = stamp(w.update, expected + 1, at);
      assertResource(r);
      return { r, expected };
    }
    return null;
  }

  return {
    // Several writes as one transaction: every create, update and removal
    // lands, or — if any resource moved on from the version it was read at,
    // or a unique key is taken — none does. Returns the resources as
    // written, in the order given (null for a removal).
    async transact(o: string, writes: Write[]): Promise<(Stored | null)[]> {
      const at = Date.now();
      const prepared = writes.map((w) => prepare(w, at));
      const statements: D1PreparedStatement[] = [];
      writes.forEach((w, i) => {
        const p = prepared[i];
        if ('remove' in w)
          statements.push(...removeStatements(o, w.remove.type, w.remove.id));
        else if (p && 'create' in w)
          statements.push(...insertStatements(o, p.r, JSON.stringify(p.r)));
        else if (p)
          statements.push(
            ...updateStatements(o, p.r, p.expected, JSON.stringify(p.r)),
          );
      });
      if (statements.length) await run(statements);
      return prepared.map((p) => p?.r ?? null);
    },

    // Store a new resource. The id is the caller's when set (deterministic
    // ids carry idempotency keys) and random otherwise.
    async create<T extends Stored>(o: string, resource: T): Promise<T> {
      const [r] = await this.transact(o, [{ create: resource }]);
      return r as T;
    },

    // Store a resource unless one with its id already exists, and say which
    // happened. This is how a message key becomes an idempotent send: the
    // caller acts only when `created` is true.
    async createIfAbsent<T extends Stored>(
      o: string,
      resource: T,
    ): Promise<{ created: boolean; resource: T }> {
      if (!resource.id) throw Error('createIfAbsent needs an id.');
      const r = stamp(resource, 1, Date.now());
      assertResource(r);
      const json = JSON.stringify(r);
      const [ins] = await run([
        q(
          'INSERT OR IGNORE INTO resources(owner,type,id,version,updated,json) VALUES(?,?,?,1,?,?)',
          o,
          r.resourceType,
          r.id,
          Date.parse(r.meta!.lastUpdated!),
          json,
        ),
        ...indexRows(o, r, json),
      ]);
      if (ins.meta.changes) return { created: true, resource: r };
      const existing = await this.read(o, r.resourceType, r.id!);
      if (!existing)
        throw new Conflict('The record was removed meanwhile.', 'stale');
      return { created: false, resource: existing as T };
    },

    async read<T extends StoredType>(
      o: string,
      type: T,
      id: string,
    ): Promise<Of<T> | null> {
      const row = await q(
        'SELECT json FROM resources WHERE owner=? AND type=? AND id=?',
        o,
        type,
        id,
      ).first<{ json: string }>();
      return row ? JSON.parse(row.json) : null;
    },

    // Resolve a reference such as "Patient/abc". A reference to a type the
    // store does not hold, or to nothing, is null.
    async resolve(o: string, ref: string | undefined): Promise<Stored | null> {
      const m = ref?.match(/^([A-Za-z]+)\/([A-Za-z0-9\-.]{1,64})$/);
      if (!m) return null;
      return this.read(o, m[1] as StoredType, m[2]);
    },

    // Write a resource read earlier. meta.versionId is the version it was
    // read at; if the stored version moved on, nothing is written.
    async update<T extends Stored>(o: string, resource: T): Promise<T> {
      try {
        const [r] = await this.transact(o, [{ update: resource }]);
        return r as T;
      } catch (err) {
        if (err instanceof Conflict && err.kind === 'stale')
          throw new Conflict(
            `This ${resource.resourceType.toLowerCase()} just changed. Reload and try again.`,
          );
        throw err;
      }
    },

    async remove(o: string, type: StoredType, id: string): Promise<boolean> {
      const [del] = await run(removeStatements(o, type, id));
      return del.meta.changes > 0;
    },

    // Resources of one type matching every parameter given; a parameter
    // with several values matches any of them (FHIR's comma-separated OR).
    // Results come back oldest write first unless `sort` says otherwise;
    // `limit` cuts them in the database, not after.
    async search<T extends StoredType>(
      o: string,
      type: T,
      params: Params = {},
      options: SearchOptions = {},
    ): Promise<Of<T>[]> {
      const where = ['r.owner=?', 'r.type=?'];
      const args: unknown[] = [o, type];
      for (const [param, raw] of Object.entries(params)) {
        if (raw === undefined) continue;
        const values = Array.isArray(raw) ? raw : [raw];
        if (!values.length) return [];
        where.push(
          `EXISTS(SELECT 1 FROM search_index i WHERE i.owner=r.owner AND i.type=r.type AND i.resource=r.id AND i.param=? AND i.value IN (${values.map(() => '?').join(',')}))`,
        );
        args.push(param, ...values);
      }
      let order = 'r.updated,r.id';
      if (options.sort) {
        const names = [options.sort.param].flat();
        order = `(SELECT MAX(i.value) FROM search_index i WHERE i.owner=r.owner AND i.type=r.type AND i.resource=r.id AND i.param IN (${names.map(() => '?').join(',')})) ${options.sort.descending ? 'DESC' : 'ASC'},r.updated ${options.sort.descending ? 'DESC' : 'ASC'},r.id`;
        args.push(...names);
      }
      const limit = options.limit ? ' LIMIT ?' : '';
      if (options.limit) args.push(options.limit);
      const rows = await q(
        `SELECT r.json FROM resources r WHERE ${where.join(' AND ')} ORDER BY ${order}${limit}`,
        ...args,
      ).all<{ json: string }>();
      return rows.results.map((row) => JSON.parse(row.json));
    },

    // Every resource in the workspace, for the tests to validate and for a
    // full export.
    async everything(o: string): Promise<Stored[]> {
      const rows = await q(
        'SELECT json FROM resources WHERE owner=? ORDER BY type,updated,id',
        o,
      ).all<{ json: string }>();
      return rows.results.map((row) => JSON.parse(row.json));
    },
  };
}

export type Store = ReturnType<typeof fhirStore>;
