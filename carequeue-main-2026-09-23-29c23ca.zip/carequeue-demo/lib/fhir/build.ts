import type * as R4 from 'fhir/r4';
import { programs } from '../services';
import { EXT, SYSTEM, humanName, idFrom, reference } from './resources';

// How CareQueue's facts become R4 resources, and how they are read back.
// Builders take the plain values staff enter and return a resource ready
// for the store; accessors pull the same values out again, so the rest of
// the code never walks a resource by hand. Nothing here touches the
// database.

// ---------------------------------------------------------------- catalogue

// A code from a Spanish service name: accents dropped, lower-case, hyphens.
// "Consulta ginecológica" → "consulta-ginecologica". Stable as long as the
// name is, which is what the catalogue promises.
export function slug(name: string) {
  return name
    .normalize('NFD')
    .replace(/\p{M}/gu, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '');
}

const catalogue = new Map(
  programs.flatMap((p) => p.services.map((s) => [s, p.name] as const)),
);

// The programme a catalogue service belongs to, or null for a service that
// was typed in.
export function programOf(service: string) {
  return catalogue.get(service) ?? null;
}

// Appointment.serviceType / Slot.serviceType. A catalogue service carries a
// coding from the clinic's own code system; any other non-empty service is
// accepted as text alone, so records that predate the menu keep working.
export function serviceConcept(service: string): R4.CodeableConcept {
  return catalogue.has(service)
    ? {
        coding: [
          { system: SYSTEM.service, code: slug(service), display: service },
        ],
        text: service,
      }
    : { text: service };
}
export function serviceName(c: R4.CodeableConcept | undefined) {
  return c?.text ?? c?.coding?.[0]?.display ?? c?.coding?.[0]?.code ?? '';
}

// The catalogue itself as a CodeSystem: programmes as top-level concepts,
// services grouped under them. Not stored — it is a fact of the code, and
// the tests validate it like any other resource.
export function serviceCodeSystem(): R4.CodeSystem {
  return {
    resourceType: 'CodeSystem',
    id: 'service',
    url: SYSTEM.service,
    name: 'CareQueueService',
    title: 'Servicios del centro de salud',
    status: 'active',
    content: 'complete',
    caseSensitive: true,
    hierarchyMeaning: 'grouped-by',
    count: programs.reduce((n, p) => n + 1 + p.services.length, 0),
    concept: programs.map((p) => ({
      code: slug(p.name),
      display: p.name,
      concept: p.services.map((s) => ({ code: slug(s), display: s })),
    })),
  };
}

// ---------------------------------------------------------------- people

export type Address = {
  value: string;
  system: 'phone' | 'other';
  provider: string;
};

export function buildPatient(input: {
  record: string;
  name: string;
  address: Address;
  notes: string | null;
}): R4.Patient {
  return {
    resourceType: 'Patient',
    active: true,
    identifier: [{ system: SYSTEM.record, value: input.record }],
    name: [{ text: input.name }],
    telecom: [contactPoint(input.address)],
    ...(input.notes
      ? { extension: [{ url: EXT.notes, valueString: input.notes }] }
      : {}),
  };
}

export function contactPoint(a: Address): R4.ContactPoint {
  return {
    system: a.system,
    value: a.value,
    extension: [{ url: EXT.provider, valueCode: a.provider }],
  };
}

// The same patient with a new name, address or notes. Returns a fresh
// object; the store's version check does the rest.
export function revisePatient(
  p: R4.Patient,
  input: { name: string; address: Address; notes: string | null },
): R4.Patient {
  const extension = (p.extension ?? []).filter((x) => x.url !== EXT.notes);
  if (input.notes) extension.push({ url: EXT.notes, valueString: input.notes });
  const { extension: _dropped, ...rest } = p;
  return {
    ...rest,
    name: [{ ...p.name?.[0], text: input.name }],
    telecom: [contactPoint(input.address)],
    ...(extension.length ? { extension } : {}),
  };
}

export { humanName };
export const patientName = (p: R4.Patient) => humanName(p.name?.[0]);
// The clinic's record number, or failing that whatever identifier came
// with an imported record.
export const patientRecord = (p: R4.Patient) =>
  p.identifier?.find((i) => i.system === SYSTEM.record)?.value ??
  p.identifier?.find((i) => i.value)?.value ??
  '';
export const patientAddress = (p: R4.Patient) => p.telecom?.[0]?.value ?? null;
export const patientNotes = (p: R4.Patient) =>
  p.extension?.find((x) => x.url === EXT.notes)?.valueString ?? null;

// The patient's consent to be reached at their address for test messages.
// The device owner consented when the address was registered; this is the
// record, per patient, that this fictional patient may be written to there.
export function buildConsent(patient: R4.Patient, at: number): R4.Consent {
  return {
    resourceType: 'Consent',
    status: 'active',
    scope: {
      coding: [
        {
          system: 'http://terminology.hl7.org/CodeSystem/consentscope',
          code: 'patient-privacy',
        },
      ],
    },
    category: [{ coding: [{ system: 'http://loinc.org', code: '59284-0' }] }],
    patient: { reference: reference('Patient', patient.id!) },
    dateTime: new Date(at).toISOString(),
    performer: [{ reference: reference('Patient', patient.id!) }],
    policy: [{ uri: SYSTEM.consentPolicy }],
    provision: { type: 'permit' },
  };
}

export function buildPractitioner(name: string): R4.Practitioner {
  return { resourceType: 'Practitioner', active: true, name: [{ text: name }] };
}
export const practitionerName = (p: R4.Practitioner) => humanName(p.name?.[0]);

export function buildLocation(name: string): R4.Location {
  return { resourceType: 'Location', status: 'active', mode: 'instance', name };
}

export function buildHealthcareService(service: string): R4.HealthcareService {
  const program = programOf(service);
  return {
    resourceType: 'HealthcareService',
    active: true,
    name: service,
    type: [serviceConcept(service)],
    ...(program ? { category: [{ text: program }] } : {}),
  };
}

// ---------------------------------------------------------------- extensions

export function extValue(
  r: { extension?: R4.Extension[] },
  url: string,
): R4.Extension | null {
  return r.extension?.find((x) => x.url === url) ?? null;
}
export function withExtension<T extends { extension?: R4.Extension[] }>(
  r: T,
  ext: R4.Extension,
): T {
  const extension = (r.extension ?? []).filter((x) => x.url !== ext.url);
  extension.push(ext);
  return { ...r, extension };
}
export function withoutExtension<T extends { extension?: R4.Extension[] }>(
  r: T,
  url: string,
): T {
  const extension = (r.extension ?? []).filter((x) => x.url !== url);
  const { extension: _dropped, ...rest } = r;
  return (extension.length ? { ...rest, extension } : rest) as T;
}

// ---------------------------------------------------------------- scheduling

// One schedule per clinician in a room; slots hang off it.
export function buildSchedule(
  practitioner: R4.Practitioner,
  location: R4.Location,
): R4.Schedule {
  return {
    resourceType: 'Schedule',
    active: true,
    actor: [
      { reference: reference('Practitioner', practitioner.id!) },
      { reference: reference('Location', location.id!) },
    ],
  };
}

export function buildSlot(input: {
  schedule: R4.Schedule;
  start: string;
  end: string;
  service: string;
  status: 'free' | 'busy';
}): R4.Slot {
  return {
    resourceType: 'Slot',
    schedule: { reference: reference('Schedule', input.schedule.id!) },
    serviceType: [serviceConcept(input.service)],
    status: input.status,
    start: input.start,
    end: input.end,
  };
}

// A patient's request for a service on a day, or on any day: an
// Appointment on the waitlist, not yet tied to a slot.
export function buildWaitlist(input: {
  patient: R4.Patient;
  service: string;
  day: string | null;
  created: number;
}): R4.Appointment {
  return {
    resourceType: 'Appointment',
    status: 'waitlist',
    serviceType: [serviceConcept(input.service)],
    created: new Date(input.created).toISOString(),
    ...(input.day
      ? { requestedPeriod: [{ start: input.day, end: input.day }] }
      : {}),
    participant: [
      {
        actor: { reference: reference('Patient', input.patient.id!) },
        status: 'needs-action',
      },
    ],
  };
}

// The same appointment placed on a slot, awaiting the patient's answer. Used
// both for a direct booking (from a bare waitlist-shaped request) and for an
// assignment from the standby list.
export function placeOnSlot(
  a: R4.Appointment,
  input: {
    slot: R4.Slot;
    schedule: R4.Schedule;
    service: string;
    code: string;
  },
): R4.Appointment {
  const patient = a.participant.find((p) =>
    p.actor?.reference?.startsWith('Patient/'),
  )!;
  return {
    ...a,
    status: 'pending',
    identifier: [{ system: SYSTEM.bookingCode, value: input.code }],
    serviceType: [serviceConcept(input.service)],
    slot: [{ reference: reference('Slot', input.slot.id!) }],
    start: input.slot.start,
    end: input.slot.end,
    participant: [
      { ...patient, status: 'needs-action' },
      ...input.schedule.actor.map((actor) => ({
        actor,
        status: 'accepted' as const,
      })),
    ],
  };
}

// The same appointment taken off its slot and back onto the waitlist.
export function takeOffSlot(a: R4.Appointment): R4.Appointment {
  const { identifier: _i, slot: _s, start: _st, end: _e, ...rest } = a;
  return {
    ...rest,
    status: 'waitlist',
    participant: a.participant
      .filter((p) => p.actor?.reference?.startsWith('Patient/'))
      .map((p) => ({ ...p, status: 'needs-action' as const })),
  };
}

export const actorRef = (a: R4.Appointment, type: string) =>
  a.participant.find((p) => p.actor?.reference?.startsWith(type + '/'))?.actor
    ?.reference ?? null;
export const patientRefOf = (a: R4.Appointment) => actorRef(a, 'Patient');
export const slotRefOf = (a: R4.Appointment) => a.slot?.[0]?.reference ?? null;
export const bookingCode = (a: R4.Appointment) =>
  a.identifier?.find((i) => i.system === SYSTEM.bookingCode)?.value ?? null;
export const serviceOfAppointment = (a: R4.Appointment | R4.Slot) =>
  serviceName(a.serviceType?.[0]);
// The day a waitlist entry is for, or null for any day.
export const requestedDay = (a: R4.Appointment) =>
  a.requestedPeriod?.[0]?.start?.slice(0, 10) ?? null;
export const assignedAt = (a: R4.Appointment) =>
  extValue(a, EXT.assigned)?.valueDateTime ?? null;
export const releasedAt = (a: R4.Appointment) =>
  extValue(a, EXT.released)?.valueDateTime ?? null;
export const LIVE = ['pending', 'booked'] as const;
export const isLive = (a: R4.Appointment) =>
  (LIVE as readonly string[]).includes(a.status);
// A waitlist entry that is actually waiting — not parked after a release.
export const isWaiting = (a: R4.Appointment) =>
  a.status === 'waitlist' && !releasedAt(a);

// The words staff and the message templates use for an appointment's
// state, from its R4 status and marks: `scheduled` (pending, booked
// directly), `filled` (pending, assigned from standby), `confirmed`
// (booked), `waiting`, `released` and `cancelled`.
export function appointmentState(a: R4.Appointment) {
  switch (a.status) {
    case 'pending':
      return assignedAt(a) ? 'filled' : 'scheduled';
    case 'booked':
      return 'confirmed';
    case 'waitlist':
      return releasedAt(a) ? 'released' : 'waiting';
    default:
      return a.status;
  }
}

// ---------------------------------------------------------------- messages

export type MessageCategory =
  | 'reminder'
  | 'standby'
  | 'inquiry'
  | 'acknowledgement'
  | 'reschedule'
  | 'inbound';

function category(codes: MessageCategory[]): R4.CodeableConcept[] {
  return codes.map((code) => ({
    coding: [{ system: SYSTEM.messageCategory, code }],
  }));
}

// A message on its way out. Its id is the idempotency key, so a second
// attempt under the same key finds the first. The address it goes to is an
// extension: R4 addresses a Communication to a person, and one device may
// stand for several fictional patients here.
export function buildOutbound(input: {
  key: string;
  address: { value: string; system: 'phone' | 'other' };
  body: string;
  categories: MessageCategory[];
  sent: number;
  about?: string | null;
  recipient?: string | null;
  inResponseTo?: string | null;
}): R4.Communication {
  return {
    resourceType: 'Communication',
    id: idFrom(input.key),
    status: 'preparation',
    category: category(input.categories),
    identifier: [{ system: SYSTEM.messageKey, value: input.key }],
    sent: new Date(input.sent).toISOString(),
    ...(input.about ? { about: [{ reference: input.about }] } : {}),
    ...(input.recipient ? { recipient: [{ reference: input.recipient }] } : {}),
    ...(input.inResponseTo
      ? { inResponseTo: [{ reference: input.inResponseTo }] }
      : {}),
    payload: [{ contentString: input.body }],
    extension: [
      {
        url: EXT.address,
        valueContactPoint: {
          system: input.address.system,
          value: input.address.value,
        },
      },
      { url: EXT.delivery, valueString: 'sending' },
    ],
  };
}

// A reply that came in. Its id is the provider's own message id, so a
// re-fetch of the same update cannot record it twice.
export function buildInbound(input: {
  sid: string;
  address: { value: string; system: 'phone' | 'other' };
  body: string;
  received: number;
}): R4.Communication {
  return {
    resourceType: 'Communication',
    id: idFrom('inbound:' + input.sid),
    status: 'completed',
    category: category(['inbound']),
    identifier: [{ system: SYSTEM.providerMessage, value: input.sid }],
    received: new Date(input.received).toISOString(),
    payload: [{ contentString: input.body }],
    extension: [
      {
        url: EXT.address,
        valueContactPoint: {
          system: input.address.system,
          value: input.address.value,
        },
      },
      { url: EXT.delivery, valueString: 'received' },
    ],
  };
}

// What the provider said about a message: its status word, kept verbatim
// for staff, mapped onto R4's event status; its own id; an error.
export function withDelivery(
  c: R4.Communication,
  input: {
    delivery: string;
    sid?: string;
    body?: string;
    error?: string | null;
  },
): R4.Communication {
  const { statusReason: _dropped, ...rest } = c;
  const identifier = input.sid
    ? [
        ...(c.identifier ?? []).filter(
          (i) => i.system !== SYSTEM.providerMessage,
        ),
        { system: SYSTEM.providerMessage, value: input.sid },
      ]
    : (c.identifier ?? []);
  return withExtension(
    {
      ...rest,
      status: communicationStatus(input.delivery),
      identifier,
      ...(input.body ? { payload: [{ contentString: input.body }] } : {}),
      ...(input.error ? { statusReason: { text: input.error } } : {}),
    },
    { url: EXT.delivery, valueString: input.delivery },
  );
}

// Provider status words onto R4 Communication.status.
export function communicationStatus(
  delivery: string,
): R4.Communication['status'] {
  switch (delivery) {
    case 'sending':
      return 'preparation';
    case 'delivered':
    case 'read':
    case 'received':
      return 'completed';
    case 'failed':
    case 'undelivered':
      return 'not-done';
    case 'unknown':
      return 'unknown';
    default:
      return 'in-progress';
  }
}

export const messageKey = (c: R4.Communication) =>
  c.identifier?.find((i) => i.system === SYSTEM.messageKey)?.value ?? null;
export const providerSid = (c: R4.Communication) =>
  c.identifier?.find((i) => i.system === SYSTEM.providerMessage)?.value ?? null;
export const deliveryStatus = (c: R4.Communication) =>
  extValue(c, EXT.delivery)?.valueString ?? c.status;
export const messageAddress = (c: R4.Communication) =>
  extValue(c, EXT.address)?.valueContactPoint?.value ?? null;
export const messageBody = (c: R4.Communication) =>
  c.payload?.[0]?.contentString ?? '';
export const messageDirection = (c: R4.Communication) =>
  c.received && !c.sent ? 'inbound' : 'outbound';
export const hasCategory = (c: R4.Communication, code: MessageCategory) =>
  !!c.category?.some((x) =>
    x.coding?.some(
      (k) => k.system === SYSTEM.messageCategory && k.code === code,
    ),
  );
// When a message went out or came in, as milliseconds.
export const messageAt = (c: R4.Communication) =>
  Date.parse(c.sent ?? c.received ?? c.meta?.lastUpdated ?? '') || 0;
