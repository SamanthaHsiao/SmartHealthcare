import type * as R4 from 'fhir/r4';
import { field, validDate, validSlot } from '../rules';
import { gridTimes, validClinicSlot } from '../timetable';
import { id, now, store } from '../workspace';
import { Conflict, newId, type Write } from './store';
import { EXT, reference, refId } from './resources';
import {
  assignedAt,
  buildSchedule,
  buildSlot,
  buildWaitlist,
  isLive,
  isWaiting,
  LIVE,
  patientRefOf,
  placeOnSlot,
  releasedAt,
  requestedDay,
  serviceConcept,
  serviceOfAppointment,
  slotRefOf,
  takeOffSlot,
  withExtension,
  withoutExtension,
} from './build';
import {
  instantAt,
  instantOf,
  plusMinutes,
  SLOT_MINUTES,
  wallTime,
} from './time';
import {
  assertReachable,
  locationOf,
  patientOf,
  practitionerOf,
  serviceOf,
} from './registry';

// Appointments, slots and the standby list as FHIR resources.
//
// A slot is a Slot on the Schedule of a clinician in a room: `busy` while an
// appointment holds it, `free` when it is open for someone from the standby
// list. A booking is an Appointment on that slot, `pending` until the
// patient confirms and `booked` after. A standby entry is an Appointment
// too, with status `waitlist` and no slot — the R4 meaning of the word:
// "to be scheduled when a slot is available". Assigning a standby patient
// moves that same Appointment onto the slot; undoing the assignment moves it
// back, marked released so staff see it needs a decision. Nothing is copied
// between two records, so nothing can disagree.

const iso = () => new Date(now()).toISOString();
const CHANGED = 'This appointment just changed. Reload and try again.';
const TAKEN =
  'This clinician already has an appointment slot at that time and location.';

export async function scheduleOf(
  o: string,
  practitioner: R4.Practitioner,
  location: R4.Location,
) {
  const s = store();
  const key = [
    reference('Practitioner', practitioner.id!),
    reference('Location', location.id!),
  ]
    .sort()
    .join(',');
  const [found] = await s.search(o, 'Schedule', { actors: key });
  if (found) return found;
  try {
    return await s.create(o, buildSchedule(practitioner, location));
  } catch (err) {
    if (err instanceof Conflict) {
      const [again] = await s.search(o, 'Schedule', { actors: key });
      if (again) return again;
    }
    throw err;
  }
}

// What staff typed for a slot, validated.
function slotInput(data: any) {
  const date = field(data.date, 'Date'),
    time = field(data.time, 'Time');
  validSlot(date, time);
  validClinicSlot(date, time);
  return {
    date,
    time,
    clinician: field(data.clinician, 'Clinician'),
    location: field(data.location, 'Location'),
    service: field(data.service, 'Service'),
  };
}

// Resolve the names in a slot input to resources and the start instant.
async function place(o: string, input: ReturnType<typeof slotInput>) {
  const practitioner = await practitionerOf(o, input.clinician);
  const location = await locationOf(o, input.location);
  await serviceOf(o, input.service);
  const schedule = await scheduleOf(o, practitioner, location);
  const start = instantOf(input.date, input.time);
  return { schedule, start, end: plusMinutes(start, SLOT_MINUTES) };
}

// The write that takes a slot at that start: a new busy Slot, or the open
// one already there — left by a cancellation — turned busy, with the
// service the booking is for. A start another booking holds is refused
// here; a race for the same start is refused by the unique index when the
// transaction runs. Nothing is written until the caller's transaction
// runs, so the slot and what goes on it land together or not at all.
export async function holdSlot(
  o: string,
  at: Awaited<ReturnType<typeof place>>,
  service: string,
): Promise<{ slot: R4.Slot; write: Write }> {
  const s = store();
  const key = `${reference('Schedule', at.schedule.id!)}@${at.start}`;
  const [existing] = await s.search(o, 'Slot', { 'schedule-start': key });
  if (existing) {
    if (existing.status !== 'free') throw Error(TAKEN);
    const slot: R4.Slot = {
      ...existing,
      status: 'busy',
      serviceType: [serviceConcept(service)],
    };
    return { slot, write: { update: slot } };
  }
  const slot: R4.Slot = {
    ...buildSlot({
      schedule: at.schedule,
      start: at.start,
      end: at.end,
      service,
      status: 'busy',
    }),
    id: newId(),
  };
  return { slot, write: { create: slot } };
}

async function liveAppointment(o: string, value: unknown, message: string) {
  const a = await store().read(o, 'Appointment', String(value ?? ''));
  if (!a || !isLive(a)) throw Error(message);
  return a;
}

async function slotOf(o: string, a: R4.Appointment) {
  const slotId = refId('Slot', slotRefOf(a) ?? undefined);
  return slotId ? store().read(o, 'Slot', slotId) : null;
}

// A refused transaction, in the caller's words: a unique key taken is the
// slot being taken; anything else is something having changed underneath.
function conflict(err: unknown, message = CHANGED, taken = TAKEN): never {
  if (err instanceof Conflict)
    throw Error(err.kind === 'unique' ? taken : message);
  throw err;
}

// ---------------------------------------------------------------- booking

export async function book(o: string, data: any) {
  const s = store();
  const patient = await patientOf(o, data.patient);
  const input = slotInput(data);
  const at = await place(o, input);
  const held = await holdSlot(o, at, input.service);
  const [, appointment] = await s
    .transact(o, [
      held.write,
      {
        create: placeOnSlot(
          buildWaitlist({
            patient,
            service: input.service,
            day: null,
            created: now(),
          }),
          {
            slot: held.slot,
            schedule: at.schedule,
            service: input.service,
            code: id(),
          },
        ),
      },
    ])
    .catch((err) => conflict(err, TAKEN));
  return appointment as R4.Appointment;
}

// Edit a live appointment: another patient, day, time, clinician, room or
// service. A different slot or patient invalidates any confirmation already
// recorded: the booking code rotates, which retires the reminder sent for
// the old one, and the appointment goes back to pending.
export async function editAppointment(o: string, data: any) {
  const s = store();
  const a = await liveAppointment(
    o,
    data.id,
    'Select an active appointment to edit.',
  );
  const patient = await patientOf(o, data.patient);
  const input = slotInput(data);
  const slot = await slotOf(o, a);
  if (!slot) throw Error(CHANGED);
  const at = await place(o, input);
  const slotMoved =
    slot.schedule.reference !== reference('Schedule', at.schedule.id!) ||
    slot.start !== at.start;
  const patientMoved = patientRefOf(a) !== reference('Patient', patient.id!);
  const moved = slotMoved || patientMoved;
  // The slot this booking will hold, and what writing it takes.
  const writes: Write[] = [];
  let held = slot;
  if (slotMoved) {
    const hold = await holdSlot(o, at, input.service);
    held = hold.slot;
    writes.push(hold.write, { remove: { type: 'Slot', id: slot.id! } });
  } else if (serviceOfAppointment(slot) !== input.service) {
    held = { ...slot, serviceType: [serviceConcept(input.service)] };
    writes.push({ update: held });
  }
  const patientPart = a.participant.find((p) =>
    p.actor?.reference?.startsWith('Patient/'),
  )!;
  let revised = placeOnSlot(
    {
      ...a,
      participant: [
        {
          ...patientPart,
          actor: { reference: reference('Patient', patient.id!) },
        },
      ],
    },
    {
      slot: held,
      schedule: at.schedule,
      service: input.service,
      code: moved ? id() : (a.identifier?.[0]?.value ?? id()),
    },
  );
  if (!moved)
    revised = {
      ...revised,
      status: a.status,
      participant: revised.participant.map((p, i) =>
        i === 0 ? { ...p, status: patientPart.status } : p,
      ),
    };
  await s.transact(o, [...writes, { update: revised }]).catch(conflict);
  return { moved };
}

// The slot is given up. A direct booking is cancelled; an appointment that
// came from the standby list goes back onto it, marked released, so staff
// see it needs a decision rather than finding it gone. The slot stays on
// the board as free unless the caller is deleting it.
async function releaseWrites(
  o: string,
  a: R4.Appointment,
  slotOutcome: 'free' | 'delete',
) {
  const requeue = !!assignedAt(a);
  const revised: R4.Appointment = requeue
    ? withExtension(withoutExtension(takeOffSlot(a), EXT.assigned), {
        url: EXT.released,
        valueDateTime: iso(),
      })
    : { ...a, status: 'cancelled' };
  const writes: Write[] = [{ update: revised }];
  const slot = await slotOf(o, a);
  if (slot)
    writes.push(
      slotOutcome === 'delete'
        ? { remove: { type: 'Slot', id: slot.id! } }
        : { update: { ...slot, status: 'free' } },
    );
  return { writes, requeued: requeue };
}
async function release(
  o: string,
  a: R4.Appointment,
  slotOutcome: 'free' | 'delete',
) {
  const { writes, requeued } = await releaseWrites(o, a, slotOutcome);
  const [appointment] = await store().transact(o, writes).catch(conflict);
  return { appointment: appointment as R4.Appointment, requeued };
}

export async function cancelAppointment(o: string, value: unknown) {
  const a = await liveAppointment(o, value, 'Select an active appointment.');
  return release(o, a, 'free');
}

// Delete a booking outright. Its slot goes with it. An assignment from the
// standby list leaves the entry behind as released, as cancelling does;
// message history is kept either way, because those messages were sent.
export async function deleteAppointment(o: string, value: unknown) {
  const s = store();
  const a = await s.read(o, 'Appointment', String(value ?? ''));
  if (!a || a.status === 'waitlist')
    throw Error('Select an appointment to delete.');
  if (isLive(a) && assignedAt(a)) {
    await release(o, a, 'delete');
    return { kept: true };
  }
  const writes: Write[] = (
    await s.search(o, 'AppointmentResponse', {
      appointment: reference('Appointment', a.id!),
    })
  ).map((r) => ({ remove: { type: 'AppointmentResponse', id: r.id! } }));
  writes.push({ remove: { type: 'Appointment', id: a.id! } });
  const slot = isLive(a) ? await slotOf(o, a) : null;
  if (slot) writes.push({ remove: { type: 'Slot', id: slot.id! } });
  await s.transact(o, writes);
  return { kept: false };
}

export async function deleteSlot(o: string, value: unknown) {
  const s = store();
  const slot = await s.read(o, 'Slot', String(value ?? ''));
  if (!slot || slot.status !== 'free')
    throw Error('Select an open slot to delete.');
  await s.remove(o, 'Slot', slot.id!);
}

// The patient confirmed, by their own command or by a reply staff reviewed.
// The answer is recorded as an AppointmentResponse and the appointment is
// booked. Callers have already checked the appointment is awaiting it.
export async function confirmAppointment(
  o: string,
  a: R4.Appointment,
  comment: string,
) {
  const s = store();
  const patient = patientRefOf(a)!;
  const [booked] = await s
    .transact(o, [
      {
        update: {
          ...a,
          status: 'booked',
          participant: a.participant.map((p) =>
            p.actor?.reference === patient ? { ...p, status: 'accepted' } : p,
          ),
        },
      },
      {
        create: {
          resourceType: 'AppointmentResponse',
          appointment: { reference: reference('Appointment', a.id!) },
          actor: { reference: patient },
          participantStatus: 'accepted',
          ...(a.start ? { start: a.start, end: a.end } : {}),
          comment,
        },
      },
    ])
    .catch(conflict);
  return booked as R4.Appointment;
}

// A new delivery address invalidates any confirmation: the person at the
// new address never agreed to these slots. Same rule as editing the slot.
export async function readdress(o: string, patient: R4.Patient) {
  const s = store();
  const live = await s.search(o, 'Appointment', {
    patient: reference('Patient', patient.id!),
    status: [...LIVE],
  });
  await s
    .transact(
      o,
      live.map((a) => ({
        update: {
          ...a,
          status: 'pending' as const,
          identifier: a.identifier?.map((i) => ({ ...i, value: id() })),
          participant: a.participant.map((p) =>
            p.actor?.reference?.startsWith('Patient/')
              ? { ...p, status: 'needs-action' as const }
              : p,
          ),
        },
      })),
    )
    .catch(conflict);
}

// ---------------------------------------------------------------- standby

function dayInput(data: any) {
  const day = String(data.date ?? '').trim() || null;
  if (day) validDate(day);
  return day;
}

// A patient may wait for the same service on several days, but not twice
// on one day (nor twice for any day).
async function alreadyWaiting(
  o: string,
  patient: R4.Patient,
  service: string,
  day: string | null,
  except?: string,
) {
  const list = await store().search(o, 'Appointment', {
    patient: reference('Patient', patient.id!),
    status: 'waitlist',
  });
  if (
    list.some(
      (a) =>
        a.id !== except &&
        isWaiting(a) &&
        serviceOfAppointment(a) === service &&
        requestedDay(a) === day,
    )
  )
    throw Error(
      day
        ? 'This patient is already waiting for that service on that day.'
        : 'This patient is already waiting for that service on any day.',
    );
}

export async function queue(o: string, data: any) {
  const patient = await patientOf(o, data.patient);
  const service = field(data.service, 'Service');
  const day = dayInput(data);
  await serviceOf(o, service);
  await alreadyWaiting(o, patient, service, day);
  return store().create(
    o,
    buildWaitlist({ patient, service, day, created: now() }),
  );
}

// Rewrite a waiting entry, or re-queue a released one. An entry that has
// been placed on a slot is that appointment now and is edited as one.
export async function editQueued(o: string, data: any) {
  const s = store();
  const a = await s.read(o, 'Appointment', String(data.id ?? ''));
  if (!a) throw Error('Select a standby entry to edit.');
  if (a.status !== 'waitlist')
    throw Error(
      'This entry has already been booked into a slot. Edit or delete the appointment instead.',
    );
  const patient = await patientOf(o, data.patient);
  const service = field(data.service, 'Service');
  const day = dayInput(data);
  await serviceOf(o, service);
  await alreadyWaiting(o, patient, service, day, a.id);
  const { requestedPeriod: _dropped, ...rest } = a;
  await s
    .update(
      o,
      withoutExtension(
        {
          ...rest,
          serviceType: [serviceConcept(service)],
          ...(day ? { requestedPeriod: [{ start: day, end: day }] } : {}),
          participant: [
            {
              actor: { reference: reference('Patient', patient.id!) },
              status: 'needs-action',
            },
          ],
        },
        EXT.released,
      ),
    )
    .catch(conflict);
  return { requeued: !!releasedAt(a) };
}

export async function removeQueued(o: string, value: unknown) {
  const s = store();
  const a = await s.read(o, 'Appointment', String(value ?? ''));
  if (!a || a.status !== 'waitlist')
    throw Error('Select a standby entry to remove.');
  await s.remove(o, 'Appointment', a.id!);
}

// Staff put a waiting patient on an open slot. The entry becomes the
// appointment: pending, awaiting the patient's confirmation, carrying the
// slot's service and a fresh booking code. Assignment is not acceptance.
export async function assign(
  o: string,
  slotValue: unknown,
  candidate: unknown,
) {
  const s = store();
  const slot = await s.read(o, 'Slot', String(slotValue ?? ''));
  const w = await s.read(o, 'Appointment', String(candidate ?? ''));
  const patient =
    w &&
    (await s.read(
      o,
      'Patient',
      refId('Patient', patientRefOf(w) ?? undefined) ?? '',
    ));
  if (!slot || slot.status !== 'free' || !w || !isWaiting(w) || !patient)
    throw Error('Choose an open slot and a waiting patient.');
  await assertReachable(o, patient);
  const schedule = await s.read(
    o,
    'Schedule',
    refId('Schedule', slot.schedule.reference) ?? '',
  );
  if (!schedule) throw Error('Choose an open slot and a waiting patient.');
  const taken = 'The slot or candidate changed. Reload and try again.';
  const code = id();
  const held: R4.Slot = { ...slot, status: 'busy' };
  // The slot and the entry move together: both at the versions just read,
  // or neither.
  const [, appointment] = await s
    .transact(o, [
      { update: held },
      {
        update: withExtension(
          placeOnSlot(w, {
            slot: held,
            schedule,
            service: serviceOfAppointment(slot),
            code,
          }),
          { url: EXT.assigned, valueDateTime: iso() },
        ),
      },
    ])
    .catch((err) => conflict(err, taken, taken));
  return {
    appointment: appointment as R4.Appointment,
    slot: held,
    patient,
    code,
  };
}

// The patient asked to move ("/reschedule"): the slot is given up and the
// patient waits for the day they named, or any day. An assignment from the
// standby list simply becomes a waiting entry for the new day again — same
// entry, same place in the queue; a direct booking is cancelled and a new
// entry queued. An entry already waiting for that day is not duplicated.
export async function releaseToStandby(
  o: string,
  a: R4.Appointment,
  day: string | null,
) {
  const s = store();
  const patient = await s.read(
    o,
    'Patient',
    refId('Patient', patientRefOf(a) ?? undefined) ?? '',
  );
  if (!patient) throw Error(CHANGED);
  const service = serviceOfAppointment(a);
  let duplicate = false;
  try {
    await alreadyWaiting(o, patient, service, day);
  } catch {
    duplicate = true;
  }
  if (assignedAt(a) && !duplicate) {
    const { requestedPeriod: _dropped, ...rest } = takeOffSlot(a);
    const writes: Write[] = [
      {
        update: withoutExtension(
          {
            ...rest,
            ...(day ? { requestedPeriod: [{ start: day, end: day }] } : {}),
          },
          EXT.assigned,
        ),
      },
    ];
    const slot = await slotOf(o, a);
    if (slot) writes.push({ update: { ...slot, status: 'free' } });
    const [requeued] = await s.transact(o, writes).catch(conflict);
    return { released: a, queued: requeued as R4.Appointment, duplicate };
  }
  // Release and queue together, so the patient is never left with neither.
  const { writes } = await releaseWrites(o, a, 'free');
  if (!duplicate)
    writes.push({
      create: buildWaitlist({ patient, service, day, created: now() }),
    });
  const written = await s.transact(o, writes).catch(conflict);
  return {
    released: written[0] as R4.Appointment,
    queued: duplicate ? null : (written[written.length - 1] as R4.Appointment),
    duplicate,
  };
}

// The patient asked to move to a day. The earliest start of that day on
// the appointment's own schedule — same clinician, same room — that no
// booking holds: a grid time with no Slot, or a Slot left free by a
// cancellation. Null when the day is full (or, today, when the rest of the
// day is). On success the appointment moves onto the new slot with a fresh
// code and goes back to pending — the patient still confirms the new time
// — and the old slot stays on the board as open, as after a cancellation.
export async function rebook(o: string, a: R4.Appointment, day: string) {
  const s = store();
  const current = await slotOf(o, a);
  if (!current) throw Error(CHANGED);
  const schedule = await s.read(
    o,
    'Schedule',
    refId('Schedule', current.schedule.reference) ?? '',
  );
  if (!schedule) throw Error(CHANGED);
  const onDay = new Map<string, R4.Slot>();
  for (const x of await s.search(o, 'Slot', {
    schedule: current.schedule.reference!,
  })) {
    const w = wallTime(x.start);
    if (w.date === day) onDay.set(w.time, x);
  }
  const clock = wallTime(instantAt(now()));
  let pick: { time: string } | null = null;
  for (const time of gridTimes(day)) {
    if (day === clock.date && time <= clock.time) continue;
    const x = onDay.get(time);
    if (!x || (x.status === 'free' && x.id !== current.id)) {
      pick = { time };
      break;
    }
  }
  if (!pick) return null;
  const service = serviceOfAppointment(a);
  const start = instantOf(day, pick.time);
  const held = await holdSlot(
    o,
    { schedule, start, end: plusMinutes(start, SLOT_MINUTES) },
    service,
  );
  // New slot taken, appointment moved, old slot freed: one transaction.
  const [, appointment] = await s
    .transact(o, [
      held.write,
      {
        update: placeOnSlot(a, {
          slot: held.slot,
          schedule,
          service,
          code: id(),
        }),
      },
      { update: { ...current, status: 'free' } },
    ])
    .catch(conflict);
  return { appointment: appointment as R4.Appointment, slot: held.slot };
}
