import type * as R4 from 'fhir/r4';

// The FHIR R4 resources CareQueue stores, and the checks every write passes
// before it reaches the database. The full R4 JSON schema is 2.7 MB and is
// run in the tests (tests/fhir.test.mjs and every workflow test) against
// each resource the code produces; at run time the TypeScript definitions
// catch shape errors at compile time and this file catches the things a type
// cannot — a status outside the R4 value set, a malformed id, a resource type
// the store does not index.

export type Stored =
  | R4.Patient
  | R4.Practitioner
  | R4.Location
  | R4.HealthcareService
  | R4.Consent
  | R4.Schedule
  | R4.Slot
  | R4.Appointment
  | R4.AppointmentResponse
  | R4.Communication;
export type StoredType = Stored['resourceType'];
export type Of<T extends StoredType> = Extract<Stored, { resourceType: T }>;

// Identifier systems, code systems and extensions that are CareQueue's own.
// `.example` is reserved for documentation, which is what a demonstration
// clinic is; a deployment under a real domain would change this one prefix.
export const LOCAL = 'https://carequeue.example/fhir';
export const SYSTEM = {
  // Patient.identifier: the clinic record number shown to staff.
  record: `${LOCAL}/sid/record`,
  // Appointment.identifier: the booking code. Rotated when the slot, patient
  // or address changes, so a reminder sent for the old code cannot stand as
  // confirmation of the new one.
  bookingCode: `${LOCAL}/sid/booking-code`,
  // Communication.identifier: the idempotency key CareQueue chose before
  // sending ("reminder:<appointment>:<code>"), and the id the provider gave
  // back.
  messageKey: `${LOCAL}/sid/message-key`,
  providerMessage: `${LOCAL}/sid/provider-message`,
  // Appointment.serviceType and Slot.serviceType: the clinic's catalogue.
  service: `${LOCAL}/CodeSystem/service`,
  // Communication.category: what a message is for.
  messageCategory: `${LOCAL}/CodeSystem/message-category`,
  // Consent.policy: the demonstration's test-message consent.
  consentPolicy: `${LOCAL}/policy/test-messages`,
};
export const EXT = {
  // On a ContactPoint: which messaging provider the address belongs to.
  provider: `${LOCAL}/StructureDefinition/messaging-provider`,
  // On a Patient: staff notes. Patient has no note element in R4.
  notes: `${LOCAL}/StructureDefinition/patient-notes`,
  // On an Appointment: when it was assigned to its slot from the standby
  // list, or when it was released from a slot back to the list.
  assigned: `${LOCAL}/StructureDefinition/assigned-from-standby`,
  released: `${LOCAL}/StructureDefinition/released-to-standby`,
  // On a Communication: the address it went to or came from, and the
  // provider's own delivery status word, kept verbatim for staff.
  address: `${LOCAL}/StructureDefinition/message-address`,
  delivery: `${LOCAL}/StructureDefinition/delivery-status`,
};

// R4 required-binding value sets for the statuses CareQueue writes. The tests
// check these lists against the enums in the official schema, so a typo here
// fails the build rather than a write in production.
export const CODES = {
  consentStatus: [
    'draft',
    'proposed',
    'active',
    'rejected',
    'inactive',
    'entered-in-error',
  ],
  slotStatus: [
    'busy',
    'free',
    'busy-unavailable',
    'busy-tentative',
    'entered-in-error',
  ],
  appointmentStatus: [
    'proposed',
    'pending',
    'booked',
    'arrived',
    'fulfilled',
    'cancelled',
    'noshow',
    'entered-in-error',
    'checked-in',
    'waitlist',
  ],
  participantStatus: ['accepted', 'declined', 'tentative', 'needs-action'],
  communicationStatus: [
    'preparation',
    'in-progress',
    'not-done',
    'on-hold',
    'stopped',
    'completed',
    'entered-in-error',
    'unknown',
  ],
  contactPointSystem: ['phone', 'fax', 'email', 'pager', 'url', 'sms', 'other'],
} as const;

const ID = /^[A-Za-z0-9\-.]{1,64}$/;

// A name as CareQueue writes it is `text`; one from another system may be
// given and family parts only. Both index and display go through here.
export function humanName(n: R4.HumanName | undefined) {
  if (!n) return '';
  if (n.text) return n.text;
  return [...(n.given ?? []), n.family].filter(Boolean).join(' ');
}

// A FHIR id from a key of CareQueue's own — "reminder:<appointment>:<code>",
// "inbound:<provider sid>". Colons are not allowed in an id; dots are, and
// none of the keys contain one, so the mapping is reversible. Anything else
// out of range is a programming error, not something to paper over.
export function idFrom(key: string) {
  const id = key.replaceAll(':', '.');
  if (!ID.test(id)) throw Error(`Not a usable FHIR id: ${key}`);
  return id;
}

export function reference(type: StoredType, id: string) {
  return `${type}/${id}`;
}
export function refId(type: StoredType, ref: string | undefined) {
  if (!ref?.startsWith(type + '/')) return null;
  return ref.slice(type.length + 1);
}

function code(where: string, value: unknown, allowed: readonly string[]) {
  if (!allowed.includes(value as string))
    throw Error(
      `${where} must be one of ${allowed.join(', ')}; got ${String(value)}`,
    );
}
function present(where: string, value: unknown) {
  if (value === undefined || value === null || value === '')
    throw Error(`${where} is required`);
}
function some(where: string, value: unknown) {
  if (!Array.isArray(value) || value.length === 0)
    throw Error(`${where} needs at least one entry`);
}

// What the store checks on every write: the required elements and coded
// values of R4 for the types CareQueue uses. Not the whole schema — that runs
// in the tests — but enough that a resource with an invented status or a
// missing required element never reaches the database.
export function assertResource(r: Stored) {
  present('resourceType', r.resourceType);
  present('id', r.id);
  if (!ID.test(r.id!)) throw Error(`Malformed id ${r.id}`);
  switch (r.resourceType) {
    case 'Patient':
    case 'Practitioner':
    case 'Location':
    case 'HealthcareService':
      break;
    case 'Consent':
      code('Consent.status', r.status, CODES.consentStatus);
      present('Consent.scope', r.scope);
      some('Consent.category', r.category);
      break;
    case 'Schedule':
      some('Schedule.actor', r.actor);
      break;
    case 'Slot':
      present('Slot.schedule', r.schedule?.reference);
      code('Slot.status', r.status, CODES.slotStatus);
      present('Slot.start', r.start);
      present('Slot.end', r.end);
      break;
    case 'Appointment':
      code('Appointment.status', r.status, CODES.appointmentStatus);
      some('Appointment.participant', r.participant);
      for (const p of r.participant)
        code(
          'Appointment.participant.status',
          p.status,
          CODES.participantStatus,
        );
      break;
    case 'AppointmentResponse':
      present('AppointmentResponse.appointment', r.appointment?.reference);
      code(
        'AppointmentResponse.participantStatus',
        r.participantStatus,
        CODES.participantStatus,
      );
      break;
    case 'Communication':
      code('Communication.status', r.status, CODES.communicationStatus);
      break;
    default:
      throw Error(
        `Unsupported resource type ${String((r as { resourceType?: unknown }).resourceType)}`,
      );
  }
  for (const t of telecoms(r))
    code('ContactPoint.system', t.system, CODES.contactPointSystem);
}

function telecoms(r: Stored): R4.ContactPoint[] {
  const out: R4.ContactPoint[] = [];
  if ('telecom' in r && Array.isArray(r.telecom)) out.push(...r.telecom);
  if (r.resourceType === 'Communication')
    for (const x of r.extension ?? [])
      if (x.url === EXT.address && x.valueContactPoint)
        out.push(x.valueContactPoint);
  return out;
}

// Search parameters, one row per (name, value), extracted when a resource
// is written. Names follow the R4 search parameters where one exists
// (`patient`, `status`, `slot`, `identifier`); the rest are CareQueue's own
// and are named for what they hold. A `unique` row also enforces uniqueness
// of that value within the workspace.
export type IndexRow = { param: string; value: string; unique?: boolean };

// A CodeableConcept is found by `system|code`, by the bare code (any
// system, as FHIR token search allows) and by its text.
function token(c: R4.CodeableConcept | undefined) {
  const out: string[] = [];
  for (const x of c?.coding ?? [])
    if (x.code) out.push(`${x.system ?? ''}|${x.code}`, x.code);
  if (c?.text) out.push(c.text);
  return out;
}
function identifiers(ids: R4.Identifier[] | undefined) {
  return (ids ?? [])
    .filter((i) => i.value)
    .map((i) => ({
      param: 'identifier',
      value: `${i.system ?? ''}|${i.value}`,
    }));
}
function refs(param: string, list: (R4.Reference | undefined)[]) {
  return list
    .filter((x): x is R4.Reference => !!x?.reference)
    .map((x) => ({ param, value: x.reference! }));
}

export function indexOf(r: Stored): IndexRow[] {
  const rows: IndexRow[] = [];
  switch (r.resourceType) {
    case 'Patient':
      rows.push(
        ...identifiers(r.identifier).map((x) => ({ ...x, unique: true })),
      );
      for (const t of r.telecom ?? [])
        if (t.value) rows.push({ param: 'telecom', value: t.value });
      for (const n of r.name ?? [])
        if (humanName(n)) rows.push({ param: 'name', value: humanName(n) });
      break;
    case 'Practitioner':
      for (const n of r.name ?? [])
        if (humanName(n))
          rows.push({ param: 'name', value: humanName(n), unique: true });
      break;
    case 'Location':
    case 'HealthcareService':
      if (r.name) rows.push({ param: 'name', value: r.name, unique: true });
      break;
    case 'Consent':
      rows.push({ param: 'status', value: r.status });
      rows.push(...refs('patient', [r.patient]));
      break;
    case 'Schedule':
      rows.push(...refs('actor', r.actor));
      // One schedule per set of actors: the pair (clinician, location) is
      // found or created by this key.
      rows.push({
        param: 'actors',
        value: r.actor
          .map((a) => a.reference ?? '')
          .sort()
          .join(','),
        unique: true,
      });
      break;
    case 'Slot':
      rows.push(...refs('schedule', [r.schedule]));
      rows.push({ param: 'status', value: r.status });
      rows.push({ param: 'start', value: r.start });
      for (const s of r.serviceType ?? [])
        for (const v of token(s))
          rows.push({ param: 'service-type', value: v });
      // A clinician has one slot at a time in a location.
      rows.push({
        param: 'schedule-start',
        value: `${r.schedule.reference}@${r.start}`,
        unique: true,
      });
      break;
    case 'Appointment':
      rows.push({ param: 'status', value: r.status });
      rows.push(...identifiers(r.identifier));
      rows.push(...refs('slot', r.slot ?? []));
      rows.push(
        ...refs(
          'actor',
          r.participant.map((p) => p.actor),
        ),
      );
      for (const p of r.participant)
        for (const t of ['Patient', 'Practitioner', 'Location'] as const)
          if (p.actor?.reference?.startsWith(t + '/'))
            rows.push({ param: t.toLowerCase(), value: p.actor.reference });
      if (r.start) rows.push({ param: 'date', value: r.start });
      for (const s of r.serviceType ?? [])
        for (const v of token(s))
          rows.push({ param: 'service-type', value: v });
      break;
    case 'AppointmentResponse':
      rows.push(...refs('appointment', [r.appointment]));
      rows.push(...refs('actor', [r.actor]));
      rows.push({ param: 'part-status', value: r.participantStatus });
      break;
    case 'Communication':
      rows.push({ param: 'status', value: r.status });
      rows.push(...identifiers(r.identifier));
      rows.push(...refs('about', r.about ?? []));
      rows.push(...refs('recipient', r.recipient ?? []));
      rows.push(...refs('sender', [r.sender]));
      rows.push(...refs('in-response-to', r.inResponseTo ?? []));
      for (const c of r.category ?? [])
        for (const v of token(c)) rows.push({ param: 'category', value: v });
      for (const x of r.extension ?? [])
        if (x.url === EXT.address && x.valueContactPoint?.value)
          rows.push({ param: 'address', value: x.valueContactPoint.value });
      if (r.sent) rows.push({ param: 'sent', value: r.sent });
      if (r.received) rows.push({ param: 'received', value: r.received });
      break;
  }
  return rows;
}
