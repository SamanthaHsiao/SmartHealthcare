import type * as R4 from 'fhir/r4';
import { field } from '../rules';
import type { Provider } from '../providers';
import { id, now, registered, store, testContact } from '../workspace';
import { Conflict } from './store';
import { reference } from './resources';
import {
  buildConsent,
  buildHealthcareService,
  buildLocation,
  buildPatient,
  buildPractitioner,
  patientAddress,
  patientName,
  revisePatient,
  type Address,
} from './build';

// The people and places of the clinic as FHIR resources: patients with
// their consent, and the clinicians, rooms and services that appointments
// refer to. Practitioner, Location and HealthcareService are found or
// created by name — staff type a name when booking, and the same name means
// the same resource.

// An address as the active provider validates it, tagged with what kind of
// contact point it is.
export function addressFor(p: Provider, value: unknown): Address {
  return { value: p.address(value), system: p.telecom, provider: p.id };
}

function notes(value: unknown) {
  return value ? field(value, 'Notes', 500) : null;
}

export async function createPatient(o: string, p: Provider, data: any) {
  const address = addressFor(p, data.phone);
  await testContact(o, address.value);
  const name = field(data.name, 'Patient name');
  const s = store();
  // Record numbers are short so staff can read them out; on the rare
  // collision the unique index says so and a new one is drawn.
  let patient: R4.Patient | null = null;
  for (let attempt = 0; attempt < 3 && !patient; attempt++) {
    try {
      patient = await s.create(
        o,
        buildPatient({
          record: 'P-' + id().slice(0, 4),
          name,
          address,
          notes: notes(data.notes),
        }),
      );
    } catch (err) {
      if (!(err instanceof Conflict) || attempt === 2) throw err;
    }
  }
  await s.create(o, buildConsent(patient!, now()));
  return patient!;
}

export async function consentOf(o: string, patient: R4.Patient) {
  const [c] = await store().search(o, 'Consent', {
    patient: reference('Patient', patient.id!),
    status: 'active',
  });
  return c ?? null;
}

// Rename, re-address or annotate a patient. A new address re-dates the
// consent: the person at the new address is agreeing afresh. What a changed
// address means for the patient's bookings is the scheduling module's
// business; the caller is told so it can act.
export async function editPatient(o: string, p: Provider, data: any) {
  const s = store();
  const before = await s.read(o, 'Patient', String(data.id ?? ''));
  if (!before) throw Error('Select a patient to edit.');
  const address = addressFor(p, data.phone);
  await testContact(o, address.value);
  const patient = await s.update(
    o,
    revisePatient(before, {
      name: field(data.name, 'Patient name'),
      address,
      notes: notes(data.notes),
    }),
  );
  const addressChanged = address.value !== patientAddress(before);
  if (addressChanged) {
    const consent = await consentOf(o, before);
    if (consent)
      await s.update(o, {
        ...consent,
        dateTime: new Date(now()).toISOString(),
      });
    else await s.create(o, buildConsent(patient, now()));
  }
  return { before, patient, addressChanged };
}

// Remove a patient record. Live appointments and standby entries block it;
// cancelled ones and the consent go with the record. Messages are kept —
// they were really sent, and they are matched by address, not by patient.
export async function deletePatient(o: string, value: unknown) {
  const s = store();
  const patient = await s.read(o, 'Patient', String(value ?? ''));
  if (!patient) throw Error('Select a patient to remove.');
  const ref = reference('Patient', patient.id!);
  const live = await s.search(o, 'Appointment', {
    patient: ref,
    status: ['waitlist', 'pending', 'booked'],
  });
  if (live.length)
    throw Error(
      'This patient still has appointments or standby entries. Remove those first.',
    );
  for (const a of await s.search(o, 'Appointment', { patient: ref })) {
    for (const r of await s.search(o, 'AppointmentResponse', {
      appointment: reference('Appointment', a.id!),
    }))
      await s.remove(o, 'AppointmentResponse', r.id!);
    await s.remove(o, 'Appointment', a.id!);
  }
  for (const c of await s.search(o, 'Consent', { patient: ref }))
    await s.remove(o, 'Consent', c.id!);
  await s.remove(o, 'Patient', patient.id!);
  return patient;
}

// Why a patient cannot be messaged right now, or null when they can. A
// patient can outlive the device that used to reach them — after switching
// provider, for instance — and stays in the list, reported rather than
// silently dropped. Every path that puts a patient on a slot asks this.
export async function unreachable(o: string, patient: R4.Patient) {
  const address = patientAddress(patient);
  if (!address || !(await registered(o, address)))
    return `${patientName(patient)} has no reachable device: ${address ?? 'no address'} is not a registered recipient. Edit the patient to point at one.`;
  if (!(await consentOf(o, patient)))
    return `${patientName(patient)} has no active consent on record.`;
  return null;
}
export async function assertReachable(o: string, patient: R4.Patient) {
  const why = await unreachable(o, patient);
  if (why) throw Error(why);
}
export async function patientOf(o: string, value: unknown) {
  const patient = await store().read(o, 'Patient', String(value ?? ''));
  if (!patient) throw Error('Choose a patient from the patient list.');
  await assertReachable(o, patient);
  return patient;
}

// Find-or-create by name. Two staff booking the same new clinician at once
// both get the one resource: the loser of the race re-reads.
async function byName<
  T extends 'Practitioner' | 'Location' | 'HealthcareService',
>(
  o: string,
  type: T,
  name: string,
  build: () => R4.Practitioner | R4.Location | R4.HealthcareService,
) {
  const s = store();
  const [found] = await s.search(o, type, { name });
  if (found) return found;
  try {
    return (await s.create(o, build() as any)) as typeof found;
  } catch (err) {
    if (err instanceof Conflict) {
      const [again] = await s.search(o, type, { name });
      if (again) return again;
    }
    throw err;
  }
}
export const practitionerOf = (o: string, name: string) =>
  byName(o, 'Practitioner', name, () => buildPractitioner(name));
export const locationOf = (o: string, name: string) =>
  byName(o, 'Location', name, () => buildLocation(name));
export const serviceOf = (o: string, name: string) =>
  byName(o, 'HealthcareService', name, () => buildHealthcareService(name));
