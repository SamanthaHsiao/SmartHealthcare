// Clinic time. Staff enter a day and a wall-clock time in Concepción; FHIR
// wants instants. Both directions go through the clinic's zone, and the
// instants are written with that zone's offset ("2026-09-20T10:00:00-03:00")
// rather than in UTC, so a resource reads as the time the clinic means.
// Chile changes its offset twice a year; the arithmetic below asks the
// platform's time-zone data rather than assuming one.

export const ZONE = 'America/Santiago';
export const SLOT_MINUTES = 30;

const format = new Intl.DateTimeFormat('en-CA', {
  timeZone: ZONE,
  hourCycle: 'h23',
  year: 'numeric',
  month: '2-digit',
  day: '2-digit',
  hour: '2-digit',
  minute: '2-digit',
  second: '2-digit',
});

function wall(utc: number) {
  const p: Record<string, number> = {};
  for (const x of format.formatToParts(new Date(utc)))
    if (x.type !== 'literal') p[x.type] = Number(x.value);
  return p as {
    year: number;
    month: number;
    day: number;
    hour: number;
    minute: number;
    second: number;
  };
}

// Minutes the clinic is ahead of UTC at that instant (negative for Chile).
function offsetAt(utc: number) {
  const w = wall(utc);
  const asUtc = Date.UTC(
    w.year,
    w.month - 1,
    w.day,
    w.hour,
    w.minute,
    w.second,
  );
  return Math.round((asUtc - utc) / 60000);
}

const two = (n: number) => String(n).padStart(2, '0');

// An R4 instant for a UTC millisecond count, in clinic time.
export function instantAt(utc: number) {
  const w = wall(utc);
  const off = offsetAt(utc);
  const sign = off < 0 ? '-' : '+';
  const abs = Math.abs(off);
  return `${w.year}-${two(w.month)}-${two(w.day)}T${two(w.hour)}:${two(w.minute)}:${two(w.second)}${sign}${two(Math.floor(abs / 60))}:${two(abs % 60)}`;
}

// The instant of a clinic day and time. `date` is YYYY-MM-DD, `time` HH:MM,
// both already validated.
export function instantOf(date: string, time: string) {
  const [y, mo, d] = date.split('-').map(Number);
  const [h, mi] = time.split(':').map(Number);
  const guess = Date.UTC(y, mo - 1, d, h, mi);
  // The offset in force at that wall time: try once, then correct for a
  // change of offset between the guess and the answer.
  let utc = guess - offsetAt(guess) * 60000;
  utc = guess - offsetAt(utc) * 60000;
  return instantAt(utc);
}

export function plusMinutes(instant: string, minutes: number) {
  return instantAt(Date.parse(instant) + minutes * 60000);
}

// The clinic day and time an instant falls on, as staff entered them.
export function wallTime(instant: string) {
  const w = wall(Date.parse(instant));
  return {
    date: `${w.year}-${two(w.month)}-${two(w.day)}`,
    time: `${two(w.hour)}:${two(w.minute)}`,
  };
}
