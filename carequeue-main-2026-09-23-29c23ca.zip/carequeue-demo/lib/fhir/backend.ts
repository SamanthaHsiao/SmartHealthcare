import { field } from '../rules';
import { provider, providers, type Provider } from '../providers';
import {
  all,
  connection,
  id,
  now,
  one,
  q,
  seal,
  secureStorage,
  store,
} from '../workspace';
import { patientName } from './build';
import { createPatient, deletePatient, editPatient } from './registry';
import {
  assign,
  book,
  cancelAppointment,
  deleteAppointment,
  deleteSlot,
  editAppointment,
  editQueued,
  queue,
  readdress,
  removeQueued,
} from './scheduling';
import {
  notifyAssignment,
  recentMessages,
  recordConfirmation,
  remind,
  sync,
} from './messaging';
export { owner } from '../workspace';

// The FHIR-backed workspace: what the browser reads (`state`) and what it
// may do (`action`). Clinical data comes from the resource store; the
// provider connection and the registered recipients come from the
// operational tables, because they describe the messaging pipeline rather
// than anyone's care. This module replaces lib/backend.ts feature by
// feature; until it has all of them the app keeps using the old one.

async function overContactLimit(o: string, p: Provider, address: string) {
  if (p.maxContacts === null) return false;
  // Re-registering an address already on file is not a new recipient.
  if (
    await one('SELECT id FROM contacts WHERE owner=? AND phone=?', o, address)
  )
    return false;
  const count = await one('SELECT COUNT(*) n FROM contacts WHERE owner=?', o);
  return count.n >= p.maxContacts;
}

export async function state(o: string) {
  const s = store();
  const patients = await s.search(o, 'Patient');
  patients.sort((a, b) => patientName(a).localeCompare(patientName(b)));
  return {
    Patient: patients,
    Consent: await s.search(o, 'Consent'),
    Practitioner: await s.search(o, 'Practitioner'),
    Location: await s.search(o, 'Location'),
    HealthcareService: await s.search(o, 'HealthcareService'),
    Schedule: await s.search(o, 'Schedule'),
    Slot: (await s.search(o, 'Slot')).sort((a, b) =>
      a.start.localeCompare(b.start),
    ),
    Appointment: (await s.search(o, 'Appointment')).sort(
      (a, b) =>
        (a.start ?? '').localeCompare(b.start ?? '') ||
        (a.created ?? '').localeCompare(b.created ?? ''),
    ),
    AppointmentResponse: await s.search(o, 'AppointmentResponse'),
    Communication: await recentMessages(o),
    contacts: await all(
      'SELECT * FROM contacts WHERE owner=? ORDER BY name',
      o,
    ),
    connection: await one(
      'SELECT provider,sender,synced,linkCode FROM connections WHERE owner=?',
      o,
    ),
    providers: Object.values(providers).map((p) => ({
      id: p.id,
      label: p.label,
      fixedTemplate: p.fixedTemplate,
      linkedContacts: p.linkedContacts,
    })),
    secureStorage: secureStorage(),
  };
}

async function activeProvider(o: string) {
  const c = await connection(o);
  return provider(c.provider);
}

export async function action(o: string, data: any) {
  switch (data.action) {
    case 'connect': {
      const p = provider(data.provider);
      const c = { ...p.credentials(data), provider: p.id };
      const sender = await p.verify(c);
      const secret = await seal(o, c);
      // Switching provider invalidates contacts addressed for the old one.
      const previous = await one(
        'SELECT provider FROM connections WHERE owner=?',
        o,
      );
      await q(
        'INSERT INTO connections(owner,provider,secret,sender,since,syncLock,synced,cursor,linkCode,linkName) VALUES(?,?,?,?,?,0,0,NULL,NULL,NULL) ON CONFLICT(owner) DO UPDATE SET provider=excluded.provider,secret=excluded.secret,sender=excluded.sender,since=excluded.since,syncLock=0,synced=0,cursor=NULL,linkCode=NULL,linkName=NULL',
        o,
        p.id,
        secret,
        sender,
        now(),
      ).run();
      if (previous && previous.provider !== p.id)
        await q('DELETE FROM contacts WHERE owner=?', o).run();
      return {
        message: p.linkedContacts
          ? `Connected to ${sender}. Generate a link code next, then start the bot from the test device.`
          : 'Credentials verified and saved securely. Register your test phones next.',
      };
    }
    case 'link': {
      const c = await connection(o);
      const p = provider(c.provider);
      if (!p.linkedContacts)
        throw Error(
          'This provider registers recipients by address, not by link code.',
        );
      const code = id().slice(0, 6);
      await q(
        'UPDATE connections SET linkCode=?,linkName=? WHERE owner=?',
        code,
        field(data.name, 'Contact label'),
        o,
      ).run();
      return {
        code,
        message: `Send "/start ${code}" to ${c.sender} from the test device, then sync.`,
      };
    }
    case 'contact': {
      if (data.consent !== true)
        throw Error('Confirm that this team member agreed to test messages.');
      const c = await connection(o);
      const p = provider(c.provider);
      if (p.linkedContacts)
        throw Error(
          'Use a link code for this provider: the contact starts the bot themselves.',
        );
      const phone = p.address(data.phone),
        name = field(data.name, 'Test contact name');
      if (await overContactLimit(o, p, phone))
        throw Error(
          `${p.label} registers at most ${p.maxContacts} recipient${p.maxContacts === 1 ? '' : 's'} here. Use the same one for fictional standby patients.`,
        );
      await q(
        'INSERT INTO contacts(id,owner,name,phone,consent) VALUES(?,?,?,?,1) ON CONFLICT(owner,phone) DO UPDATE SET name=excluded.name,consent=1',
        id(),
        o,
        name,
        phone,
      ).run();
      return { message: 'Recipient registered.' };
    }
    case 'patient': {
      await createPatient(o, await activeProvider(o), data);
      return { message: 'Patient record created.' };
    }
    case 'patientEdit': {
      const { patient, addressChanged } = await editPatient(
        o,
        await activeProvider(o),
        data,
      );
      if (addressChanged) await readdress(o, patient);
      return {
        message: addressChanged
          ? 'Patient updated. The delivery address changed, so send a new reminder before recording a confirmation.'
          : 'Patient updated.',
      };
    }
    case 'patientDelete': {
      await deletePatient(o, data.id);
      return { message: 'Patient record removed.' };
    }
    case 'appointment': {
      await book(o, data);
      return { message: 'Appointment saved. No message sent yet.' };
    }
    case 'update': {
      const { moved } = await editAppointment(o, data);
      return {
        message: moved
          ? 'Appointment updated. The slot changed, so send a new template before recording a confirmation. No message was sent.'
          : 'Appointment updated. No message was sent.',
      };
    }
    case 'cancel': {
      const { requeued } = await cancelAppointment(o, data.id);
      return {
        message: requeued
          ? 'Staff canceled the demo appointment and released the slot. The standby entry is back on the list as released. No message was sent.'
          : 'Staff canceled the demo appointment and released the slot. No message was sent.',
      };
    }
    case 'appointmentDelete': {
      const { kept } = await deleteAppointment(o, data.id);
      return {
        message: kept
          ? 'Appointment deleted. The standby entry it was assigned from is back on the list as released; its message history is kept. No message was sent.'
          : 'Appointment deleted. Its message history is kept. No message was sent.',
      };
    }
    case 'slotDelete': {
      await deleteSlot(o, data.id);
      return { message: 'Open slot deleted. No message was sent.' };
    }
    case 'standby': {
      await queue(o, data);
      return { message: 'Patient added to the standby list.' };
    }
    case 'standbyEdit': {
      const { requeued } = await editQueued(o, data);
      return {
        message: requeued
          ? 'Standby entry updated and back on the list. No message was sent.'
          : 'Standby entry updated. No message was sent.',
      };
    }
    case 'standbyDelete': {
      await removeQueued(o, data.id);
      return { message: 'Standby entry removed. No message was sent.' };
    }
    case 'invite': {
      const { appointment, patient } = await assign(o, data.id, data.candidate);
      // The rotated code gives this booking a fresh reminder key, so the
      // notification cannot collide with anything sent for the slot before.
      const told = await notifyAssignment(o, appointment, patient);
      return {
        message: told.sent
          ? 'Standby patient assigned and notified of the new slot. A C reply still needs staff review; assignment is not patient acceptance.'
          : 'error' in told
            ? 'Standby patient assigned, but notifying them failed: ' +
              told.error +
              ' The assignment stands; see message history.'
            : 'Standby patient assigned by staff. This provider sends a fixed template only, so send it from the appointment panel once you have acknowledged the sample date. Assignment is not patient acceptance.',
      };
    }
    case 'remind': {
      const { followUp, fixedTemplate } = await remind(o, data);
      return {
        message: followUp
          ? 'Follow-up reminder sent.'
          : fixedTemplate
            ? 'Reminder submitted. See message history for delivery status.'
            : 'Reminder sent with this appointment’s real date and time.',
      };
    }
    case 'confirm': {
      await recordConfirmation(o, data);
      return {
        message:
          'Staff recorded the confirmation. No WhatsApp confirmation message was sent.',
      };
    }
    case 'sync':
      return sync(o);
    default:
      throw Error('Unknown action.');
  }
}
