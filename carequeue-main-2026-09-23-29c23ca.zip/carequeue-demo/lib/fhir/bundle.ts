import type * as R4 from 'fhir/r4';
import { id, now, store } from '../workspace';
import { Conflict, type Write } from './store';
import {
  assertResource,
  humanName,
  LOCAL,
  reference,
  SYSTEM,
  type Stored,
  type StoredType,
} from './resources';
import { isLive, patientRefOf, serviceName } from './build';
import { plusMinutes, SLOT_MINUTES } from './time';
import { holdSlot, scheduleOf } from './scheduling';
import { violations } from './validate';

// The workspace as one FHIR Bundle, out and in. Export is the clinical and
// scheduling resources as a `collection`; messages stay home, they are the
// messaging pipeline's records. Import takes any R4 Bundle — another
// system's, or one of ours — and adds what this system can use: every
// resource gets a new id and the Bundle's own references are rewritten to
// match, so nothing imported can collide with, or be mistaken for, what was
// already here. Types this system does not hold are skipped and reported;
// so is anything that fails the R4 checks every write goes through.

export const EXPORTED: StoredType[] = [
  'Patient',
  'Consent',
  'Practitioner',
  'Location',
  'HealthcareService',
  'Schedule',
  'Slot',
  'Appointment',
  'AppointmentResponse',
];

export async function exportBundle(o: string): Promise<R4.Bundle> {
  const s = store();
  const entry: R4.BundleEntry[] = [];
  for (const type of EXPORTED)
    for (const resource of await s.search(o, type))
      entry.push({ fullUrl: `${LOCAL}/${type}/${resource.id}`, resource });
  return {
    resourceType: 'Bundle',
    id: crypto.randomUUID(),
    identifier: { system: `${LOCAL}/sid/export`, value: crypto.randomUUID() },
    type: 'collection',
    timestamp: new Date(now()).toISOString(),
    entry,
  };
}

// ---------------------------------------------------------------- import

export type ImportReport = {
  // Stored under a new id.
  imported: Partial<Record<StoredType, number>>;
  // Taken to be a record already here — a clinician, room or service of
  // the same name, a patient with the same identifier — and referred to.
  matched: Partial<Record<StoredType, number>>;
  skipped: { type: string; id: string | null; reason: string }[];
};

type Entry = {
  resource: Record<string, any>;
  // The entry's fullUrl, if it has one.
  url: string | null;
  // For a RESTful fullUrl, the server base the entry's relative references
  // resolve against.
  base: string | null;
  // The resource's own Type/id, if it has an id.
  local: string | null;
};

const SUPPORTED = new Set<string>(EXPORTED);
const RESTFUL = /^(https?:\/\/.+)\/([A-Za-z]+)\/([A-Za-z0-9\-.]{1,64})$/;
const ABSOLUTE = /^[a-z][a-z0-9+.-]*:/i;

function entryOf(raw: any): Entry {
  const r = raw.resource;
  const url = typeof raw.fullUrl === 'string' ? raw.fullUrl : null;
  const m = url?.match(RESTFUL);
  return {
    resource: r,
    url,
    base: m ? m[1] : null,
    local: typeof r.id === 'string' ? `${r.resourceType}/${r.id}` : null,
  };
}

// Where each entry ended up here, by the names the Bundle's own references
// use for it. Resolution follows the Bundle rules: an absolute reference —
// a URL or a urn — must match an entry's fullUrl exactly; a relative one
// (Type/id) resolves against the referring entry's server base when it has
// one, and otherwise against the resource ids in the Bundle. Nothing is
// matched by the tail of a URL to some other server, and a reference to a
// contained resource (#…) is not followed.
class Targets {
  private byUrl = new Map<string, string>();
  private byLocal = new Map<string, string>();
  set(e: Entry, ref: string) {
    if (e.url) this.byUrl.set(e.url, ref);
    if (e.local) this.byLocal.set(e.local, ref);
  }
  resolve(ref: string, from: Entry): string | null {
    if (ref.startsWith('#')) return null;
    if (ABSOLUTE.test(ref)) return this.byUrl.get(ref) ?? null;
    const rel = ref.replace(/\/_history\/.*$/, '');
    // A known server base is authoritative. Falling back to Type/id here
    // could attach this entry to another hospital's patient with that id.
    if (from.base) return this.byUrl.get(`${from.base}/${rel}`) ?? null;
    return this.byLocal.get(rel) ?? null;
  }
}

// A copy of the value with every reference either rewritten or removed. A
// Reference object whose target is gone is dropped with the array element
// or property that held it; the per-type steps then decide whether what is
// left is still a resource this system can keep.
function rewrite(value: any, from: Entry, targets: Targets): any {
  if (Array.isArray(value))
    return value
      .map((x) => rewrite(x, from, targets))
      .filter((x) => x !== undefined && x !== null);
  if (value && typeof value === 'object') {
    if (typeof value.reference === 'string') {
      const target = targets.resolve(value.reference, from);
      if (!target) return null;
      const { identifier: _dropped, ...rest } = value;
      return { ...rest, reference: target };
    }
    const out: Record<string, any> = {};
    for (const [k, v] of Object.entries(value)) {
      const w = rewrite(v, from, targets);
      if (w !== null && w !== undefined) out[k] = w;
    }
    return out;
  }
  return value;
}

// An entry's resource as this system will hold it: another server's id,
// version and narrative do not come along, contained resources are not
// supported, and references are rewritten or dropped.
function incoming(e: Entry, targets: Targets) {
  const {
    id: _id,
    meta: _meta,
    text: _text,
    contained: _c,
    ...rest
  } = e.resource;
  return rewrite(rest, e, targets);
}

export async function importBundle(
  o: string,
  input: unknown,
): Promise<ImportReport> {
  const bundle = input as any;
  if (
    !bundle ||
    typeof bundle !== 'object' ||
    bundle.resourceType !== 'Bundle' ||
    !Array.isArray(bundle.entry)
  )
    throw Error(
      'Upload a FHIR Bundle: a JSON object with resourceType "Bundle" and an entry list.',
    );
  const s = store();
  const report: ImportReport = { imported: {}, matched: {}, skipped: [] };
  const targets = new Targets();
  const skip = (e: Entry, reason: string) =>
    report.skipped.push({
      type: String(e.resource.resourceType),
      id: typeof e.resource.id === 'string' ? e.resource.id : null,
      reason,
    });
  const counted = (type: StoredType) => {
    report.imported[type] = (report.imported[type] ?? 0) + 1;
  };
  const matched = (type: StoredType) => {
    report.matched[type] = (report.matched[type] ?? 0) + 1;
  };
  // Store one resource under a fresh id and remember what it was called.
  // Store one resource under a fresh id — together with any writes it
  // depends on, such as the slot it holds — and remember what it was
  // called.
  const keep = async (e: Entry, resource: Stored, along: Write[] = []) => {
    const r = { ...resource, id: crypto.randomUUID() };
    // The R4 schema, on what will actually be stored — after references
    // were rewritten and this system's own elements added — so an upload
    // cannot bring in a malformed date, a string where a boolean goes, or
    // an element R4 does not have.
    const bad = violations(r, 4);
    if (bad.length)
      throw Error(
        bad
          .slice(0, 3)
          .map((v) => (v.path ? `${v.path} ${v.message}` : v.message))
          .join('; ') + (bad.length > 3 ? '; …' : ''),
      );
    assertResource(r);
    const written = await s.transact(o, [...along, { create: r }]);
    const stored = written[written.length - 1] as Stored;
    targets.set(e, reference(stored.resourceType, stored.id!));
    counted(stored.resourceType);
    return stored;
  };
  // Point every way of naming an entry at a resource already here.
  const alias = (e: Entry, ref: string, type: StoredType) => {
    targets.set(e, ref);
    matched(type);
  };

  const byType = new Map<string, Entry[]>();
  for (const raw of bundle.entry) {
    const r = raw?.resource;
    if (!r || typeof r !== 'object' || typeof r.resourceType !== 'string')
      continue;
    const e = entryOf(raw);
    if (!SUPPORTED.has(r.resourceType)) {
      skip(e, 'not a resource type this system holds');
      continue;
    }
    byType.set(r.resourceType, [...(byType.get(r.resourceType) ?? []), e]);
  }
  const of = (type: string) => byType.get(type) ?? [];
  const attempt = async (e: Entry, fn: () => Promise<void>) => {
    try {
      await fn();
    } catch (err) {
      skip(
        e,
        err instanceof Conflict
          ? 'collides with a record already here'
          : String((err as Error)?.message ?? err),
      );
    }
  };

  // People and places first, so what refers to them can be rewritten. A
  // clinician, room or service with the same name as one already here is
  // taken to be the same one.
  for (const e of of('Practitioner'))
    await attempt(e, async () => {
      const name = humanName(e.resource.name?.[0]);
      if (!name) throw Error('has no name');
      const [found] = await s.search(o, 'Practitioner', { name });
      if (found)
        return alias(e, reference('Practitioner', found.id!), 'Practitioner');
      const r = incoming(e, targets) as R4.Practitioner;
      r.name = [{ ...r.name?.[0], text: name }, ...(r.name?.slice(1) ?? [])];
      await keep(e, r);
    });
  for (const e of of('Location'))
    await attempt(e, async () => {
      const name = String(e.resource.name ?? '').trim();
      if (!name) throw Error('has no name');
      const [found] = await s.search(o, 'Location', { name });
      if (found) return alias(e, reference('Location', found.id!), 'Location');
      await keep(e, incoming(e, targets) as R4.Location);
    });
  for (const e of of('HealthcareService'))
    await attempt(e, async () => {
      const name =
        String(e.resource.name ?? '').trim() ||
        serviceName(e.resource.type?.[0]);
      if (!name) throw Error('has no name');
      const [found] = await s.search(o, 'HealthcareService', { name });
      if (found)
        return alias(
          e,
          reference('HealthcareService', found.id!),
          'HealthcareService',
        );
      await keep(e, {
        ...(incoming(e, targets) as R4.HealthcareService),
        name,
      });
    });

  // A patient with an identifier already on record here is that patient.
  // Otherwise patients keep everything they came with; the name gets a
  // `text` if it had only parts, and a clinic record number is added if
  // there is no identifier at all.
  for (const e of of('Patient'))
    await attempt(e, async () => {
      const r = incoming(e, targets) as R4.Patient;
      for (const i of r.identifier ?? []) {
        if (!i.value) continue;
        const [found] = await s.search(o, 'Patient', {
          identifier: `${i.system ?? ''}|${i.value}`,
        });
        if (found) return alias(e, reference('Patient', found.id!), 'Patient');
      }
      const name = humanName(r.name?.[0]);
      if (!name) throw Error('has no name');
      r.name = [{ ...r.name?.[0], text: name }, ...(r.name?.slice(1) ?? [])];
      if (!r.identifier?.some((i) => i.value))
        r.identifier = [
          ...(r.identifier ?? []),
          { system: SYSTEM.record, value: 'P-' + id().slice(0, 4) },
        ];
      await keep(e, r);
    });
  for (const e of of('Consent'))
    await attempt(e, async () => {
      const r = incoming(e, targets) as R4.Consent;
      if (!r.patient?.reference)
        throw Error('its patient is not in the bundle');
      await keep(e, r);
    });

  // Schedules resolve to this system's one-per-clinician-and-room; slots
  // come in free, and are taken by the appointments that name them.
  for (const e of of('Schedule'))
    await attempt(e, async () => {
      const r = incoming(e, targets) as R4.Schedule;
      const actors = r.actor ?? [];
      const practitioner = (await s.resolve(
        o,
        actors.find((a) => a.reference?.startsWith('Practitioner/'))?.reference,
      )) as R4.Practitioner | null;
      const location = (await s.resolve(
        o,
        actors.find((a) => a.reference?.startsWith('Location/'))?.reference,
      )) as R4.Location | null;
      if (!practitioner || !location)
        throw Error('needs a clinician and a room that are in the bundle');
      const key = [
        reference('Practitioner', practitioner.id!),
        reference('Location', location.id!),
      ]
        .sort()
        .join(',');
      const [found] = await s.search(o, 'Schedule', { actors: key });
      if (found) return alias(e, reference('Schedule', found.id!), 'Schedule');
      const schedule = await scheduleOf(o, practitioner, location);
      targets.set(e, reference('Schedule', schedule.id!));
      counted('Schedule');
    });
  // A slot comes in free — busy is what an appointment makes it, below —
  // unless it was blocked outright (busy-unavailable, busy-tentative).
  for (const e of of('Slot'))
    await attempt(e, async () => {
      const r = incoming(e, targets) as R4.Slot;
      if (!r.schedule?.reference)
        throw Error('its schedule is not in the bundle');
      if (!r.start) throw Error('has no start');
      await keep(e, {
        ...r,
        status: r.status === 'busy' ? 'free' : r.status,
        end: r.end ?? plusMinutes(r.start, SLOT_MINUTES),
      });
    });

  // A live appointment must hold a slot with a clinician in a room, as
  // every booking here does: the slot it named in the bundle, taken as it
  // is used so a second appointment naming the same slot is refused, or
  // one held on the clinician's schedule at its start. Other statuses come
  // in as history, and a waitlist entry as a standby entry. Each gets a
  // booking code of this system's own.
  for (const e of of('Appointment'))
    await attempt(e, async () => {
      const r = incoming(e, targets) as R4.Appointment;
      r.participant = (r.participant ?? []).filter((p) => p.actor?.reference);
      const patient = patientRefOf(r);
      if (!patient) throw Error('its patient is not in the bundle');
      if (r.status === 'waitlist') {
        // The standby list's rule: not twice for one service on one day.
        const day = r.requestedPeriod?.[0]?.start?.slice(0, 10) ?? null;
        const service = serviceName(r.serviceType?.[0]);
        const waiting = await s.search(o, 'Appointment', {
          patient,
          status: 'waitlist',
        });
        if (
          waiting.some(
            (w) =>
              serviceName(w.serviceType?.[0]) === service &&
              (w.requestedPeriod?.[0]?.start?.slice(0, 10) ?? null) === day,
          )
        )
          throw Error('is already waiting for that service on that day');
      }
      const live = isLive(r);
      const along: Write[] = [];
      if (live) {
        if (!r.start) throw Error('is live but has no start');
        r.end = r.end ?? plusMinutes(r.start, SLOT_MINUTES);
        const named = (await s.resolve(
          o,
          r.slot?.[0]?.reference,
        )) as R4.Slot | null;
        if (named) {
          if (named.status !== 'free')
            throw Error('names a slot another booking already holds');
          const held: R4.Slot = {
            ...named,
            status: 'busy',
            ...(named.serviceType?.length || !r.serviceType?.length
              ? {}
              : { serviceType: r.serviceType }),
          };
          along.push({ update: held });
          r.slot = [{ reference: reference('Slot', held.id!) }];
          r.start = held.start;
          r.end = held.end;
        } else {
          const practitioner = (await s.resolve(
            o,
            r.participant.find((p) =>
              p.actor?.reference?.startsWith('Practitioner/'),
            )?.actor?.reference,
          )) as R4.Practitioner | null;
          const location = (await s.resolve(
            o,
            r.participant.find((p) =>
              p.actor?.reference?.startsWith('Location/'),
            )?.actor?.reference,
          )) as R4.Location | null;
          if (!practitioner || !location)
            throw Error(
              'is live but names no clinician and room in the bundle',
            );
          const schedule = await scheduleOf(o, practitioner, location);
          const hold = await holdSlot(
            o,
            { schedule, start: r.start, end: r.end },
            serviceName(r.serviceType?.[0]) || 'Sin especificar',
          );
          along.push(hold.write);
          r.slot = [{ reference: reference('Slot', hold.slot.id!) }];
        }
      } else if (r.slot?.length === 0) delete r.slot;
      if (!r.serviceType?.length) r.serviceType = [{ text: 'Sin especificar' }];
      // A booking code of this system's own, replacing one from a
      // CareQueue export so the reminder keys start afresh.
      r.identifier = [
        ...(r.identifier ?? []).filter((i) => i.system !== SYSTEM.bookingCode),
        { system: SYSTEM.bookingCode, value: id() },
      ];
      await keep(e, r, along);
    });
  for (const e of of('AppointmentResponse'))
    await attempt(e, async () => {
      const r = incoming(e, targets) as R4.AppointmentResponse;
      if (!r.appointment?.reference)
        throw Error('its appointment is not in the bundle');
      await keep(e, r);
    });
  return report;
}
