// The centre's fixed timetable: which days it sees patients, from when to
// when, in slots of how many minutes. One table for the whole centre, as
// decided for the demonstration; a per-clinician roster would replace the
// constants with a setting. It decides three things: which times staff may
// book, what the booking form shows as taken or free for a clinician's day,
// and whether a day is "full" when a patient asks to move to it.
//
// Pure functions over clinic-day strings (YYYY-MM-DD) and wall times
// (HH:MM); safe in the browser and on the server alike.

export const TIMETABLE = {
  // ISO weekdays, Monday = 1.
  days: [1, 2, 3, 4, 5],
  open: '08:00',
  // The last slot starts one step before this.
  close: '17:00',
  step: 30,
};

const weekday = (date: string) => {
  const d = new Date(date + 'T12:00:00Z').getUTCDay();
  return d === 0 ? 7 : d;
};
const minutes = (time: string) => {
  const [h, m] = time.split(':').map(Number);
  return h * 60 + m;
};
const two = (n: number) => String(n).padStart(2, '0');
const label = (min: number) => `${two(Math.floor(min / 60))}:${two(min % 60)}`;

export function isClinicDay(date: string) {
  return TIMETABLE.days.includes(weekday(date));
}

// Every slot start of a clinic day, in order; none on a closed day.
export function gridTimes(date: string): string[] {
  if (!isClinicDay(date)) return [];
  const out: string[] = [];
  for (
    let t = minutes(TIMETABLE.open);
    t < minutes(TIMETABLE.close);
    t += TIMETABLE.step
  )
    out.push(label(t));
  return out;
}

export function onGrid(time: string) {
  const t = minutes(time);
  return (
    (t - minutes(TIMETABLE.open)) % TIMETABLE.step === 0 &&
    t >= minutes(TIMETABLE.open) &&
    t < minutes(TIMETABLE.close)
  );
}

export const DAY_NAMES = ['', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
export function hoursLabel() {
  const days = TIMETABLE.days;
  const span =
    days.length > 2 && days.every((d, i) => i === 0 || d === days[i - 1] + 1)
      ? `${DAY_NAMES[days[0]]}–${DAY_NAMES[days[days.length - 1]]}`
      : days.map((d) => DAY_NAMES[d]).join(', ');
  return `${span} ${TIMETABLE.open}–${TIMETABLE.close}`;
}

// A time staff may book: on the grid, within hours, on a clinic day.
export function validClinicSlot(date: string, time: string) {
  if (!isClinicDay(date))
    throw Error(
      `The centre does not see patients on that day. It is open ${hoursLabel()}.`,
    );
  if (!onGrid(time))
    throw Error(
      `Choose a slot start on the timetable: every ${TIMETABLE.step} minutes from ${TIMETABLE.open}, last at ${label(minutes(TIMETABLE.close) - TIMETABLE.step)}.`,
    );
}
