// The health centre's programmes and the services booked under them, as the
// clinic lists them. Kept in Spanish on purpose: these are the names staff and
// patients use, and a reminder quotes the service verbatim.
//
// The catalogue drives the Service menu when booking or queueing. The server
// still accepts any non-empty service, so records that predate the menu (or a
// service added on the fly) keep working; the edit form shows such a value
// under "Currently on this record" so it can be kept or replaced.
export const programs: { name: string; services: string[] }[] = [
  {
    name: 'Programa de la Mujer',
    services: [
      'Consulta ginecológica',
      'Climaterio',
      'Regulación de fecundidad',
      'Control prenatal',
      'PAP',
      'Test de VIH',
    ],
  },
  {
    name: 'Programa Infantil y Adolescente',
    services: [
      'Controles de niño sano',
      'Control adolescente',
      'Sala estimulación',
    ],
  },
  {
    name: 'Programa del Adulto y Adulto Mayor',
    services: [
      'Exámenes preventivos del adulto',
      'Controles crónicos',
      'Control integral',
      'Evaluación funcional del adulto mayor',
    ],
  },
  {
    name: 'Programa de Salud Mental',
    services: [
      'Ingresos y controles de salud mental',
      'Atención por consumo problemático (OH y drogas)',
    ],
  },
  {
    name: 'Programa Odontológico',
    services: ['Embarazadas', 'Atenciones a niños y adultos', 'Dental'],
  },
];

export const services: string[] = programs.flatMap((p) => p.services);
