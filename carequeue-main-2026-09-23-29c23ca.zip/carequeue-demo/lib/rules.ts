export function normalizePhone(value: unknown) {
  const p = String(value ?? '').replace(/[\s()-]/g, '');
  if (!/^\+[1-9]\d{7,14}$/.test(p))
    throw Error(
      'Enter an international phone number, including + and country code.',
    );
  return p;
}
export function field(value: unknown, label: string, max = 100) {
  const s = String(value ?? '').trim();
  if (!s || s.length > max)
    throw Error(`${label} must contain 1–${max} characters.`);
  return s;
}
export function parseReply(body: string) {
  const m = body
    .trim()
    .toUpperCase()
    .match(/^(CONFIRM|CANCEL|ACCEPT|DECLINE)\s+([A-F0-9]{8})$/);
  return m ? { action: m[1], code: m[2] } : null;
}
export function validDate(date: string) {
  if (
    !/^\d{4}-\d{2}-\d{2}$/.test(date) ||
    Number.isNaN(Date.parse(date)) ||
    new Date(date + 'T12:00:00Z').toISOString().slice(0, 10) !== date
  )
    throw Error('Choose a valid date.');
  const today = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'America/Santiago',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(new Date());
  if (date < today) throw Error('Choose today or a future date.');
}
export function validSlot(date: string, time: string) {
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(time))
    throw Error('Choose a valid appointment date and time.');
  validDate(date);
}
// How standby candidates are ordered when a slot is being filled. Fit first:
// waiting for this slot's day, or for any day. Then first come, first served.
// Deliberately not attendance history — in a public clinic that would push the
// least-resourced patients to the back; staff see history as context instead.
export function standbyRank(slotDate: string | null) {
  const fit = (w: { date?: string | null }) =>
    !w.date || w.date === slotDate ? 0 : 1;
  return (
    a: { date?: string | null; created?: number },
    b: { date?: string | null; created?: number },
  ) => fit(a) - fit(b) || (a.created ?? 0) - (b.created ?? 0);
}
// The confirmation command. "/confirm@botname" is how Telegram spells it in
// a group. A bare "C" is deliberately not this: Twilio's fixed template tells
// patients to reply C, and that path stays staff-reviewed.
export function isConfirmCommand(text: string) {
  return /^\/confirm(?:@\w+)?\s*$/i.test(text.trim());
}
// The reschedule command, with whatever the patient wrote after it: a day,
// "cualquier día", or nothing. "/reschedule@botname" is the group spelling.
export function parseRescheduleCommand(text: string) {
  const m = text.trim().match(/^\/reschedule(?:@\w+)?(?:\s+(.+))?$/i);
  return m ? { arg: (m[1] ?? '').trim() || null } : null;
}
export function todayInSantiago() {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'America/Santiago',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(new Date());
}
// A day as a Chilean patient types it: 25/09, 25-09, 25/09/2026, 2026-09-25,
// or "cualquier día". Day/month without a year means the next such date.
// Returns {date} for a usable future day, {any:true} for any day, or null.
export function parseRequestedDay(
  text: string,
  today = todayInSantiago(),
): { date: string } | { any: true } | null {
  const t = text.trim().toLowerCase();
  if (/^cualquier(a|\s+d[ií]a)?$/.test(t)) return { any: true };
  let date: string | null = null;
  let m = t.match(/^(\d{1,2})[\/.-](\d{1,2})(?:[\/.-](\d{2}|\d{4}))?$/);
  if (m) {
    const d = m[1].padStart(2, '0');
    const mo = m[2].padStart(2, '0');
    let y = m[3] ? (m[3].length === 2 ? '20' + m[3] : m[3]) : today.slice(0, 4);
    date = `${y}-${mo}-${d}`;
    if (!m[3] && date < today) date = `${Number(y) + 1}-${mo}-${d}`;
  } else if ((m = t.match(/^(\d{4})-(\d{2})-(\d{2})$/))) date = t;
  if (!date) return null;
  try {
    validDate(date);
  } catch {
    return null;
  }
  return { date };
}
export function mayReply(
  phone: string,
  target: string,
  created: number,
  sent: number,
) {
  return phone === target && sent >= created;
}
