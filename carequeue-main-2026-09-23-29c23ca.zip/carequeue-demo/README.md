# CareQueue · Concepción — Free trial demonstration

Pick one messaging provider per workspace in setup.

- **Twilio WhatsApp (free trial)**: fixed Appointment Reminders template with a sample date, one verified phone.
- **Telegram bot**: free-text reminders carrying the real appointment details, no template approval. Create a bot with @BotFather, generate a link code in step 03, and send `/start <code>` to the bot from the test device.
- **Several patients as separate chats, from one Telegram account**: make one group per patient, add the bot to each, and link each group with its own code (`/start@yourbot <code>` inside the group). Each group is its own chat window and its own recipient, so a `C` sent there is unambiguous. Turn the bot's privacy mode off in @BotFather (`/setprivacy`) first, then remove and re-add the bot to each group; otherwise it only sees commands, not a plain `C`.

Switching provider clears registered recipients, because their addresses belong to the old one.

Book any number of fictional appointments on the centre's timetable — Monday to Friday, 08:00 to 17:00, in 30-minute slots — and the booking form shows which of a clinician's slots that day are already taken as you fill it in. A clinician's slot at a given time and location cannot be double-booked; booking a slot that a cancellation left open takes it over. Creating a booking sends nothing; every reminder is sent by hand, one appointment at a time, so the trial quota is only spent deliberately.

## Data as HL7 FHIR R4

Everything clinical is stored as an HL7 FHIR R4 resource — the international base specification, no national profile — as JSON documents in the workspace's database, one row per resource, with search parameters indexed alongside. There is no FHIR REST endpoint: the store is internal to the app.

| In the app | Resource |
|---|---|
| Patient record | `Patient` (record number as `identifier`, delivery address as `telecom`) with one `Consent` (`provision.type = permit`) |
| Clinician, room, service | `Practitioner`, `Location`, `HealthcareService`; the service menu is also a `CodeSystem` |
| A clinician's slot in a room | `Slot` (30 minutes, clinic time) on a `Schedule`; an open slot is a `free` Slot |
| Booking | `Appointment` on the slot — `pending` until confirmed, `booked` after; the booking code is its `identifier` |
| Standby entry | `Appointment` with status `waitlist` and no slot; the day it waits for is `requestedPeriod`. Assigning moves the same Appointment onto the slot |
| Confirmation | `AppointmentResponse` (`participantStatus = accepted`) |
| Message | `Communication` — the address, the provider's delivery word and what the message is for travel with it; replies point at the message they answer |

Every resource the code produces is validated in the tests against HL7's official R4 JSON schema (`fhir/fhir.schema.json.gz`); at run time each write is checked against the R4 value sets before it reaches the database.

**Export and import.** On the Messaging setup tab, *Export FHIR Bundle* downloads the workspace as one Bundle (type `collection`) of those resources — messages are not included. *Import FHIR Bundle* takes a Bundle from any FHIR R4 system and adds it: every resource gets a new id and the references inside the file are rewritten to match; a clinician, room or service with the same name, or a patient with an identifier already on record, is reused rather than duplicated; resource types this app does not hold (Encounter, Observation…) and anything that fails the R4 checks are skipped and listed in the report. Imported patients show as unreachable until a record is pointed at a registered device.

## What works

- Service is chosen from a menu of the centre's programmes (Programa de la Mujer, Infantil y Adolescente, Adulto y Adulto Mayor, Salud Mental, Odontológico), in Spanish as the clinic names them. A record whose service predates the menu keeps it selectable when edited.
- Patient records come first. Staff create a patient on the Patients tab, then book an appointment or add a standby entry from that record. Renaming a patient updates every booking, and one registered device may serve many patients.
- The Patients tab doubles as a back office: pick a record to see its appointments, standby entries and message history, and to spot a patient whose delivery address is no longer a registered device.
- Send a Twilio-provided fixed Appointment Reminders template using From, To and ContentSid only. No custom Body or ContentVariables is sent.
- Poll incoming messages while the page is visible, every 15 seconds. Show real incoming messages for staff review, with support for snake_case and camelCase dates.
- A patient confirms with `/confirm`. It takes effect on its own when exactly one appointment on that chat is waiting and its reminder went out first; with two waiting, or none, nothing changes and the patient is told staff will settle it (Telegram). A plain C still needs staff to record it, because Twilio's fixed template asks for C. `/reschedule día/mes` (or `/reschedule` followed by the day when asked) moves the patient to the earliest free slot with their clinician on that day and asks them to `/confirm` the new time; if the day is full, it gives up their slot and puts them on that day's standby list instead. A specific day is required — «cualquier día» is answered with a request for one — and a day the centre is closed is pointed out. Nothing changes until a usable day is given. A bare R is still only recorded.
- The standby list is organised by day: each entry may say which day the patient is waiting for (or any day), and the page groups entries under those dates. Among those, candidates waiting for that day are offered first, then whoever has waited longest.
- Staff may delete an appointment outright from the edit dialog, behind a second confirmation. Unlike cancel, which keeps the slot open on the board, delete removes the booking; its message history is kept.
- Standby rows link back to the patient record, and a booked row links to the appointment it became. If that assignment is later cancelled or the appointment deleted, the row shows "Assignment cancelled" and can be re-queued with one click or removed.
- On Telegram, a patient can send `/cita` and get back their upcoming appointments and standby entries, in Spanish, read-only. It answers within about 15 seconds while the dashboard is open and not otherwise; on the Twilio trial the command is only recorded. On a shared device the answer lists everyone on it — one group per patient keeps answers private.
- Pressing Send reminder twice is refused; a follow-up to a patient who has not replied is a separate "Send again", counted on the button. A waiting entry can be edited (patient, service, day) or removed; a booked entry is the appointment it became and is edited or deleted as one.
- A standby-assigned slot is awaiting confirmation like any other booking: it shows under Awaiting reply and a reviewed C confirms it.
- Staff cancellation frees the slot: it stays on the board as open, and the booking is kept as a cancelled record (deletable from its panel, removed with its patient) so the patient record can be removed once nothing live references it. Assigning a standby patient is a staff decision made on the website: on Telegram the patient is then told which slot they were given and asked to reply C; on the Twilio trial nothing is sent until staff send the fixed template by hand. Assignment is labeled staff_assigned, never patient acceptance. When filling a slot, only patients waiting for that slot's service are offered; the slot keeps its own service.
- Staff may edit an active appointment. Editing sends no message. Changing the date, time, clinician, location or patient retires the booking code, which clears a recorded confirmation and requires a new template and a new C reply before it can be confirmed again; so does changing the patient's delivery address.

## Setup

In Twilio, link the verified recipient in Try out WhatsApp and send the Appointment Reminders template once. Read the From number and ContentSid in the API example. Enter those plus Account SID and Auth Token into CareQueue WhatsApp setup, then register the same phone with consent. Keep the Twilio trial session linked as required by Twilio. The template SID initially shown in the form was supplied in the user's trial screenshot; verify it against your own console.

Fixed-template sample dates are not clinic appointment dates. Acknowledge this before sending. This is not suitable for real patients. No upgrade is performed or required by the app. Trial quota, expiration and supported API access still apply. Live website-to-Twilio integration remains unverified until the owner enters credentials and runs a test. Automated tests use a fake transport and do not send any messages.

## Access and validation

Private Sites hosting. Every API requires authenticated owner identity; database queries are scoped by owner. Credentials are encrypted with an AES-GCM runtime CREDENTIAL_KEY and never returned to the browser. Secret .dev.vars is ignored. No AVIS/SINETSUR integration.

npm run build
npx tsc --noEmit
node --test tests/rules.test.ts tests/fhir.test.mjs tests/fhir-workflow.test.mjs

Official trial restrictions: https://www.twilio.com/docs/usage/trials/try-out-whatsapp
