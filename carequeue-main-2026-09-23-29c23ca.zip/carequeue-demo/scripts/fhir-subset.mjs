// Extract from HL7's official R4 JSON schema the definitions an import
// can reach — the nine resource types CareQueue takes in and every
// datatype they use — and write them as fhir/r4-import.schema.json for the
// Worker to validate uploads with. The full schema is 2.7 MB and needs
// ~200 MB to compile; this subset is ~50 KB, because `contained` (which
// reaches every resource type) is left out: the import drops contained
// resources before validating. Descriptions are stripped.
//
//   node scripts/fhir-subset.mjs
//
// The tests check the committed file against this script's output.
import { readFileSync, writeFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';

export const ROOTS = [
  'Patient',
  'Consent',
  'Practitioner',
  'Location',
  'HealthcareService',
  'Schedule',
  'Slot',
  'Appointment',
  'AppointmentResponse',
];

export function subset() {
  const full = JSON.parse(
    gunzipSync(readFileSync('fhir/fhir.schema.json.gz')).toString(),
  );
  const need = new Set();
  const walk = (v) => {
    if (Array.isArray(v)) return v.forEach(walk);
    if (!v || typeof v !== 'object') return;
    for (const [k, x] of Object.entries(v)) {
      if (k === 'contained') continue;
      if (k === '$ref') {
        const n = x.replace('#/definitions/', '');
        if (!need.has(n)) {
          need.add(n);
          walk(full.definitions[n]);
        }
      } else if (typeof x === 'object') walk(x);
    }
  };
  for (const r of ROOTS) {
    need.add(r);
    walk(full.definitions[r]);
  }
  const definitions = {};
  for (const n of [...need].sort((a, b) => a.localeCompare(b))) {
    // Documentation strings go; an element that happens to be called
    // "description" (Location, Appointment) is an object and stays.
    const d = JSON.parse(
      JSON.stringify(full.definitions[n], (k, v) =>
        k === 'description' && typeof v === 'string' ? undefined : v,
      ),
    );
    if (d.properties?.contained) delete d.properties.contained;
    definitions[n] = d;
  }
  return {
    source: 'http://hl7.org/fhir/R4/fhir.schema.json (4.0.1), subset',
    roots: ROOTS,
    definitions,
  };
}

if (process.argv[1]?.endsWith('fhir-subset.mjs')) {
  const out = subset();
  writeFileSync('fhir/r4-import.schema.json', JSON.stringify(out));
  console.log(
    `${Object.keys(out.definitions).length} definitions, ${JSON.stringify(out).length} bytes`,
  );
}
