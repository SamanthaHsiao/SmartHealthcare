-- The tables of the pre-FHIR data model go. Nothing is copied across on
-- purpose: this is a demonstration with fictional data, and the decision
-- (2026-09-16) was to start the FHIR workspace empty rather than migrate
-- the demo rows. A deployment that needed to keep its data would insert a
-- migration before this one that writes each patient, appointment,
-- standby entry and message into `resources` as the matching R4 resource
-- (see lib/fhir/build.ts for the shapes) and checks the counts, then run
-- this one.
DROP TABLE `appointments`;--> statement-breakpoint
DROP TABLE `messages`;--> statement-breakpoint
DROP TABLE `offers`;--> statement-breakpoint
DROP TABLE `patients`;--> statement-breakpoint
DROP TABLE `standby`;