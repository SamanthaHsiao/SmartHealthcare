ALTER TABLE `connections` ADD `provider` text DEFAULT 'twilio' NOT NULL;--> statement-breakpoint
ALTER TABLE `connections` ADD `cursor` text;--> statement-breakpoint
ALTER TABLE `connections` ADD `linkCode` text;--> statement-breakpoint
ALTER TABLE `connections` ADD `linkName` text;