PRAGMA foreign_keys=OFF;--> statement-breakpoint
CREATE TABLE `__new_appointments` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`patient` text NOT NULL,
	`phone` text NOT NULL,
	`date` text NOT NULL,
	`time` text NOT NULL,
	`clinician` text NOT NULL,
	`service` text NOT NULL,
	`location` text NOT NULL,
	`status` text DEFAULT 'scheduled' NOT NULL,
	`code` text NOT NULL,
	`activeOffer` text,
	`created` integer NOT NULL
);
--> statement-breakpoint
INSERT INTO `__new_appointments`("id", "owner", "patient", "phone", "date", "time", "clinician", "service", "location", "status", "code", "activeOffer", "created") SELECT "id", "owner", "patient", "phone", "date", "time", "clinician", "service", "location", "status", "code", "activeOffer", "created" FROM `appointments`;--> statement-breakpoint
DROP TABLE `appointments`;--> statement-breakpoint
ALTER TABLE `__new_appointments` RENAME TO `appointments`;--> statement-breakpoint
PRAGMA foreign_keys=ON;--> statement-breakpoint
CREATE INDEX `appointment_owner` ON `appointments` (`owner`);--> statement-breakpoint
CREATE UNIQUE INDEX `appointment_code` ON `appointments` (`code`);--> statement-breakpoint
CREATE UNIQUE INDEX `appointment_slot` ON `appointments` (`owner`,`date`,`time`,`clinician`,`location`);--> statement-breakpoint
CREATE TABLE `__new_standby` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`patient` text NOT NULL,
	`service` text NOT NULL,
	`status` text DEFAULT 'waiting' NOT NULL,
	`created` integer NOT NULL
);
--> statement-breakpoint
INSERT INTO `__new_standby`("id", "owner", "patient", "service", "status", "created") SELECT "id", "owner", "patient", "service", "status", "created" FROM `standby`;--> statement-breakpoint
DROP TABLE `standby`;--> statement-breakpoint
ALTER TABLE `__new_standby` RENAME TO `standby`;--> statement-breakpoint
CREATE INDEX `standby_owner` ON `standby` (`owner`);