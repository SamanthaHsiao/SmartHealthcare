CREATE TABLE `resources` (
	`owner` text NOT NULL,
	`type` text NOT NULL,
	`id` text NOT NULL,
	`version` integer NOT NULL,
	`updated` integer NOT NULL,
	`json` text NOT NULL,
	PRIMARY KEY(`owner`, `type`, `id`)
);
--> statement-breakpoint
CREATE INDEX `resource_type` ON `resources` (`owner`,`type`);--> statement-breakpoint
CREATE TABLE `search_index` (
	`owner` text NOT NULL,
	`type` text NOT NULL,
	`resource` text NOT NULL,
	`param` text NOT NULL,
	`value` text NOT NULL,
	`unique` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE INDEX `search_lookup` ON `search_index` (`owner`,`type`,`param`,`value`);--> statement-breakpoint
CREATE INDEX `search_resource` ON `search_index` (`owner`,`type`,`resource`);--> statement-breakpoint
CREATE UNIQUE INDEX `search_unique` ON `search_index` (`owner`,`type`,`param`,`value`) WHERE "search_index"."unique" = 1;