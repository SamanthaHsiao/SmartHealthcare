CREATE TABLE `patients` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`record` text NOT NULL,
	`name` text NOT NULL,
	`phone` text NOT NULL,
	`notes` text,
	`created` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `patient_owner` ON `patients` (`owner`);--> statement-breakpoint
CREATE UNIQUE INDEX `patient_record` ON `patients` (`owner`,`record`);--> statement-breakpoint
ALTER TABLE `appointments` ADD `patient` text;--> statement-breakpoint
ALTER TABLE `standby` ADD `patient` text;--> statement-breakpoint
-- Backfill: every distinct person already named on a booking or a standby row
-- becomes a patient record, then the rows point at it. Written by hand because
-- drizzle only generates structure, not data movement.
INSERT INTO `patients` (`id`, `owner`, `record`, `name`, `phone`, `notes`, `created`)
SELECT
	upper(hex(randomblob(4))),
	s.`owner`,
	'P-' || upper(hex(randomblob(2))),
	s.`name`,
	s.`phone`,
	NULL,
	CAST(strftime('%s','now') AS INTEGER) * 1000
FROM (
	SELECT `owner`, `name`, `phone` FROM `appointments`
	UNION
	SELECT `owner`, `name`, `phone` FROM `standby`
) s;--> statement-breakpoint
UPDATE `appointments` SET `patient` = (
	SELECT p.`id` FROM `patients` p
	WHERE p.`owner` = `appointments`.`owner`
		AND p.`name` = `appointments`.`name`
		AND p.`phone` = `appointments`.`phone`
);--> statement-breakpoint
UPDATE `standby` SET `patient` = (
	SELECT p.`id` FROM `patients` p
	WHERE p.`owner` = `standby`.`owner`
		AND p.`name` = `standby`.`name`
		AND p.`phone` = `standby`.`phone`
);
