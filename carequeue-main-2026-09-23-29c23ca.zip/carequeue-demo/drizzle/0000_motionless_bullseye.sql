CREATE TABLE `appointments` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`name` text NOT NULL,
	`phone` text NOT NULL,
	`date` text NOT NULL,
	`time` text NOT NULL,
	`clinician` text NOT NULL,
	`service` text NOT NULL,
	`location` text NOT NULL,
	`status` text DEFAULT 'scheduled' NOT NULL,
	`code` text NOT NULL,
	`activeOffer` text,
	`created` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `appointment_owner` ON `appointments` (`owner`);--> statement-breakpoint
CREATE UNIQUE INDEX `appointment_code` ON `appointments` (`code`);--> statement-breakpoint
CREATE TABLE `connections` (
	`owner` text PRIMARY KEY NOT NULL,
	`secret` text NOT NULL,
	`sender` text NOT NULL,
	`since` integer NOT NULL,
	`syncLock` integer DEFAULT 0 NOT NULL,
	`synced` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE TABLE `contacts` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`name` text NOT NULL,
	`phone` text NOT NULL,
	`consent` integer NOT NULL,
	`lastInbound` integer DEFAULT 0 NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `contact_phone` ON `contacts` (`owner`,`phone`);--> statement-breakpoint
CREATE TABLE `messages` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`phone` text NOT NULL,
	`body` text NOT NULL,
	`direction` text NOT NULL,
	`status` text NOT NULL,
	`sid` text,
	`error` text,
	`created` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `message_owner` ON `messages` (`owner`);--> statement-breakpoint
CREATE TABLE `offers` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`appointment` text NOT NULL,
	`candidate` text NOT NULL,
	`name` text NOT NULL,
	`phone` text NOT NULL,
	`status` text NOT NULL,
	`expires` integer NOT NULL,
	`created` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `standby` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`name` text NOT NULL,
	`phone` text NOT NULL,
	`service` text NOT NULL,
	`status` text DEFAULT 'waiting' NOT NULL,
	`created` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `standby_owner` ON `standby` (`owner`);