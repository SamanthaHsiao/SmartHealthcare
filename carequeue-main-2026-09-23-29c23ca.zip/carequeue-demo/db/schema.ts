import { sql } from 'drizzle-orm';
import {
  sqliteTable,
  text,
  integer,
  uniqueIndex,
  index,
  primaryKey,
} from 'drizzle-orm/sqlite-core';
// Two kinds of table. `connections` and `contacts` describe the messaging
// pipeline — the provider a workspace talks to and the devices it may write
// to — and are not clinical data. Everything clinical is an HL7 FHIR R4
// resource in `resources`, indexed by `search_index`.
export const connections = sqliteTable('connections', {
  owner: text().primaryKey(),
  // Which messaging provider this workspace is wired to: 'twilio' or 'telegram'.
  provider: text().notNull().default('twilio'),
  secret: text().notNull(),
  // Display label for the sending identity: a phone number for Twilio, a bot
  // username for Telegram.
  sender: text().notNull(),
  since: integer().notNull(),
  syncLock: integer().notNull().default(0),
  synced: integer().notNull().default(0),
  // Telegram getUpdates confirms and discards updates, so the next offset has
  // to be remembered. Unused by Twilio, which filters by DateSent instead.
  cursor: text(),
  // A pending Telegram link: staff generate a code, the contact sends
  // "/start <code>" to the bot, and the next sync binds their chat id.
  linkCode: text(),
  linkName: text(),
});
export const contacts = sqliteTable(
  'contacts',
  {
    id: text().primaryKey(),
    owner: text().notNull(),
    name: text().notNull(),
    // Provider address: an E.164 phone number for Twilio, a numeric chat id for
    // Telegram. Kept under one name so appointments, standby and messages can
    // address a recipient without caring which provider is active.
    phone: text().notNull(),
    consent: integer().notNull(),
    lastInbound: integer().notNull().default(0),
    // A conversation mid-flight: "/reschedule" sent without a day, waiting
    // for the day. JSON {appointment, until}; null when nothing is pending.
    pending: text(),
  },
  (t) => [uniqueIndex('contact_phone').on(t.owner, t.phone)],
);
// FHIR R4 resources, one JSON document per row. A resource is addressed as
// Type/id inside its workspace, so the three columns are the key and a
// reference such as "Patient/abc" resolves with one lookup. The row carries
// nothing the document does not: `version` is meta.versionId and `updated`
// is meta.lastUpdated, kept as columns so an update can refuse a stale write
// and a listing can order by recency without parsing every document.
export const resources = sqliteTable(
  'resources',
  {
    owner: text().notNull(),
    type: text().notNull(),
    id: text().notNull(),
    version: integer().notNull(),
    updated: integer().notNull(),
    json: text().notNull(),
  },
  (t) => [
    primaryKey({ columns: [t.owner, t.type, t.id] }),
    index('resource_type').on(t.owner, t.type),
  ],
);
// Search parameters extracted from each resource as it is written, the way a
// FHIR server indexes its search parameters: one row per (parameter, value),
// rewritten on every update. Which parameters exist per type is decided in
// lib/fhir/store.ts. A row flagged `unique` doubles as a uniqueness
// constraint — a patient's record number, a slot's schedule and start, a
// message's idempotency key — so a race between two writers is settled by
// the database rather than by whoever checked first.
export const searchIndex = sqliteTable(
  'search_index',
  {
    owner: text().notNull(),
    type: text().notNull(),
    resource: text().notNull(),
    param: text().notNull(),
    value: text().notNull(),
    unique: integer().notNull().default(0),
  },
  (t) => [
    index('search_lookup').on(t.owner, t.type, t.param, t.value),
    index('search_resource').on(t.owner, t.type, t.resource),
    uniqueIndex('search_unique')
      .on(t.owner, t.type, t.param, t.value)
      .where(sql`${t.unique} = 1`),
  ],
);
